import { createServer } from "vite";

const server = await createServer({
  server: { middlewareMode: true },
  appType: "custom",
  logLevel: "error",
});
const logic = await server.ssrLoadModule("/src/game/logic.ts");
const saveMod = await server.ssrLoadModule("/src/game/save.ts");
const save = saveMod.freshSave();
const match = logic.createMatch(save, "new");
if (!match) throw new Error("no match");
match.input.mx = 0;
match.input.my = -1;
for (let i = 0; i < 45; i++) logic.tick(match, 1 / 60);
const v = logic.playerVelocity(match);
const speed = Math.hypot(v.vx, v.vy);
const yawW = Math.atan2(-v.vx, -v.vy);
console.log("W speed", speed.toFixed(1), "yaw", yawW.toFixed(3), "pos", match.player.x.toFixed(0), match.player.y.toFixed(0));
if (speed < 50) throw new Error("W did not move");
const y0 = yawW;
match.input.mx = -1;
match.input.my = -1;
for (let i = 0; i < 30; i++) logic.tick(match, 1 / 60);
const v2 = logic.playerVelocity(match);
const y1 = Math.atan2(-v2.vx, -v2.vy);
const d = Math.atan2(Math.sin(y1 - y0), Math.cos(y1 - y0));
console.log("A+W dyaw", d.toFixed(3), "vx", v2.vx.toFixed(1), "vy", v2.vy.toFixed(1));
if (d < 0.05) throw new Error("A did not turn left-yaw, got " + d);

function centerDist(s) {
  const cx = 780 + 320;
  const cy = 560 + 250;
  return Math.hypot(s.x - cx, s.y - cy);
}
match.input.mx = 0;
match.input.my = 0;
for (let i = 0; i < 8 * 60; i++) logic.tick(match, 1 / 60);
const alive = match.sheep.filter((s) => !s.dead);
console.log(
  "t=8s phase",
  match.phase,
  "alive",
  alive.length,
  "queue",
  match.spawnQ.length,
  "avgDist",
  alive.length ? (alive.reduce((a, s) => a + centerDist(s), 0) / alive.length).toFixed(0) : "-",
);
console.log(alive.map((s) => `${s.kind}:${s.mode}@${Math.round(s.x)},${Math.round(s.y)} hp${Math.round(s.hp)}`).join("\n"));
const d0 = alive.reduce((a, s) => a + centerDist(s), 0) / Math.max(1, alive.length);
for (let i = 0; i < 12 * 60; i++) logic.tick(match, 1 / 60);
const alive2 = match.sheep.filter((s) => !s.dead);
const d1 = alive2.length ? alive2.reduce((a, s) => a + centerDist(s), 0) / alive2.length : 0;
const fences = match.fences.map((f) => `${f.side}${f.isGate ? "G" : "W"}:${Math.round(f.hp)}`);
console.log("t=20s phase", match.phase, "alive", alive2.length, "avgDist", d1.toFixed(0), "from", d0.toFixed(0));
console.log(alive2.map((s) => `${s.kind}:${s.mode}@${Math.round(s.x)},${Math.round(s.y)}`).join("\n"));
console.log("fences", fences.join(" "));
const damaged = match.fences.some((f) => f.hp < f.maxHp);
const inside = alive2.some((s) => s.x > 780 && s.x < 1420 && s.y > 560 && s.y < 1060);
console.log("damaged", damaged, "inside", inside, "coins", match.save.coins);
if (!damaged && !inside && match.phase === "combat") {
  throw new Error("sheep are not pressuring the garden");
}
// melee a sheep if any
if (alive2[0]) {
  match.player.x = alive2[0].x - 30;
  match.player.y = alive2[0].y;
  match.player.aim = Math.atan2(alive2[0].y - match.player.y, alive2[0].x - match.player.x);
  const before = match.save.coins;
  for (let n = 0; n < 12; n++) {
    match.input.attackEdge = true;
    logic.tick(match, 1 / 60);
    for (let k = 0; k < 20; k++) logic.tick(match, 1 / 60);
  }
  console.log("coins after swings", match.save.coins, "was", before, "dur", match.save.weapons.stick.durability);
  if (match.save.weapons.stick.durability >= 90) throw new Error("durability did not drop");
}
await server.close();
console.log("SIM OK");
