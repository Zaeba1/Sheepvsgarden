import { GEO } from "./content";
import type { Fence, Match, Obstacle, Sheep } from "./logic";

const INK = "#1c2430";

interface Wool {
  a: string;
  b: string;
  face: string;
  eye: string;
  glow?: string;
}

const WOOL: Record<string, Wool> = {
  "wool-classic": { a: "#f7f1e6", b: "#e3d0b8", face: "#3a2a22", eye: "#1c2430" },
  "wool-charcoal": { a: "#525a6b", b: "#343b4c", face: "#f4efe6", eye: "#e2a123" },
  "wool-mint": { a: "#c9f0da", b: "#8ed0ae", face: "#243028", eye: "#1c2430" },
  "wool-berry": { a: "#f6c0ce", b: "#e4899e", face: "#3a242c", eye: "#1c2430" },
  "wool-gold": { a: "#f8d56a", b: "#e2a123", face: "#3a2c12", eye: "#1c2430", glow: "#fff4c4" },
  "wool-cosmos": { a: "#32275f", b: "#1a1438", face: "#d9e2ff", eye: "#f4efe6", glow: "#9eb6ff" },
};

const GRASS: Record<string, { a: string; b: string; c: string }> = {
  "env-summer": { a: "#3f8f4e", b: "#2f6f3e", c: "#67b85a" },
  "env-autumn": { a: "#b8883e", b: "#8a6a32", c: "#d7b15a" },
  "env-snow": { a: "#d5e4e6", b: "#b7c9c8", c: "#f4f7f7" },
  "env-blossom": { a: "#4e9a5c", b: "#3d7d4c", c: "#f3b7c8" },
};

let grassCanvas: HTMLCanvasElement | null = null;
let grassKey = "";

export function render(ctx: CanvasRenderingContext2D, match: Match, vis: number) {
  const w = match.view.w;
  const h = match.view.h;
  const sky = match.save.equipped.sky;
  ctx.clearRect(0, 0, w, h);
  drawSky(ctx, w, h, sky, vis);
  const shake = match.save.settings.shake ? match.cam.shake : 0;
  const sx = shake ? Math.sin(vis * 42) * shake : 0;
  const sy = shake ? Math.cos(vis * 36) * shake : 0;
  ctx.save();
  ctx.translate(-match.cam.x + sx, -match.cam.y + sy);
  drawIsland(ctx, match.save.equipped.environment);
  drawGardenBed(ctx);
  const items: { y: number; draw: () => void }[] = [];
  for (const c of match.crops) {
    items.push({ y: c.y + 10, draw: () => drawCrop(ctx, c.x, c.y, c.hp / c.maxHp, match.save.equipped.vegetable, vis) });
  }
  for (const f of match.fences) {
    items.push({
      y: f.y + f.h,
      draw: () => drawFence(ctx, f, match.save.equipped.fence, vis),
    });
  }
  for (const o of match.obstacles) {
    items.push({ y: o.y + o.r, draw: () => drawObstacle(ctx, o) });
  }
  for (const s of match.sheep) {
    items.push({ y: s.y + s.radius, draw: () => drawSheep(ctx, s, match.save.equipped.sheep, vis) });
  }
  items.push({ y: match.player.y + 16, draw: () => drawPlayer(ctx, match, vis) });
  items.sort((a, b) => a.y - b.y);
  for (const it of items) it.draw();
  for (const b of match.bullets) {
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }
  for (const p of match.particles) {
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  ctx.font = "800 14px Nunito, Trebuchet MS, sans-serif";
  ctx.textAlign = "center";
  for (const f of match.floaters) {
    ctx.globalAlpha = Math.max(0, f.life / 0.8);
    ctx.fillStyle = f.color;
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.strokeText(f.text, f.x, f.y - (0.8 - f.life) * 28);
    ctx.fillText(f.text, f.x, f.y - (0.8 - f.life) * 28);
    ctx.globalAlpha = 1;
  }
  ctx.restore();
  grade(ctx, w, h, sky);
  if (match.countdown > 0 && match.phase === "combat") {
    ctx.fillStyle = INK;
    ctx.font = "800 42px Nunito, Trebuchet MS, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(String(Math.ceil(match.countdown)), w / 2, h * 0.28);
  }
  const p = match.player;
  ctx.strokeStyle = INK;
  ctx.fillStyle = "#f4efe6";
  ctx.beginPath();
  ctx.arc(p.x - match.cam.x + Math.cos(p.aim) * 36 + sx, p.y - match.cam.y + Math.sin(p.aim) * 36 + sy, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.stroke();
}

export function drawPoster(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  time: number,
  sky: string,
  env: string,
  wool: string,
  veg: string,
) {
  drawSky(ctx, w, h, sky, time);
  ctx.save();
  const scale = Math.max(w / 900, h / 640);
  ctx.translate(w * 0.5, h * 0.58);
  ctx.scale(scale, scale);
  ctx.translate(-1100, -980);
  drawIsland(ctx, env);
  drawGardenBed(ctx);
  drawCrop(ctx, 1040, 860, 1, veg, time);
  drawCrop(ctx, 1160, 900, 0.7, veg, time);
  const sheep = posterSheep(time);
  drawSheep(ctx, sheep, wool, time);
  ctx.restore();
  grade(ctx, w, h, sky);
}

function posterSheep(time: number): Sheep {
  const x = 980 + Math.sin(time * 0.7) * 70;
  return {
    id: 0,
    kind: "normal",
    x,
    y: 1120,
    vx: Math.cos(time * 0.7),
    vy: 0,
    hp: 10,
    maxHp: 10,
    speed: 40,
    dmg: 1,
    fenceDps: 1,
    intel: 0.2,
    aggr: 0.2,
    detect: 10,
    radius: 14,
    seed: 2,
    face: Math.sin(time * 0.7) > 0 ? 0 : Math.PI,
    phase: time * 6,
    mode: "enter",
    goalX: 0,
    goalY: 0,
    targetFence: -1,
    path: null,
    pathI: 0,
    think: 0,
    stuck: 0,
    lastX: 0,
    lastY: 0,
    frustrated: 0,
    evadeT: 0,
    stunT: 0,
    attackCd: 0,
    hitFlash: 0,
    dead: false,
    fade: 0,
    rewarded: false,
    chargeT: 0,
    boss: false,
  };
}

function drawSky(ctx: CanvasRenderingContext2D, w: number, h: number, id: string, time: number) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  const skies: Record<string, [string, string]> = {
    "sky-day": ["#79c7ea", "#d7f3ff"],
    "sky-sunset": ["#ff7a59", "#ffd7a8"],
    "sky-night": ["#14182e", "#33406a"],
    "sky-stars": ["#090d22", "#1c2450"],
    "sky-cosmos": ["#1a1038", "#3a2068"],
    "sky-aurora": ["#102430", "#1d4a4a"],
  };
  const pair = skies[id] ?? skies["sky-day"]!;
  g.addColorStop(0, pair[0]);
  g.addColorStop(1, pair[1]);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  if (id === "sky-day" || id === "sky-sunset") {
    ctx.fillStyle = id === "sky-sunset" ? "#ffe1a8" : "#fff4c4";
    ctx.beginPath();
    ctx.arc(w * 0.8, h * 0.16, Math.min(w, h) * 0.06, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.stroke();
  }
  if (id === "sky-night" || id === "sky-stars" || id === "sky-aurora") {
    ctx.fillStyle = "#f4efe6";
    ctx.beginPath();
    ctx.arc(w * 0.78, h * 0.16, Math.min(w, h) * 0.045, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = id === "sky-aurora" ? "#16343a" : "#1a2144";
    ctx.beginPath();
    ctx.arc(w * 0.78 - 8, h * 0.15, Math.min(w, h) * 0.038, 0, Math.PI * 2);
    ctx.fill();
  }
  if (id === "sky-stars" || id === "sky-cosmos" || id === "sky-night" || id === "sky-aurora") {
    const n = id === "sky-stars" || id === "sky-cosmos" ? 70 : 28;
    for (let i = 0; i < n; i++) {
      const hx = ((i * 97) % 1000) / 1000;
      const hy = ((i * 57) % 1000) / 1000;
      const tw = 0.35 + Math.abs(Math.sin(time * 1.5 + i)) * 0.65;
      ctx.globalAlpha = tw;
      ctx.fillStyle = id === "sky-cosmos" ? (i % 3 === 0 ? "#e2a123" : "#d7e4ff") : "#f4efe6";
      ctx.fillRect(hx * w, hy * h * 0.7, i % 5 === 0 ? 2.5 : 1.5, i % 5 === 0 ? 2.5 : 1.5);
    }
    ctx.globalAlpha = 1;
  }
  if (id === "sky-cosmos") {
    ctx.globalAlpha = 0.35;
    const neb = ctx.createRadialGradient(w * 0.3, h * 0.3, 10, w * 0.3, h * 0.3, w * 0.35);
    neb.addColorStop(0, "#d64545");
    neb.addColorStop(1, "rgba(214,69,69,0)");
    ctx.fillStyle = neb;
    ctx.fillRect(0, 0, w, h);
    ctx.globalAlpha = 1;
  }
  if (id === "sky-aurora") {
    ctx.save();
    ctx.globalAlpha = 0.55;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.strokeStyle = i === 1 ? "#67b85a" : i === 2 ? "#7eb6ff" : "#d6fff0";
      ctx.lineWidth = 18;
      for (let x = 0; x <= w; x += 16) {
        const y = h * (0.18 + i * 0.06) + Math.sin(x * 0.01 + time * 0.8 + i) * 26;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }
  ctx.globalAlpha = 0.85;
  for (let i = 0; i < 4; i++) {
    const cx = ((time * (12 + i * 6) + i * 180) % (w + 200)) - 100;
    const cy = 30 + i * 28;
    ctx.fillStyle = id === "sky-night" || id === "sky-stars" || id === "sky-cosmos" ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.72)";
    blob(ctx, cx, cy, 54, 22);
    blob(ctx, cx + 30, cy + 6, 36, 16);
  }
  ctx.globalAlpha = 1;
}

function grade(ctx: CanvasRenderingContext2D, w: number, h: number, id: string) {
  const tint: Record<string, string | null> = {
    "sky-day": null,
    "sky-sunset": "rgba(255,120,60,0.16)",
    "sky-night": "rgba(8,12,32,0.42)",
    "sky-stars": "rgba(6,8,24,0.48)",
    "sky-cosmos": "rgba(28,12,48,0.34)",
    "sky-aurora": "rgba(10,30,28,0.28)",
  };
  const c = tint[id];
  if (!c) return;
  ctx.fillStyle = c;
  ctx.fillRect(0, 0, w, h);
}

function drawIsland(ctx: CanvasRenderingContext2D, env: string) {
  const key = env;
  if (!grassCanvas || grassKey !== key) {
    grassCanvas = document.createElement("canvas");
    grassCanvas.width = GEO.worldW;
    grassCanvas.height = GEO.worldH;
    const g = grassCanvas.getContext("2d");
    if (!g) return;
    paintGrass(g, env);
    grassKey = key;
  }
  ctx.drawImage(grassCanvas, 0, 0);
  if (env === "env-snow" || env === "env-blossom" || env === "env-autumn") {
    /* flakes are animated in render via particles already; static specks live in cache */
  }
}

function paintGrass(ctx: CanvasRenderingContext2D, env: string) {
  const pal = GRASS[env] ?? GRASS["env-summer"]!;
  const isl = GEO.island;
  ctx.fillStyle = "rgba(20,30,40,0.25)";
  round(ctx, isl.x + 12, isl.y + 18, isl.w, isl.h, 80);
  ctx.fill();
  ctx.fillStyle = pal.a;
  round(ctx, isl.x, isl.y, isl.w, isl.h, 80);
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 4;
  ctx.stroke();
  for (let i = 0; i < 80; i++) {
    const x = isl.x + 30 + ((i * 173) % (isl.w - 60));
    const y = isl.y + 30 + ((i * 97) % (isl.h - 60));
    ctx.fillStyle = i % 2 ? pal.b : pal.c;
    ctx.globalAlpha = 0.35;
    blob(ctx, x, y, 18 + (i % 5) * 6, 10 + (i % 3) * 4);
  }
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#8a6244";
  const garden = GEO.garden;
  ctx.fillRect(1088, isl.y + 24, 24, garden.y - isl.y);
  ctx.fillRect(1088, garden.y + garden.h, 24, isl.y + isl.h - (garden.y + garden.h) - 24);
  ctx.fillRect(isl.x + 24, 800, garden.x - isl.x, 28);
  ctx.fillRect(garden.x + garden.w, 800, isl.x + isl.w - garden.x - garden.w - 24, 28);
  if (env === "env-autumn" || env === "env-blossom" || env === "env-snow") {
    ctx.fillStyle = env === "env-snow" ? "#ffffff" : env === "env-blossom" ? "#f3b7c8" : "#d64545";
    for (let i = 0; i < 50; i++) {
      const x = isl.x + ((i * 211) % isl.w);
      const y = isl.y + ((i * 139) % isl.h);
      ctx.globalAlpha = 0.7;
      ctx.beginPath();
      ctx.arc(x, y, env === "env-snow" ? 2 : 3, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
}

function drawGardenBed(ctx: CanvasRenderingContext2D) {
  const g = GEO.garden;
  ctx.fillStyle = "#6b4632";
  round(ctx, g.x + 8, g.y + 8, g.w - 16, g.h - 16, 18);
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.strokeStyle = "rgba(28,36,48,0.25)";
  ctx.lineWidth = 2;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(g.x + 24, g.y + i * (g.h / 4));
    ctx.lineTo(g.x + g.w - 24, g.y + i * (g.h / 4));
    ctx.stroke();
  }
}

function drawCrop(ctx: CanvasRenderingContext2D, x: number, y: number, hp: number, skin: string, time: number) {
  if (hp <= 0) {
    ctx.strokeStyle = "#3a2a22";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - 8, y + 6);
    ctx.lineTo(x + 8, y - 2);
    ctx.stroke();
    return;
  }
  const s = 0.55 + 0.45 * hp;
  const wilt = hp < 0.45;
  ctx.save();
  ctx.translate(x, y + 8);
  ctx.scale(s, s);
  ctx.rotate(wilt ? -0.2 : Math.sin(time + x) * 0.03);
  if (skin === "veg-pumpkin") {
    ctx.fillStyle = "#e07a28";
    ellipse(ctx, 0, 0, 16, 13);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.strokeStyle = "#a85a18";
    ctx.beginPath();
    ctx.moveTo(-6, 0);
    ctx.quadraticCurveTo(0, 4, 6, 0);
    ctx.stroke();
    ctx.fillStyle = "#2c6b45";
    ctx.fillRect(-2, -16, 4, 8);
  } else if (skin === "veg-crystal") {
    ctx.fillStyle = "#b7f0ff";
    crystal(ctx, 0, 0, 16);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.beginPath();
    ctx.moveTo(-4, -2);
    ctx.lineTo(0, -10);
    ctx.lineTo(2, -2);
    ctx.fill();
  } else if (skin === "veg-melon") {
    ctx.fillStyle = "#67b85a";
    ellipse(ctx, 0, 0, 16, 12);
    ctx.fillStyle = "#2c6b45";
    ctx.fillRect(-14, -2, 28, 3);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ellipse(ctx, 0, 0, 16, 12);
    ctx.stroke();
  } else if (skin === "veg-star") {
    ctx.fillStyle = "#fff4c4";
    star(ctx, 0, -2, 5, 16, 7);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.strokeStyle = "#e2a123";
    ctx.globalAlpha = 0.8;
    ctx.beginPath();
    ctx.arc(0, -2, 22 + Math.sin(time * 3 + x) * 2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  } else {
    ctx.fillStyle = "#2f6b3a";
    ellipse(ctx, 0, 2, 15, 11);
    ctx.fillStyle = "#67b85a";
    ellipse(ctx, -6, -2, 9, 8);
    ellipse(ctx, 6, -1, 9, 8);
    ellipse(ctx, 0, -6, 10, 8);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ellipse(ctx, 0, 2, 15, 11);
    ctx.stroke();
  }
  ctx.restore();
}

function drawFence(ctx: CanvasRenderingContext2D, f: Fence, skin: string, time: number) {
  if (f.hp <= 0) {
    ctx.strokeStyle = "#6b4632";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(f.x, f.y + f.h);
    ctx.lineTo(f.x + f.w * 0.4, f.y);
    ctx.lineTo(f.x + f.w, f.y + f.h * 0.7);
    ctx.stroke();
    return;
  }
  const openShift = f.isGate && f.open ? (f.side === "n" || f.side === "s" ? 0 : 0) : 0;
  void openShift;
  ctx.save();
  if (f.isGate && f.open) {
    ctx.translate(centerX(f), centerY(f));
    ctx.rotate(f.side === "w" || f.side === "n" ? -0.9 : 0.9);
    ctx.translate(-f.w / 2, -f.h / 2);
  } else {
    ctx.translate(f.x, f.y);
  }
  const ratio = f.hp / f.maxHp;
  if (skin === "fence-metal") {
    ctx.fillStyle = "#9aa4b2";
    ctx.fillRect(0, 0, f.w, f.h);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 0, f.w, f.h);
    ctx.strokeStyle = "#5c6774";
    ctx.lineWidth = 2;
    if (f.w > f.h) {
      for (let x = 8; x < f.w; x += 14) {
        ctx.beginPath();
        ctx.moveTo(x, 2);
        ctx.lineTo(x, f.h - 2);
        ctx.stroke();
      }
    } else {
      for (let y = 8; y < f.h; y += 14) {
        ctx.beginPath();
        ctx.moveTo(2, y);
        ctx.lineTo(f.w - 2, y);
        ctx.stroke();
      }
    }
  } else if (skin === "fence-neon") {
    ctx.strokeStyle = "#7dffe1";
    ctx.shadowColor = "#7dffe1";
    ctx.shadowBlur = 12;
    ctx.lineWidth = 4;
    ctx.strokeRect(2, 2, f.w - 4, f.h - 4);
    ctx.shadowBlur = 0;
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, f.w, f.h);
  } else if (skin === "fence-rune") {
    ctx.fillStyle = "#3d4a44";
    ctx.fillRect(0, 0, f.w, f.h);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 0, f.w, f.h);
    ctx.strokeStyle = `rgba(226,161,35,${0.45 + Math.sin(time * 3 + f.id) * 0.35})`;
    ctx.lineWidth = 2;
    ctx.strokeRect(4, 4, Math.max(2, f.w - 8), Math.max(2, f.h - 8));
  } else {
    ctx.fillStyle = f.isGate ? "#d7b15a" : "#c4904a";
    ctx.fillRect(0, 0, f.w, f.h);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 0, f.w, f.h);
    ctx.strokeStyle = "#8a5a28";
    ctx.lineWidth = 2;
    if (f.w >= f.h) {
      ctx.beginPath();
      ctx.moveTo(0, f.h * 0.35);
      ctx.lineTo(f.w, f.h * 0.35);
      ctx.moveTo(0, f.h * 0.7);
      ctx.lineTo(f.w, f.h * 0.7);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(f.w * 0.35, 0);
      ctx.lineTo(f.w * 0.35, f.h);
      ctx.moveTo(f.w * 0.7, 0);
      ctx.lineTo(f.w * 0.7, f.h);
      ctx.stroke();
    }
  }
  if (ratio < 0.66) {
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(f.w * 0.2, f.h * 0.2);
    ctx.lineTo(f.w * 0.55, f.h * 0.7);
    if (ratio < 0.33) {
      ctx.moveTo(f.w * 0.7, f.h * 0.15);
      ctx.lineTo(f.w * 0.4, f.h * 0.85);
    }
    ctx.stroke();
  }
  ctx.restore();
}

function drawObstacle(ctx: CanvasRenderingContext2D, o: Obstacle) {
  if (o.kind === "rock") {
    ctx.fillStyle = "#8d97a3";
    blob(ctx, o.x, o.y, o.r, o.r * 0.72);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    blob(ctx, o.x - o.r * 0.2, o.y - o.r * 0.2, o.r * 0.35, o.r * 0.22);
    return;
  }
  if (o.kind === "bush") {
    ctx.fillStyle = "#2c6b45";
    blob(ctx, o.x, o.y, o.r, o.r * 0.7);
    ctx.fillStyle = "#67b85a";
    blob(ctx, o.x - 4, o.y - 3, o.r * 0.6, o.r * 0.45);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    blob(ctx, o.x, o.y, o.r, o.r * 0.7);
    ctx.stroke();
    return;
  }
  ctx.fillStyle = "#6b4632";
  ctx.fillRect(o.x - 6, o.y - 4, 12, o.r * 0.7);
  ctx.strokeStyle = INK;
  ctx.strokeRect(o.x - 6, o.y - 4, 12, o.r * 0.7);
  ctx.fillStyle = "#2f6b3a";
  ellipse(ctx, o.x, o.y - o.r * 0.35, o.r, o.r * 0.8);
  ctx.fillStyle = "#67b85a";
  ellipse(ctx, o.x - o.r * 0.2, o.y - o.r * 0.55, o.r * 0.55, o.r * 0.4);
  ctx.strokeStyle = INK;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ellipse(ctx, o.x, o.y - o.r * 0.35, o.r, o.r * 0.8);
  ctx.stroke();
}

function drawSheep(ctx: CanvasRenderingContext2D, s: Sheep, skin: string, time: number) {
  const wool = WOOL[skin] ?? WOOL["wool-classic"]!;
  const sc = s.kind === "boss" ? 1.65 : s.kind === "armored" ? 1.12 : 1;
  ctx.save();
  ctx.translate(s.x, s.y);
  ctx.scale(sc, sc);
  if (s.dead) ctx.globalAlpha = Math.max(0, s.fade / 0.42);
  if (s.hitFlash > 0) ctx.globalAlpha = Math.min(1, ctx.globalAlpha) * 0.85;
  ctx.fillStyle = "rgba(28,36,48,0.22)";
  ellipse(ctx, 0, 10, 16, 6);
  const step = Math.sin(s.phase) * 4;
  ctx.strokeStyle = INK;
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  leg(ctx, -8, 4, step);
  leg(ctx, 8, 4, -step);
  ctx.fillStyle = wool.b;
  ellipse(ctx, 0, 2, 18, 13);
  ctx.fillStyle = wool.a;
  ellipse(ctx, -2, -1, 16, 12);
  puff(ctx, -12, -2, 7, wool.a);
  puff(ctx, 12, -1, 7, wool.a);
  puff(ctx, 0, -8, 8, wool.a);
  if (wool.glow) {
    ctx.fillStyle = wool.glow;
    ctx.globalAlpha *= 0.85;
    ctx.beginPath();
    ctx.arc(-4, -4, 2, 0, Math.PI * 2);
    ctx.arc(5, -2, 1.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = s.dead ? Math.max(0, s.fade / 0.42) : 1;
  }
  const fx = Math.cos(s.face);
  const fy = Math.sin(s.face);
  ctx.fillStyle = wool.face;
  ellipse(ctx, fx * 10, fy * 8 - 2, 7, 6);
  ctx.fillStyle = wool.eye;
  ctx.beginPath();
  ctx.arc(fx * 12 - 2, fy * 8 - 3, 1.3, 0, Math.PI * 2);
  ctx.arc(fx * 12 + 2, fy * 8 - 3, 1.3, 0, Math.PI * 2);
  ctx.fill();
  if (s.mode === "evade") {
    ctx.strokeStyle = wool.eye;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(fx * 12 - 4, fy * 8 - 6);
    ctx.lineTo(fx * 12 - 1, fy * 8 - 5);
    ctx.moveTo(fx * 12 + 4, fy * 8 - 6);
    ctx.lineTo(fx * 12 + 1, fy * 8 - 5);
    ctx.stroke();
  }
  kindMarks(ctx, s.kind, time);
  ctx.restore();
  if (!s.dead && s.hp < s.maxHp) bar(ctx, s.x, s.y - s.radius - 14, 28, s.hp / s.maxHp, s.boss ? "#e2a123" : "#d64545");
}

function kindMarks(ctx: CanvasRenderingContext2D, kind: Sheep["kind"], time: number) {
  ctx.strokeStyle = INK;
  ctx.fillStyle = INK;
  ctx.lineWidth = 2;
  if (kind === "fast") {
    ctx.beginPath();
    ctx.moveTo(-20, 0);
    ctx.lineTo(-28, -3);
    ctx.moveTo(-18, 6);
    ctx.lineTo(-26, 6);
    ctx.stroke();
  } else if (kind === "armored") {
    ctx.fillStyle = "#9aa4b2";
    ctx.fillRect(-10, -6, 20, 8);
    ctx.strokeRect(-10, -6, 20, 8);
  } else if (kind === "cunning") {
    ctx.strokeStyle = "#d64545";
    ctx.beginPath();
    ctx.arc(0, -2, 12, Math.PI * 1.1, Math.PI * 1.9);
    ctx.stroke();
  } else if (kind === "breaker") {
    ctx.beginPath();
    ctx.moveTo(-6, -12);
    ctx.lineTo(-2, -18);
    ctx.lineTo(2, -12);
    ctx.moveTo(4, -12);
    ctx.lineTo(8, -18);
    ctx.lineTo(12, -12);
    ctx.stroke();
  } else if (kind === "tactician") {
    ctx.fillStyle = "#d64545";
    ctx.fillRect(10, -16, 10, 6);
    ctx.strokeRect(10, -16, 10, 6);
    ctx.beginPath();
    ctx.moveTo(10, -16);
    ctx.lineTo(10, -4);
    ctx.stroke();
  } else if (kind === "boss") {
    ctx.fillStyle = "#e2a123";
    ctx.beginPath();
    ctx.moveTo(-10, -10);
    ctx.lineTo(-16, -22);
    ctx.lineTo(-4, -12);
    ctx.moveTo(10, -10);
    ctx.lineTo(16, -22);
    ctx.lineTo(4, -12);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#e2a123";
    ctx.globalAlpha = 0.4 + Math.sin(time * 4) * 0.2;
    ctx.beginPath();
    ctx.arc(0, 0, 26, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
}

function drawPlayer(ctx: CanvasRenderingContext2D, match: Match, _time: number) {
  const p = match.player;
  ctx.save();
  ctx.translate(p.x, p.y);
  if (p.iFrame > 0 && Math.sin(p.iFrame * 40) > 0) ctx.globalAlpha = 0.45;
  ctx.fillStyle = "rgba(28,36,48,0.22)";
  ellipse(ctx, 0, 12, 12, 5);
  const step = Math.sin(p.bob) * 3;
  ctx.strokeStyle = INK;
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-5, 4);
  ctx.lineTo(-6, 12 + step);
  ctx.moveTo(5, 4);
  ctx.lineTo(6, 12 - step);
  ctx.stroke();
  ctx.fillStyle = "#243044";
  round(ctx, -9, -2, 18, 14, 4);
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.fillStyle = "#2c6b45";
  round(ctx, -8, -8, 16, 12, 4);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#d64545";
  ctx.fillRect(-3, -4, 6, 4);
  ctx.fillStyle = "#f3c7a4";
  ellipse(ctx, 0, -14, 8, 8);
  ctx.strokeStyle = INK;
  ctx.lineWidth = 2.5;
  ctx.stroke();
  ctx.fillStyle = "#3b271c";
  ellipse(ctx, 0, -18, 8, 5);
  ctx.fillRect(-8, -18, 16, 4);
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.arc(-3, -14, 1.2, 0, Math.PI * 2);
  ctx.arc(3, -14, 1.2, 0, Math.PI * 2);
  ctx.fill();
  drawWeapon(ctx, match);
  if (p.swing > 0) {
    const w = match.save.equipped.weapon;
    ctx.strokeStyle = w === "wskin-void" ? "#b07cff" : w === "wskin-night" ? "#7eb6ff" : w === "wskin-sakura" ? "#e48ab0" : "#f4efe6";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, 40, p.swingDir - 0.8, p.swingDir + 0.5);
    ctx.stroke();
  }
  ctx.restore();
}

function drawWeapon(ctx: CanvasRenderingContext2D, match: Match) {
  const id = match.save.equippedWeapon;
  const skin = match.save.equipped.weapon;
  const tint =
    skin === "wskin-sakura" ? "#e48ab0" : skin === "wskin-night" ? "#2a3358" : skin === "wskin-gold" ? "#e2a123" : skin === "wskin-void" ? "#6a4cff" : "#c4a574";
  const ang = match.player.aim;
  ctx.save();
  ctx.rotate(ang);
  ctx.translate(12, 4);
  ctx.strokeStyle = INK;
  ctx.fillStyle = tint;
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  if (id === "axe") {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(28, 0);
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(30, -4, 8, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (id === "hammer") {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(26, 0);
    ctx.stroke();
    ctx.fillRect(24, -7, 12, 14);
    ctx.strokeRect(24, -7, 12, 14);
  } else if (id === "pistol" || id === "smg" || id === "rifle" || id === "shotgun") {
    const len = id === "rifle" || id === "shotgun" ? 34 : id === "smg" ? 24 : 22;
    ctx.fillRect(0, -3, len, 6);
    ctx.strokeRect(0, -3, len, 6);
    ctx.fillRect(4, 3, 7, 6);
  } else if (id === "plasma") {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(26, 0);
    ctx.stroke();
    ctx.fillStyle = "#b7f0ff";
    ctx.beginPath();
    ctx.arc(30, 0, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (id === "lance") {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(40, 0);
    ctx.stroke();
    star(ctx, 44, 0, 4, 7, 3);
    ctx.fill();
    ctx.stroke();
  } else {
    const len = id === "pipe" || id === "metal" || id === "bat" ? 32 : 24;
    ctx.lineWidth = id === "metal" ? 6 : 4;
    ctx.strokeStyle = id === "metal" ? "#9aa4b2" : tint;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(len, 0);
    ctx.stroke();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.stroke();
  }
  ctx.restore();
}

function bar(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, ratio: number, color: string) {
  ctx.fillStyle = INK;
  ctx.fillRect(x - w / 2 - 1, y - 1, w + 2, 6);
  ctx.fillStyle = "#f4efe6";
  ctx.fillRect(x - w / 2, y, w, 4);
  ctx.fillStyle = color;
  ctx.fillRect(x - w / 2, y, w * Math.max(0, Math.min(1, ratio)), 4);
}

function ellipse(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
}

function blob(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number) {
  ctx.beginPath();
  ctx.ellipse(x, y, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2);
  ctx.fill();
}

function puff(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 2;
  ctx.stroke();
}

function leg(ctx: CanvasRenderingContext2D, x: number, y: number, o: number) {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + o * 0.2, y + 10);
  ctx.stroke();
}

function round(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function crystal(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x, y - r);
  ctx.lineTo(x + r * 0.7, y);
  ctx.lineTo(x, y + r * 0.8);
  ctx.lineTo(x - r * 0.7, y);
  ctx.closePath();
  ctx.fill();
}

function star(ctx: CanvasRenderingContext2D, x: number, y: number, spikes: number, outer: number, inner: number) {
  ctx.beginPath();
  for (let i = 0; i < spikes * 2; i++) {
    const rad = i % 2 === 0 ? outer : inner;
    const a = -Math.PI / 2 + (i * Math.PI) / spikes;
    const px = x + Math.cos(a) * rad;
    const py = y + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function centerX(f: Fence) {
  return f.x + f.w / 2;
}
function centerY(f: Fence) {
  return f.y + f.h / 2;
}

export function drawIcon(ctx: CanvasRenderingContext2D, cat: string, id: string, w: number, h: number) {
  ctx.clearRect(0, 0, w, h);
  if (cat === "sky" || cat === "environment") {
    drawSky(ctx, w, h, cat === "sky" ? id : "sky-day", 1.2);
    if (cat === "environment") {
      const pal = GRASS[id] ?? GRASS["env-summer"]!;
      ctx.fillStyle = pal.a;
      round(ctx, 16, h * 0.45, w - 32, h * 0.4, 16);
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 3;
      ctx.stroke();
    }
    return;
  }
  ctx.fillStyle = "#d7efe0";
  ctx.fillRect(0, 0, w, h);
  if (cat === "sheep") {
    const fake = posterSheep(0);
    fake.x = w / 2;
    fake.y = h / 2 + 8;
    fake.kind = id === "wool-cosmos" ? "boss" : "normal";
    if (id !== "wool-cosmos") fake.kind = "normal";
    drawSheep(ctx, fake, id, 0);
  } else if (cat === "vegetable") {
    drawCrop(ctx, w / 2, h / 2, 1, id, 0);
  } else if (cat === "fence") {
    const f: Fence = { id: 1, side: "n", x: 20, y: h / 2 - 12, w: w - 40, h: 24, hp: 10, maxHp: 10, isGate: false, open: false };
    drawFence(ctx, f, id, 1);
  } else if (cat === "weapon" || cat === "fx") {
    ctx.fillStyle = INK;
    ctx.font = "800 16px Nunito, Trebuchet MS, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(cat === "fx" ? "FX" : "оружие", w / 2, h / 2);
  }
}
