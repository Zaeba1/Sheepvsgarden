import { COSMETICS, WEAPONS, type CosmeticCat, type SheepKind } from "./content";

export const SAVE_KEY = "sheep-ai-save-v1";

export interface WeaponState {
  unlocked: boolean;
  durability: number;
  loaded: number;
  reserve: number;
}

export interface RunStats {
  kills: number;
  earned: number;
  gardenLost: number;
  weaponUse: Record<string, number>;
  bestName: string;
  bestScore: number;
}

export interface RunSave {
  wave: number;
  phase: "combat" | "intermission";
  countdown: number;
  player: { x: number; y: number; hp: number; aim: number };
  fences: { hp: number; open: boolean }[];
  crops: number[];
  sheep: { kind: SheepKind; x: number; y: number; hp: number; seed: number }[];
  spawnQ: SheepKind[];
  spawnT: number;
  stats: RunStats;
}

export interface Settings {
  volume: number;
  muted: boolean;
  shake: boolean;
  aimAssist: boolean;
}

export interface LifetimeStats {
  bestWave: number;
  totalKills: number;
  totalCoinsEarned: number;
  runs: number;
}

export interface SaveData {
  version: 1;
  coins: number;
  weapons: Record<string, WeaponState>;
  equippedWeapon: string;
  owned: string[];
  equipped: Record<CosmeticCat, string>;
  settings: Settings;
  stats: LifetimeStats;
  run: RunSave | null;
}

function emptyUse(): Record<string, number> {
  const o: Record<string, number> = {};
  for (const w of WEAPONS) o[w.id] = 0;
  return o;
}

export function emptyRunStats(): RunStats {
  return { kills: 0, earned: 0, gardenLost: 0, weaponUse: emptyUse(), bestName: "—", bestScore: 0 };
}

export function freshSave(): SaveData {
  const weapons: Record<string, WeaponState> = {};
  for (const w of WEAPONS) {
    weapons[w.id] = {
      unlocked: w.unlock === 0,
      durability: w.durability,
      loaded: w.kind === "gun" ? w.mag : 0,
      reserve: w.kind === "gun" ? w.mag * 2 : 0,
    };
  }
  const owned = COSMETICS.filter((c) => c.price === 0).map((c) => c.id);
  return {
    version: 1,
    coins: 0,
    weapons,
    equippedWeapon: "stick",
    owned,
    equipped: {
      sheep: "wool-classic",
      vegetable: "veg-cabbage",
      fence: "fence-wood",
      weapon: "wskin-plain",
      sky: "sky-day",
      environment: "env-summer",
      fx: "fx-wool",
    },
    settings: { volume: 0.7, muted: false, shake: true, aimAssist: false },
    stats: { bestWave: 0, totalKills: 0, totalCoinsEarned: 0, runs: 0 },
    run: null,
  };
}

function num(v: unknown, fallback: number, min = 0, max = 1e9): number {
  const n = typeof v === "number" && Number.isFinite(v) ? v : fallback;
  return Math.min(max, Math.max(min, n));
}

export function sanitize(raw: unknown): SaveData {
  const base = freshSave();
  if (!raw || typeof raw !== "object") return base;
  const o = raw as Partial<SaveData>;
  base.coins = Math.floor(num(o.coins, 0, 0, 9_999_999));
  if (o.weapons && typeof o.weapons === "object") {
    for (const w of WEAPONS) {
      const s = (o.weapons as Record<string, Partial<WeaponState>>)[w.id];
      if (!s) continue;
      base.weapons[w.id] = {
        unlocked: Boolean(s.unlocked) || w.unlock === 0,
        durability: num(s.durability, w.durability, 0, w.durability),
        loaded: w.kind === "gun" ? Math.floor(num(s.loaded, w.mag, 0, w.mag)) : 0,
        reserve: w.kind === "gun" ? Math.floor(num(s.reserve, w.mag * 2, 0, w.mag * 5)) : 0,
      };
    }
  }
  if (typeof o.equippedWeapon === "string" && base.weapons[o.equippedWeapon]?.unlocked) {
    base.equippedWeapon = o.equippedWeapon;
  }
  if (Array.isArray(o.owned)) {
    for (const id of o.owned) {
      if (typeof id === "string" && COSMETICS.some((c) => c.id === id) && !base.owned.includes(id)) {
        base.owned.push(id);
      }
    }
  }
  if (o.equipped && typeof o.equipped === "object") {
    (Object.keys(base.equipped) as CosmeticCat[]).forEach((cat) => {
      const id = (o.equipped as Record<string, string>)[cat];
      if (typeof id === "string" && base.owned.includes(id)) base.equipped[cat] = id;
    });
  }
  if (o.settings && typeof o.settings === "object") {
    const s = o.settings;
    base.settings = {
      volume: num(s.volume, 0.7, 0, 1),
      muted: Boolean(s.muted),
      shake: s.shake !== false,
      aimAssist: Boolean(s.aimAssist),
    };
  }
  if (o.stats && typeof o.stats === "object") {
    base.stats = {
      bestWave: Math.floor(num(o.stats.bestWave, 0, 0, 9999)),
      totalKills: Math.floor(num(o.stats.totalKills, 0, 0, 9_999_999)),
      totalCoinsEarned: Math.floor(num(o.stats.totalCoinsEarned, 0, 0, 9_999_999)),
      runs: Math.floor(num(o.stats.runs, 0, 0, 9_999_999)),
    };
  }
  base.run = sanitizeRun(o.run);
  return base;
}

function sanitizeRun(raw: unknown): RunSave | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Partial<RunSave>;
  if (!r.player || !Array.isArray(r.fences) || !Array.isArray(r.crops)) return null;
  const kinds: SheepKind[] = ["normal", "fast", "armored", "cunning", "breaker", "tactician", "boss"];
  const sheep = Array.isArray(r.sheep)
    ? r.sheep
        .filter((s) => s && kinds.includes(s.kind))
        .map((s) => ({
          kind: s.kind,
          x: num(s.x, 0, 0, 5000),
          y: num(s.y, 0, 0, 5000),
          hp: num(s.hp, 1, 0, 100000),
          seed: num(s.seed, 1, 0, 1e12),
        }))
    : [];
  const spawnQ = Array.isArray(r.spawnQ) ? r.spawnQ.filter((k): k is SheepKind => kinds.includes(k as SheepKind)) : [];
  const stats = r.stats && typeof r.stats === "object" ? r.stats : emptyRunStats();
  return {
    wave: Math.floor(num(r.wave, 1, 1, 999)),
    phase: r.phase === "intermission" ? "intermission" : "combat",
    countdown: num(r.countdown, 0, 0, 30),
    player: {
      x: num(r.player.x, 1100, 0, 5000),
      y: num(r.player.y, 1260, 0, 5000),
      hp: num(r.player.hp, 100, 1, 100),
      aim: num(r.player.aim, -Math.PI / 2, -20, 20),
    },
    fences: r.fences.map((f) => ({
      hp: num(f?.hp, 0, 0, 100000),
      open: Boolean(f?.open),
    })),
    crops: r.crops.map((h) => num(h, 0, 0, 100000)),
    sheep,
    spawnQ,
    spawnT: num(r.spawnT, 0, 0, 30),
    stats: {
      kills: Math.floor(num(stats.kills, 0)),
      earned: Math.floor(num(stats.earned, 0)),
      gardenLost: num(stats.gardenLost, 0),
      weaponUse: { ...emptyUse(), ...(stats.weaponUse ?? {}) },
      bestName: typeof stats.bestName === "string" ? stats.bestName : "—",
      bestScore: num(stats.bestScore, 0),
    },
  };
}

export function loadSave(): SaveData {
  try {
    const text = localStorage.getItem(SAVE_KEY);
    if (!text) return freshSave();
    return sanitize(JSON.parse(text) as unknown);
  } catch {
    return freshSave();
  }
}

export function persist(save: SaveData) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(save));
  } catch {
    /* ignore quota */
  }
}
