export type SheepKind =
  | "normal"
  | "fast"
  | "armored"
  | "cunning"
  | "breaker"
  | "tactician"
  | "boss";

export type WeaponKind = "melee" | "gun";

export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary" | "exotic";

export type CosmeticCat =
  | "sheep"
  | "vegetable"
  | "fence"
  | "weapon"
  | "sky"
  | "environment"
  | "fx";

export type Side = "n" | "s" | "e" | "w";

export interface WeaponDef {
  id: string;
  name: string;
  blurb: string;
  kind: WeaponKind;
  dmg: number;
  range: number;
  arc: number;
  cooldown: number;
  durability: number;
  repair: number;
  unlock: number;
  knock: number;
  stun: number;
  dash: number;
  mag: number;
  reload: number;
  pellets: number;
  spread: number;
  bulletSpeed: number;
  pierce: number;
}

export interface KindDef {
  name: string;
  blurb: string;
  hp: number;
  speed: number;
  dmg: number;
  fence: number;
  intel: number;
  aggr: number;
  detect: number;
  radius: number;
  coins: number;
}

export interface CosmeticDef {
  id: string;
  cat: CosmeticCat;
  name: string;
  desc: string;
  rarity: Rarity;
  price: number;
}

export const GEO = {
  cell: 32,
  island: { x: 160, y: 140, w: 1880, h: 1360 },
  garden: { x: 780, y: 560, w: 640, h: 500 },
  fenceT: 24,
  gate: 100,
  worldW: 2200,
  worldH: 1640,
};

export const PLAYER_SPEED = 236;
export const PLAYER_HP = 100;
export const PLAYER_R = 15;

export const KINDS: Record<SheepKind, KindDef> = {
  normal: {
    name: "Обычная овца",
    blurb: "Идёт к ближайшим воротам и бодает их, если закрыто.",
    hp: 38,
    speed: 76,
    dmg: 8,
    fence: 6,
    intel: 0.2,
    aggr: 0.25,
    detect: 140,
    radius: 14,
    coins: 10,
  },
  fast: {
    name: "Быстрая овца",
    blurb: "Ищет открытый проход и старается проскочить мимо вас.",
    hp: 24,
    speed: 148,
    dmg: 6,
    fence: 3,
    intel: 0.38,
    aggr: 0.18,
    detect: 170,
    radius: 12,
    coins: 12,
  },
  armored: {
    name: "Бронированная",
    blurb: "Медленная, толстая, ломает ближайший забор.",
    hp: 96,
    speed: 52,
    dmg: 12,
    fence: 11,
    intel: 0.32,
    aggr: 0.72,
    detect: 150,
    radius: 16,
    coins: 18,
  },
  cunning: {
    name: "Хитрая овца",
    blurb: "Считает маршрут, игнорирует закрытые ворота и обходит вас.",
    hp: 42,
    speed: 96,
    dmg: 8,
    fence: 5,
    intel: 0.74,
    aggr: 0.34,
    detect: 230,
    radius: 14,
    coins: 16,
  },
  breaker: {
    name: "Разрушитель",
    blurb: "Бьёт самый слабый участок и открывает дыру остальным.",
    hp: 62,
    speed: 68,
    dmg: 10,
    fence: 16,
    intel: 0.58,
    aggr: 0.48,
    detect: 180,
    radius: 15,
    coins: 20,
  },
  tactician: {
    name: "Тактик",
    blurb: "Отвлекает вас, пока стадо заходит с другой стороны.",
    hp: 50,
    speed: 100,
    dmg: 9,
    fence: 6,
    intel: 0.86,
    aggr: 0.42,
    detect: 260,
    radius: 14,
    coins: 22,
  },
  boss: {
    name: "Баран-вожак",
    blurb: "Таранит забор и игрока. Отдельная шкала здоровья.",
    hp: 420,
    speed: 70,
    dmg: 16,
    fence: 22,
    intel: 0.9,
    aggr: 0.8,
    detect: 320,
    radius: 26,
    coins: 80,
  },
};

export const WEAPONS: WeaponDef[] = [
  {
    id: "stick",
    name: "Деревянная палка",
    blurb: "Быстрые короткие удары. Стартовое оружие.",
    kind: "melee",
    dmg: 13,
    range: 62,
    arc: 1.25,
    cooldown: 0.3,
    durability: 90,
    repair: 8,
    unlock: 0,
    knock: 70,
    stun: 0,
    dash: 0,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
  {
    id: "pipe",
    name: "Пластиковая труба",
    blurb: "Длиннее палки и чуть быстрее. Удобно держать дистанцию.",
    kind: "melee",
    dmg: 15,
    range: 78,
    arc: 1.05,
    cooldown: 0.26,
    durability: 100,
    repair: 12,
    unlock: 40,
    knock: 50,
    stun: 0,
    dash: 0,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
  {
    id: "metal",
    name: "Металлическая труба",
    blurb: "Тяжёлая. Сильный отброс, удар медленнее.",
    kind: "melee",
    dmg: 24,
    range: 74,
    arc: 0.95,
    cooldown: 0.4,
    durability: 120,
    repair: 18,
    unlock: 110,
    knock: 150,
    stun: 0.12,
    dash: 0,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
  {
    id: "axe",
    name: "Топор",
    blurb: "Широкая дуга: задевает несколько овец сразу.",
    kind: "melee",
    dmg: 32,
    range: 68,
    arc: 1.85,
    cooldown: 0.5,
    durability: 75,
    repair: 26,
    unlock: 190,
    knock: 90,
    stun: 0,
    dash: 0,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
  {
    id: "hammer",
    name: "Молот",
    blurb: "Медленный удар оглушает и отбрасывает толпу.",
    kind: "melee",
    dmg: 46,
    range: 64,
    arc: 0.85,
    cooldown: 0.68,
    durability: 80,
    repair: 34,
    unlock: 290,
    knock: 210,
    stun: 0.48,
    dash: 0,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
  {
    id: "bat",
    name: "Усиленная бита",
    blurb: "Середина пути: темп палки и вес трубы.",
    kind: "melee",
    dmg: 28,
    range: 80,
    arc: 1.2,
    cooldown: 0.32,
    durability: 140,
    repair: 30,
    unlock: 400,
    knock: 120,
    stun: 0.08,
    dash: 0,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
  {
    id: "pistol",
    name: "Пистолет",
    blurb: "Первый ствол. Магазин, перезарядка, точные выстрелы.",
    kind: "gun",
    dmg: 16,
    range: 460,
    arc: 0,
    cooldown: 0.26,
    durability: 160,
    repair: 42,
    unlock: 580,
    knock: 30,
    stun: 0,
    dash: 0,
    mag: 12,
    reload: 1.05,
    pellets: 1,
    spread: 0.05,
    bulletSpeed: 680,
    pierce: 1,
  },
  {
    id: "shotgun",
    name: "Дробовик",
    blurb: "Пять дробин веером. Рвёт стадо в упор, далеко не бьёт.",
    kind: "gun",
    dmg: 11,
    range: 230,
    arc: 0,
    cooldown: 0.7,
    durability: 90,
    repair: 56,
    unlock: 860,
    knock: 80,
    stun: 0.05,
    dash: 0,
    mag: 5,
    reload: 1.55,
    pellets: 5,
    spread: 0.42,
    bulletSpeed: 560,
    pierce: 1,
  },
  {
    id: "smg",
    name: "Пистолет-пулемёт",
    blurb: "Очень быстрый огонь и большой разброс.",
    kind: "gun",
    dmg: 8,
    range: 380,
    arc: 0,
    cooldown: 0.08,
    durability: 180,
    repair: 72,
    unlock: 1240,
    knock: 16,
    stun: 0,
    dash: 0,
    mag: 28,
    reload: 1.25,
    pellets: 1,
    spread: 0.14,
    bulletSpeed: 740,
    pierce: 1,
  },
  {
    id: "rifle",
    name: "Винтовка",
    blurb: "Дальнобойный точный выстрел по одной цели.",
    kind: "gun",
    dmg: 38,
    range: 620,
    arc: 0,
    cooldown: 0.46,
    durability: 120,
    repair: 88,
    unlock: 1780,
    knock: 60,
    stun: 0,
    dash: 0,
    mag: 8,
    reload: 1.45,
    pellets: 1,
    spread: 0.012,
    bulletSpeed: 980,
    pierce: 1,
  },
  {
    id: "plasma",
    name: "Плазменный жезл",
    blurb: "Медленный сгусток прошивает несколько овец.",
    kind: "gun",
    dmg: 24,
    range: 500,
    arc: 0,
    cooldown: 0.22,
    durability: 100,
    repair: 130,
    unlock: 2680,
    knock: 20,
    stun: 0.1,
    dash: 0,
    mag: 16,
    reload: 1.15,
    pellets: 1,
    spread: 0.02,
    bulletSpeed: 430,
    pierce: 3,
  },
  {
    id: "lance",
    name: "Звёздное копьё",
    blurb: "Выпад вперёд с длинным уколом. Экзотика ближнего боя.",
    kind: "melee",
    dmg: 64,
    range: 118,
    arc: 0.48,
    cooldown: 0.38,
    durability: 85,
    repair: 170,
    unlock: 3600,
    knock: 40,
    stun: 0.15,
    dash: 96,
    mag: 0,
    reload: 0,
    pellets: 1,
    spread: 0,
    bulletSpeed: 0,
    pierce: 1,
  },
];

export const COSMETICS: CosmeticDef[] = [
  { id: "wool-classic", cat: "sheep", name: "Классическая шерсть", desc: "Тёплая кремовая отара.", rarity: "common", price: 0 },
  { id: "wool-charcoal", cat: "sheep", name: "Угольные", desc: "Тёмная шерсть и светлые глаза.", rarity: "uncommon", price: 80 },
  { id: "wool-mint", cat: "sheep", name: "Мятные", desc: "Прохладный зелёный оттенок.", rarity: "uncommon", price: 90 },
  { id: "wool-berry", cat: "sheep", name: "Ягодные", desc: "Розовая шерсть, как глазурь.", rarity: "rare", price: 180 },
  { id: "wool-gold", cat: "sheep", name: "Золотое руно", desc: "Блестящая шерсть с искрами.", rarity: "legendary", price: 820 },
  { id: "wool-cosmos", cat: "sheep", name: "Космическая отара", desc: "Ночное небо вместо шерсти.", rarity: "exotic", price: 1680 },
  { id: "veg-cabbage", cat: "vegetable", name: "Капуста", desc: "Обычные кочаны.", rarity: "common", price: 0 },
  { id: "veg-pumpkin", cat: "vegetable", name: "Тыквы", desc: "Круглые оранжевые тыквы.", rarity: "uncommon", price: 90 },
  { id: "veg-crystal", cat: "vegetable", name: "Кристаллическая капуста", desc: "Гранёные светящиеся кочаны.", rarity: "rare", price: 240 },
  { id: "veg-melon", cat: "vegetable", name: "Неоновые дыни", desc: "Полосатые плоды с ярким контуром.", rarity: "epic", price: 520 },
  { id: "veg-star", cat: "vegetable", name: "Звёздные плоды", desc: "Парящие плоды с ореолом.", rarity: "exotic", price: 1600 },
  { id: "fence-wood", cat: "fence", name: "Дерево", desc: "Доски и верёвка.", rarity: "common", price: 0 },
  { id: "fence-metal", cat: "fence", name: "Металл", desc: "Прутья и клёпки.", rarity: "uncommon", price: 140 },
  { id: "fence-neon", cat: "fence", name: "Светящийся контур", desc: "Неоновые дуги вместо досок.", rarity: "epic", price: 560 },
  { id: "fence-rune", cat: "fence", name: "Рунический камень", desc: "Плиты с пульсирующими знаками.", rarity: "exotic", price: 1760 },
  { id: "wskin-plain", cat: "weapon", name: "Как есть", desc: "Обычный вид оружия. Без бонусов.", rarity: "common", price: 0 },
  { id: "wskin-sakura", cat: "weapon", name: "Сакура", desc: "Розовый металл и лепестки на взмахе.", rarity: "rare", price: 220 },
  { id: "wskin-night", cat: "weapon", name: "Полночь", desc: "Тёмный металл и синий след.", rarity: "epic", price: 460 },
  { id: "wskin-gold", cat: "weapon", name: "Золотой лист", desc: "Золотая окантовка. Только вид.", rarity: "legendary", price: 960 },
  { id: "wskin-void", cat: "weapon", name: "Пустотный след", desc: "Фиолетовое свечение ударов и пуль.", rarity: "exotic", price: 1880 },
  { id: "sky-day", cat: "sky", name: "Дневное", desc: "Ясное голубое небо и солнце.", rarity: "common", price: 0 },
  { id: "sky-sunset", cat: "sky", name: "Закат", desc: "Тёплое небо и длинные тени.", rarity: "uncommon", price: 110 },
  { id: "sky-night", cat: "sky", name: "Ночь", desc: "Луна и тёмная заливка луга.", rarity: "rare", price: 200 },
  { id: "sky-stars", cat: "sky", name: "Звёздное", desc: "Густые мигающие звёзды.", rarity: "epic", price: 480 },
  { id: "sky-cosmos", cat: "sky", name: "Космос", desc: "Туманности вместо облаков.", rarity: "legendary", price: 920 },
  { id: "sky-aurora", cat: "sky", name: "Полярное сияние", desc: "Движущиеся ленты света.", rarity: "exotic", price: 1980 },
  { id: "env-summer", cat: "environment", name: "Лето", desc: "Зелёный луг.", rarity: "common", price: 0 },
  { id: "env-autumn", cat: "environment", name: "Осень", desc: "Рыжая трава и падающие листья.", rarity: "uncommon", price: 120 },
  { id: "env-snow", cat: "environment", name: "Снег", desc: "Бледный луг и снежинки.", rarity: "rare", price: 260 },
  { id: "env-blossom", cat: "environment", name: "Цветение", desc: "Лепестки над зелёной травой.", rarity: "epic", price: 540 },
  { id: "fx-wool", cat: "fx", name: "Клочья шерсти", desc: "Овцы разлетаются шерстью.", rarity: "common", price: 0 },
  { id: "fx-petals", cat: "fx", name: "Лепестки", desc: "Удары поднимают лепестки.", rarity: "uncommon", price: 100 },
  { id: "fx-sparks", cat: "fx", name: "Искры", desc: "Искры на попаданиях.", rarity: "rare", price: 220 },
  { id: "fx-soft", cat: "fx", name: "Тихие вспышки", desc: "Меньше частиц, тот же урон.", rarity: "common", price: 40 },
];

export const RARITY_LABEL: Record<Rarity, string> = {
  common: "Обычная",
  uncommon: "Необычная",
  rare: "Редкая",
  epic: "Эпическая",
  legendary: "Легендарная",
  exotic: "Экзотическая",
};

export const CAT_LABEL: Record<CosmeticCat, string> = {
  sheep: "Овцы",
  vegetable: "Овощи",
  fence: "Забор",
  weapon: "Оружие",
  sky: "Небо",
  environment: "Окружение",
  fx: "Эффекты",
};

export const CATS: CosmeticCat[] = [
  "sheep",
  "vegetable",
  "fence",
  "weapon",
  "sky",
  "environment",
  "fx",
];

export function weaponById(id: string): WeaponDef {
  return WEAPONS.find((w) => w.id === id) ?? WEAPONS[0]!;
}

export function cosmeticById(id: string): CosmeticDef | undefined {
  return COSMETICS.find((c) => c.id === id);
}

export function gearIndex(unlocked: Record<string, { unlocked: boolean }>): number {
  let best = 0;
  WEAPONS.forEach((w, i) => {
    if (unlocked[w.id]?.unlocked) best = i;
  });
  return best;
}

export function waveScale(wave: number, gear: number) {
  const t = Math.max(0, (wave - 1) * 0.78 - gear * 0.42);
  return {
    hp: 1 + t * 0.1,
    dmg: 1 + t * 0.055,
    speed: 1 + Math.min(0.26, t * 0.018),
    fence: 1 + t * 0.07,
    intel: Math.min(0.34, wave * 0.022),
  };
}

export function waveMods(wave: number): { name: string; hp: number; speed: number }[] {
  const mods: { name: string; hp: number; speed: number }[] = [];
  if (wave % 3 === 0) mods.push({ name: "Густая шерсть", hp: 1.16, speed: 1 });
  if (wave % 4 === 0) mods.push({ name: "Порыв", hp: 1, speed: 1.12 });
  if (wave % 5 === 0) mods.push({ name: "Вожак", hp: 1, speed: 1 });
  return mods;
}

export function rollWave(wave: number, rng: () => number): SheepKind[] {
  const n = Math.min(16, 4 + Math.floor(wave * 1.05));
  const table: [SheepKind, number][] = [
    ["normal", 8],
    ["fast", wave >= 2 ? 5 : 0],
    ["armored", wave >= 3 ? 4 : 0],
    ["cunning", wave >= 4 ? 4 : 0],
    ["breaker", wave >= 5 ? 3.4 : 0],
    ["tactician", wave >= 7 ? 3 : 0],
  ];
  const sum = table.reduce((a, [, w]) => a + w, 0);
  const out: SheepKind[] = [];
  for (let i = 0; i < n; i++) {
    let r = rng() * sum;
    let pick: SheepKind = "normal";
    for (const [k, w] of table) {
      r -= w;
      if (r <= 0) {
        pick = k;
        break;
      }
    }
    out.push(pick);
  }
  const feature: SheepKind | null =
    wave >= 7 ? "tactician" : wave >= 5 ? "breaker" : wave >= 4 ? "cunning" : wave >= 3 ? "armored" : wave >= 2 ? "fast" : null;
  if (feature && !out.includes(feature)) out[out.length - 1] = feature;
  if (wave % 5 === 0) out.push("boss");
  return out;
}

export function coinReward(
  kind: SheepKind,
  intel: number,
  maxHp: number,
  dmg: number,
  speed: number,
  wave: number,
): number {
  const base = KINDS[kind].coins;
  const intelM = 0.72 + intel;
  const bulk = 0.78 + Math.min(0.65, maxHp / 220);
  const danger = 0.86 + Math.min(0.7, (dmg * speed) / 4200);
  const waveM = 1 + (wave - 1) * 0.055;
  const bossM = kind === "boss" ? 1.25 : 1;
  return Math.max(1, Math.round(base * intelM * bulk * danger * waveM * bossM));
}

export function weaponRepairCost(def: WeaponDef, durability: number, fraction: number): number {
  const missing = Math.max(0, def.durability - durability);
  const portion = missing * fraction;
  if (portion <= 0.01) return 0;
  return Math.max(1, Math.ceil(def.repair * (portion / def.durability)));
}

export function ammoPackCost(def: WeaponDef): number {
  return Math.max(8, Math.round(10 + def.unlock * 0.032));
}

export function structureRepairCost(missing: number): number {
  if (missing <= 0) return 0;
  return Math.max(1, Math.ceil(missing * 0.32));
}

export const SPAWNS = [
  { x: 1100, y: 250 },
  { x: 1100, y: 1410 },
  { x: 280, y: 820 },
  { x: 1920, y: 820 },
  { x: 360, y: 300 },
  { x: 1840, y: 320 },
  { x: 360, y: 1340 },
  { x: 1840, y: 1320 },
];

export const OBSTACLES: { x: number; y: number; r: number; kind: "tree" | "rock" | "bush" }[] = [
  { x: 320, y: 300, r: 46, kind: "tree" },
  { x: 500, y: 460, r: 40, kind: "tree" },
  { x: 380, y: 580, r: 28, kind: "bush" },
  { x: 640, y: 340, r: 20, kind: "rock" },
  { x: 720, y: 520, r: 18, kind: "rock" },
  { x: 1680, y: 280, r: 48, kind: "tree" },
  { x: 1880, y: 460, r: 36, kind: "tree" },
  { x: 1500, y: 420, r: 42, kind: "tree" },
  { x: 1600, y: 560, r: 18, kind: "rock" },
  { x: 1780, y: 250, r: 16, kind: "bush" },
  { x: 340, y: 1220, r: 44, kind: "tree" },
  { x: 540, y: 1360, r: 34, kind: "tree" },
  { x: 700, y: 1200, r: 38, kind: "tree" },
  { x: 420, y: 1100, r: 20, kind: "rock" },
  { x: 250, y: 1320, r: 16, kind: "bush" },
  { x: 1700, y: 1200, r: 46, kind: "tree" },
  { x: 1880, y: 1340, r: 34, kind: "tree" },
  { x: 1520, y: 1300, r: 40, kind: "tree" },
  { x: 1640, y: 1120, r: 18, kind: "rock" },
  { x: 1860, y: 1160, r: 16, kind: "bush" },
];
