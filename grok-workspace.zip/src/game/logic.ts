import {
  GEO,
  KINDS,
  OBSTACLES,
  PLAYER_HP,
  PLAYER_R,
  PLAYER_SPEED,
  SPAWNS,
  WEAPONS,
  coinReward,
  gearIndex,
  rollWave,
  structureRepairCost,
  waveMods,
  waveScale,
  weaponById,
  type SheepKind,
  type Side,
  type WeaponDef,
} from "./content";
import {
  emptyRunStats,
  type RunSave,
  type RunStats,
  type SaveData,
} from "./save";
import type { Sfx } from "./audio";
import {
  tryBuyAmmo,
  tryBuyCosmetic,
  tryBuyWeapon,
  tryEquipCosmetic,
  tryEquipWeapon,
  tryRepairWeapon,
} from "./market";

export interface Fence {
  id: number;
  side: Side;
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  maxHp: number;
  isGate: boolean;
  open: boolean;
}

export interface Crop {
  x: number;
  y: number;
  hp: number;
  maxHp: number;
}

export interface Obstacle {
  x: number;
  y: number;
  r: number;
  kind: "tree" | "rock" | "bush";
}

export interface Sheep {
  id: number;
  kind: SheepKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  speed: number;
  dmg: number;
  fenceDps: number;
  intel: number;
  aggr: number;
  detect: number;
  radius: number;
  seed: number;
  face: number;
  phase: number;
  mode: "enter" | "smash" | "eat" | "decoy" | "evade" | "chase" | "flank";
  goalX: number;
  goalY: number;
  targetFence: number;
  path: { x: number; y: number }[] | null;
  pathI: number;
  think: number;
  stuck: number;
  lastX: number;
  lastY: number;
  frustrated: number;
  evadeT: number;
  stunT: number;
  attackCd: number;
  hitFlash: number;
  dead: boolean;
  fade: number;
  rewarded: boolean;
  chargeT: number;
  boss: boolean;
}

export interface Bullet {
  x: number;
  y: number;
  px: number;
  py: number;
  vx: number;
  vy: number;
  dmg: number;
  r: number;
  life: number;
  pierce: number;
  hit: number[];
  knock: number;
  stun: number;
  color: string;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  color: string;
}

export interface Floater {
  x: number;
  y: number;
  text: string;
  life: number;
  color: string;
}

export interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  aim: number;
  cd: number;
  swing: number;
  swingDur: number;
  swingDir: number;
  swingHits: number[];
  reload: number;
  iFrame: number;
  bob: number;
  hurt: number;
}

export interface InputState {
  mx: number;
  my: number;
  aimX: number;
  aimY: number;
  aimOk: boolean;
  attackHeld: boolean;
  attackEdge: boolean;
  interactEdge: boolean;
  reloadEdge: boolean;
  slot: number | null;
  cycle: number;
  assist: boolean;
}

export interface Match {
  save: SaveData;
  time: number;
  phase: "combat" | "intermission" | "defeat";
  paused: boolean;
  wave: number;
  countdown: number;
  player: Player;
  sheep: Sheep[];
  fences: Fence[];
  crops: Crop[];
  obstacles: Obstacle[];
  bullets: Bullet[];
  particles: Particle[];
  floaters: Floater[];
  herd: { decoyId: number | null; avoidSide: Side | null };
  nav: Uint8Array;
  cols: number;
  rows: number;
  navDirty: boolean;
  spawnQ: SheepKind[];
  spawnT: number;
  spawnI: number;
  nextId: number;
  rng: () => number;
  cam: { x: number; y: number; shake: number };
  view: { w: number; h: number };
  input: InputState;
  prompt: string | null;
  alert: "garden" | "fence" | "boss" | null;
  mods: { name: string; hp: number; speed: number }[];
  run: RunStats;
  cropMax: number;
  hitStop: number;
  toast: string | null;
  toastT: number;
  result: Result | null;
  sfx?: (n: Sfx) => void;
  autosave: number;
}

export interface Result {
  wave: number;
  kills: number;
  earned: number;
  bestName: string;
  weaponName: string;
  garden: number;
}

export interface Snapshot {
  phase: Match["phase"];
  paused: boolean;
  coins: number;
  wave: number;
  countdown: number;
  playerHp: number;
  playerMax: number;
  garden: number;
  weaponId: string;
  weaponName: string;
  durability: number;
  durabilityMax: number;
  broken: boolean;
  warn: boolean;
  loaded: number | null;
  reserve: number | null;
  mag: number;
  reloading: boolean;
  bossHp: number | null;
  bossMax: number | null;
  bossName: string | null;
  alert: Match["alert"];
  prompt: string | null;
  toast: string | null;
  mods: string[];
  kills: number;
  earned: number;
  result: Result | null;
  fenceMissing: number;
  cropMissing: number;
  runActive: boolean;
}

const CELL = GEO.cell;

function mulberry(seed: number) {
  let a = seed >>> 0 || 1;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function blankInput(): InputState {
  return {
    mx: 0,
    my: 0,
    aimX: 0,
    aimY: 0,
    aimOk: false,
    attackHeld: false,
    attackEdge: false,
    interactEdge: false,
    reloadEdge: false,
    slot: null,
    cycle: 0,
    assist: false,
  };
}

function makePlayer(x = 1100, y = 1260, hp = PLAYER_HP): Player {
  return {
    x,
    y,
    vx: 0,
    vy: 0,
    hp,
    aim: -Math.PI / 2,
    cd: 0,
    swing: 0,
    swingDur: 0,
    swingDir: -Math.PI / 2,
    swingHits: [],
    reload: 0,
    iFrame: 0,
    bob: 0,
    hurt: 0,
  };
}

function buildFences(): Fence[] {
  const g = GEO.garden;
  const t = GEO.fenceT;
  const gate = GEO.gate;
  const o = { x: g.x - t, y: g.y - t, w: g.w + t * 2, h: g.h + t * 2 };
  const list: Fence[] = [];
  const add = (side: Side, x: number, y: number, w: number, h: number, isGate: boolean) => {
    const maxHp = isGate ? 100 : 160;
    list.push({ id: list.length, side, x, y, w, h, hp: maxHp, maxHp, isGate, open: false });
  };
  const gx = o.x + (o.w - gate) / 2;
  const gy = o.y + (o.h - gate) / 2;
  add("n", o.x, o.y, gx - o.x, t, false);
  add("n", gx, o.y, gate, t, true);
  add("n", gx + gate, o.y, o.x + o.w - (gx + gate), t, false);
  add("s", o.x, o.y + o.h - t, gx - o.x, t, false);
  add("s", gx, o.y + o.h - t, gate, t, true);
  add("s", gx + gate, o.y + o.h - t, o.x + o.w - (gx + gate), t, false);
  const innerTop = o.y + t;
  const topH = gy - innerTop;
  const botY = gy + gate;
  const botH = o.y + o.h - t - botY;
  add("w", o.x, innerTop, t, topH, false);
  add("w", o.x, gy, t, gate, true);
  add("w", o.x, botY, t, botH, false);
  add("e", o.x + o.w - t, innerTop, t, topH, false);
  add("e", o.x + o.w - t, gy, t, gate, true);
  add("e", o.x + o.w - t, botY, t, botH, false);
  return list;
}

function buildCrops(): Crop[] {
  const g = GEO.garden;
  const crops: Crop[] = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 5; c++) {
      crops.push({ x: g.x + 80 + c * 120, y: g.y + 78 + r * 112, hp: 34, maxHp: 34 });
    }
  }
  return crops;
}

export function createMatch(save: SaveData, mode: "new" | "continue"): Match | null {
  const fences = buildFences();
  const crops = buildCrops();
  if (mode === "continue") {
    if (!save.run) return null;
    if (save.run.fences.length !== fences.length || save.run.crops.length !== crops.length) {
      save.run = null;
      return null;
    }
  }
  const cols = Math.ceil(GEO.worldW / CELL);
  const rows = Math.ceil(GEO.worldH / CELL);
  const match: Match = {
    save,
    time: 0,
    phase: "combat",
    paused: false,
    wave: 1,
    countdown: 2.4,
    player: makePlayer(),
    sheep: [],
    fences,
    crops,
    obstacles: OBSTACLES.map((o) => ({ ...o })),
    bullets: [],
    particles: [],
    floaters: [],
    herd: { decoyId: null, avoidSide: null },
    nav: new Uint8Array(cols * rows),
    cols,
    rows,
    navDirty: true,
    spawnQ: [],
    spawnT: 0.4,
    spawnI: 0,
    nextId: 1,
    rng: mulberry((Date.now() ^ (save.stats.runs * 997)) >>> 0),
    cam: { x: 0, y: 0, shake: 0 },
    view: { w: 800, h: 600 },
    input: blankInput(),
    prompt: null,
    alert: null,
    mods: [],
    run: emptyRunStats(),
    cropMax: crops.reduce((a, c) => a + c.maxHp, 0),
    hitStop: 0,
    toast: null,
    toastT: 0,
    result: null,
    autosave: 0,
  };
  if (mode === "continue" && save.run) applyRun(match, save.run);
  else {
    save.stats.runs += 1;
    beginWave(match, 1, false);
    snapCam(match);
  }
  rebuildNav(match);
  return match;
}

function applyRun(match: Match, run: RunSave) {
  match.wave = run.wave;
  match.phase = run.phase;
  match.countdown = run.countdown;
  match.player = makePlayer(run.player.x, run.player.y, run.player.hp);
  match.player.aim = run.player.aim;
  run.fences.forEach((f, i) => {
    const fence = match.fences[i];
    if (!fence) return;
    fence.hp = Math.min(fence.maxHp, f.hp);
    fence.open = f.open && fence.isGate && fence.hp > 0;
  });
  run.crops.forEach((hp, i) => {
    const c = match.crops[i];
    if (c) c.hp = Math.min(c.maxHp, hp);
  });
  match.spawnQ = [...run.spawnQ];
  match.spawnT = run.spawnT;
  match.run = {
    ...run.stats,
    weaponUse: { ...emptyRunStats().weaponUse, ...run.stats.weaponUse },
  };
  match.mods = waveMods(run.wave);
  const scale = scaleOf(match);
  for (const s of run.sheep) {
    if (s.hp <= 0) continue;
    match.sheep.push(makeSheep(match, s.kind, s.x, s.y, scale, s.hp, s.seed));
  }
  snapCam(match);
}

function snapCam(match: Match) {
  const p = match.player;
  match.cam.x = clamp(p.x - match.view.w / 2, 0, Math.max(0, GEO.worldW - match.view.w));
  match.cam.y = clamp(p.y - match.view.h / 2, 0, Math.max(0, GEO.worldH - match.view.h));
}

function scaleOf(match: Match) {
  const gear = gearIndex(match.save.weapons);
  const s = waveScale(match.wave, gear);
  let hp = s.hp;
  let speed = s.speed;
  for (const m of match.mods) {
    hp *= m.hp;
    speed *= m.speed;
  }
  return { ...s, hp, speed };
}

function beginWave(match: Match, wave: number, heal: boolean) {
  match.wave = wave;
  match.phase = "combat";
  match.countdown = 2.3;
  match.mods = waveMods(wave);
  match.spawnQ = rollWave(wave, match.rng);
  match.spawnT = 0.35;
  match.sheep = [];
  match.bullets = [];
  match.save.stats.bestWave = Math.max(match.save.stats.bestWave, wave);
  if (heal) match.player.hp = Math.min(PLAYER_HP, match.player.hp + 18);
  toast(match, wave % 5 === 0 ? `Волна ${wave}: вожак` : `Волна ${wave}`);
  match.sfx?.("wave");
}

export function nextWave(match: Match) {
  if (match.phase !== "intermission") return;
  beginWave(match, match.wave + 1, true);
}

function toast(match: Match, text: string) {
  match.toast = text;
  match.toastT = 2.4;
}

function center(f: Fence) {
  return { x: f.x + f.w / 2, y: f.y + f.h / 2 };
}

export function fenceSolid(f: Fence) {
  return f.hp > 0 && !(f.isGate && f.open);
}

function insideGarden(x: number, y: number) {
  const g = GEO.garden;
  return x > g.x && y > g.y && x < g.x + g.w && y < g.y + g.h;
}

function outward(f: Fence, dist: number) {
  const c = center(f);
  const gcx = GEO.garden.x + GEO.garden.w / 2;
  const gcy = GEO.garden.y + GEO.garden.h / 2;
  const dx = c.x - gcx;
  const dy = c.y - gcy;
  const len = Math.hypot(dx, dy) || 1;
  return { x: c.x + (dx / len) * dist, y: c.y + (dy / len) * dist };
}

function inward(f: Fence, dist: number) {
  const c = center(f);
  const gcx = GEO.garden.x + GEO.garden.w / 2;
  const gcy = GEO.garden.y + GEO.garden.h / 2;
  const dx = gcx - c.x;
  const dy = gcy - c.y;
  const len = Math.hypot(dx, dy) || 1;
  return { x: c.x + (dx / len) * dist, y: c.y + (dy / len) * dist };
}

function circleHitsRect(px: number, py: number, rad: number, r: Fence) {
  const cx = Math.max(r.x, Math.min(px, r.x + r.w));
  const cy = Math.max(r.y, Math.min(py, r.y + r.h));
  return (px - cx) ** 2 + (py - cy) ** 2 < rad * rad;
}

function blockedAt(match: Match, x: number, y: number, rad: number) {
  const isl = GEO.island;
  if (x - rad < isl.x || y - rad < isl.y || x + rad > isl.x + isl.w || y + rad > isl.y + isl.h) return true;
  for (const o of match.obstacles) {
    if ((x - o.x) ** 2 + (y - o.y) ** 2 < (rad + o.r - 6) ** 2) return true;
  }
  for (const f of match.fences) {
    if (fenceSolid(f) && circleHitsRect(x, y, rad, f)) return true;
  }
  return false;
}

function moveBody(match: Match, x: number, y: number, rad: number, dx: number, dy: number) {
  let nx = x + dx;
  let ny = y;
  if (blockedAt(match, nx, ny, rad)) nx = x;
  ny = y + dy;
  if (blockedAt(match, nx, ny, rad)) ny = y;
  if (nx === x && ny === y && (dx !== 0 || dy !== 0)) {
    nx = x + dy * 0.6;
    ny = y - dx * 0.6;
    if (blockedAt(match, nx, ny, rad)) {
      nx = x;
      ny = y;
    }
  }
  return { x: nx, y: ny };
}

function rebuildNav(match: Match) {
  const { cols, rows, nav } = match;
  nav.fill(0);
  const isl = GEO.island;
  const pad = 10;
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const cx = i * CELL + CELL / 2;
      const cy = j * CELL + CELL / 2;
      let block = cx < isl.x + 20 || cy < isl.y + 20 || cx > isl.x + isl.w - 20 || cy > isl.y + isl.h - 20;
      if (!block) {
        for (const o of match.obstacles) {
          if ((cx - o.x) ** 2 + (cy - o.y) ** 2 < (o.r + 8) ** 2) {
            block = true;
            break;
          }
        }
      }
      if (!block) {
        for (const f of match.fences) {
          if (!fenceSolid(f)) continue;
          if (cx > f.x - pad && cx < f.x + f.w + pad && cy > f.y - pad && cy < f.y + f.h + pad) {
            block = true;
            break;
          }
        }
      }
      if (block) nav[i + j * cols] = 1;
    }
  }
  match.navDirty = false;
  for (const s of match.sheep) s.path = null;
}

function nearestFree(match: Match, x: number, y: number) {
  let i = clamp(Math.floor(x / CELL), 0, match.cols - 1);
  let j = clamp(Math.floor(y / CELL), 0, match.rows - 1);
  const { cols, rows, nav } = match;
  if (!nav[i + j * cols]) return { i, j };
  for (let rad = 1; rad <= 14; rad++) {
    for (let oy = -rad; oy <= rad; oy++) {
      for (let ox = -rad; ox <= rad; ox++) {
        if (Math.max(Math.abs(ox), Math.abs(oy)) !== rad) continue;
        const ni = i + ox;
        const nj = j + oy;
        if (ni < 0 || nj < 0 || ni >= cols || nj >= rows) continue;
        if (!nav[ni + nj * cols]) return { i: ni, j: nj };
      }
    }
  }
  return null;
}

function astar(match: Match, x0: number, y0: number, x1: number, y1: number) {
  const start = nearestFree(match, x0, y0);
  const goal = nearestFree(match, x1, y1);
  if (!start || !goal) return null;
  const { cols, rows, nav } = match;
  const s = start.i + start.j * cols;
  const g = goal.i + goal.j * cols;
  if (s === g) return [{ x: x1, y: y1 }];
  const n = cols * rows;
  const gs = new Float32Array(n);
  const fs = new Float32Array(n);
  const came = new Int32Array(n);
  const closed = new Uint8Array(n);
  gs.fill(Infinity);
  fs.fill(Infinity);
  came.fill(-1);
  gs[s] = 0;
  fs[s] = Math.hypot(start.i - goal.i, start.j - goal.j);
  const open = [s];
  let guard = 0;
  while (open.length && guard++ < n) {
    let bi = 0;
    let bf = fs[open[0]!]!;
    for (let k = 1; k < open.length; k++) {
      const f = fs[open[k]!]!;
      if (f < bf) {
        bf = f;
        bi = k;
      }
    }
    const cur = open[bi]!;
    open.splice(bi, 1);
    if (closed[cur]) continue;
    if (cur === g) {
      const pts: { x: number; y: number }[] = [];
      let c = g;
      while (c !== -1) {
        const i = c % cols;
        const j = (c / cols) | 0;
        pts.push({ x: i * CELL + CELL / 2, y: j * CELL + CELL / 2 });
        if (c === s) break;
        c = came[c]!;
      }
      pts.reverse();
      return pts;
    }
    closed[cur] = 1;
    const ci = cur % cols;
    const cj = (cur / cols) | 0;
    for (let oy = -1; oy <= 1; oy++) {
      for (let ox = -1; ox <= 1; ox++) {
        if (!ox && !oy) continue;
        const ni = ci + ox;
        const nj = cj + oy;
        if (ni < 0 || nj < 0 || ni >= cols || nj >= rows) continue;
        const nid = ni + nj * cols;
        if (nav[nid] || closed[nid]) continue;
        if (ox && oy && (nav[ci + ox + cj * cols] || nav[ci + (cj + oy) * cols])) continue;
        const step = ox && oy ? 1.414 : 1;
        const ng = gs[cur]! + step;
        if (ng < gs[nid]!) {
          gs[nid] = ng;
          came[nid] = cur;
          fs[nid] = ng + Math.hypot(ni - goal.i, nj - goal.j);
          open.push(nid);
        }
      }
    }
  }
  return null;
}

function hasPassage(match: Match) {
  return match.fences.some((f) => f.hp <= 0 || (f.isGate && f.open));
}

function passages(match: Match) {
  return match.fences.filter((f) => f.hp <= 0 || (f.isGate && f.open));
}

function sideOf(x: number, y: number): Side {
  const g = GEO.garden;
  const dx = x - (g.x + g.w / 2);
  const dy = y - (g.y + g.h / 2);
  if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? "e" : "w";
  return dy > 0 ? "s" : "n";
}

function dist(ax: number, ay: number, bx: number, by: number) {
  return Math.hypot(ax - bx, ay - by);
}

function thinkSheep(match: Match, sheep: Sheep) {
  const p = match.player;
  const inside = insideGarden(sheep.x, sheep.y);
  if (sheep.hp < sheep.maxHp * 0.32 && sheep.aggr < 0.55 && dist(sheep.x, sheep.y, p.x, p.y) < sheep.detect) {
    sheep.mode = "evade";
    sheep.evadeT = 1.3 + sheep.intel;
    const dx = sheep.x - p.x;
    const dy = sheep.y - p.y;
    const len = Math.hypot(dx, dy) || 1;
    sheep.goalX = sheep.x + (dx / len) * 180;
    sheep.goalY = sheep.y + (dy / len) * 180;
    sheep.path = astar(match, sheep.x, sheep.y, sheep.goalX, sheep.goalY);
    sheep.pathI = 0;
    return;
  }
  if (inside) {
    sheep.mode = "eat";
    let best: Crop | null = null;
    let bd = 1e9;
    for (const c of match.crops) {
      if (c.hp <= 0) continue;
      const d = dist(sheep.x, sheep.y, c.x, c.y);
      if (d < bd) {
        bd = d;
        best = c;
      }
    }
    if (best) {
      sheep.goalX = best.x;
      sheep.goalY = best.y;
    }
    sheep.path = null;
    return;
  }
  if (sheep.id === match.herd.decoyId && sheep.hp > sheep.maxHp * 0.35) {
    sheep.mode = "decoy";
    const ang = Math.atan2(sheep.y - p.y, sheep.x - p.x) + Math.sin(match.time * 1.3 + sheep.seed) * 0.9;
    sheep.goalX = p.x + Math.cos(ang) * 168;
    sheep.goalY = p.y + Math.sin(ang) * 168;
    sheep.path = astar(match, sheep.x, sheep.y, sheep.goalX, sheep.goalY);
    sheep.pathI = 0;
    return;
  }
  const open = passages(match);
  const pd = dist(sheep.x, sheep.y, p.x, p.y);
  const wantChase =
    sheep.chargeT > 0 ||
    (pd < sheep.detect &&
      sheep.aggr > 0.6 &&
      sheep.hp > sheep.maxHp * 0.45 &&
      (sheep.kind === "boss" || sheep.kind === "armored" || (sheep.kind === "tactician" && sheep.id !== match.herd.decoyId && pd < 90)));
  if (wantChase && sheep.kind !== "fast" && sheep.kind !== "cunning") {
    sheep.mode = "chase";
    const lead = sheep.kind === "boss" ? 0.25 : 0;
    sheep.goalX = p.x + p.vx * lead;
    sheep.goalY = p.y + p.vy * lead;
    sheep.path = astar(match, sheep.x, sheep.y, sheep.goalX, sheep.goalY);
    sheep.pathI = 0;
    return;
  }
  if (sheep.kind === "fast" && open.length === 0 && sheep.frustrated < 4) {
    sheep.mode = "flank";
    const gates = match.fences.filter((f) => f.isGate);
    const idx = (Math.floor(match.time * 0.35 + sheep.seed) + sheep.id) % Math.max(1, gates.length);
    const g = gates[idx];
    if (g) {
      const pt = outward(g, 78);
      sheep.goalX = pt.x;
      sheep.goalY = pt.y;
      sheep.targetFence = g.id;
      sheep.path = astar(match, sheep.x, sheep.y, pt.x, pt.y);
      sheep.pathI = 0;
      return;
    }
  }
  if (open.length === 0) {
    const fence = pickFence(match, sheep, true);
    const pt = outward(fence, 64);
    sheep.mode = "smash";
    sheep.targetFence = fence.id;
    sheep.goalX = pt.x;
    sheep.goalY = pt.y;
    sheep.path = astar(match, sheep.x, sheep.y, pt.x, pt.y);
    sheep.pathI = 0;
    return;
  }
  const fence = pickEntry(match, sheep, open);
  const pt = inward(fence, 78);
  sheep.mode = "enter";
  sheep.targetFence = fence.id;
  sheep.goalX = pt.x;
  sheep.goalY = pt.y;
  sheep.path = astar(match, sheep.x, sheep.y, pt.x, pt.y);
  sheep.pathI = 0;
}

function pickFence(match: Match, sheep: Sheep, _closedOnly: boolean) {
  let best = match.fences[0]!;
  let score = Infinity;
  for (const f of match.fences) {
    if (!fenceSolid(f) && sheep.kind === "breaker") continue;
    if (f.hp <= 0) continue;
    const c = center(f);
    const d = dist(sheep.x, sheep.y, c.x, c.y);
    const ratio = f.hp / f.maxHp;
    const gateBias = f.isGate ? 0.18 : 0;
    const noise = ((sheep.seed + f.id * 17) % 10) * 0.004;
    const s =
      sheep.kind === "breaker"
        ? ratio - gateBias * 0.4 + d * 0.00025 + noise
        : sheep.kind === "armored" || sheep.kind === "boss"
          ? d * 0.001 + ratio * 0.2 - (f.isGate ? 0.05 : 0)
          : d * 0.001 + (f.isGate ? 0 : 0.35);
    if (s < score) {
      score = s;
      best = f;
    }
  }
  return best;
}

function pickEntry(match: Match, sheep: Sheep, open: Fence[]) {
  const list = open.length ? open : match.fences.filter((f) => f.isGate);
  if (sheep.kind === "normal" || sheep.intel < 0.4) {
    let best = list[0]!;
    let bd = Infinity;
    for (const f of list) {
      const c = center(f);
      let d = dist(sheep.x, sheep.y, c.x, c.y);
      if (!(f.hp <= 0 || (f.isGate && f.open))) d += 240;
      if (d < bd) {
        bd = d;
        best = f;
      }
    }
    return best;
  }
  let best = list[0]!;
  let bc = Infinity;
  for (const f of list) {
    if (match.herd.avoidSide === f.side && sheep.intel > 0.55 && list.length > 1) continue;
    const pt = f.hp <= 0 || (f.isGate && f.open) ? inward(f, 78) : outward(f, 64);
    const path = astar(match, sheep.x, sheep.y, pt.x, pt.y);
    let cost = path ? path.length : 400;
    const c = center(f);
    const pd = dist(match.player.x, match.player.y, c.x, c.y);
    if (pd < 200 && (sheep.kind === "cunning" || sheep.kind === "tactician" || sheep.kind === "fast")) {
      cost += (200 - pd) * 0.08;
    }
    const predX = match.player.x + match.player.vx * 0.45;
    const predY = match.player.y + match.player.vy * 0.45;
    if (sheep.kind === "cunning") cost += Math.max(0, 160 - dist(predX, predY, c.x, c.y)) * 0.05;
    cost *= 0.9 + ((sheep.seed + f.id * 13) % 17) / 100;
    if (cost < bc) {
      bc = cost;
      best = f;
    }
  }
  return best;
}

function updateHerd(match: Match) {
  const alive = match.sheep.filter((s) => !s.dead);
  const tacs = alive.filter((s) => s.kind === "tactician");
  if (tacs.length && alive.length >= 3 && !insideGarden(match.player.x, match.player.y)) {
    let decoy = tacs[0]!;
    let bd = Infinity;
    for (const t of tacs) {
      const d = dist(t.x, t.y, match.player.x, match.player.y);
      if (d < bd) {
        bd = d;
        decoy = t;
      }
    }
    match.herd.decoyId = decoy.id;
    match.herd.avoidSide = sideOf(match.player.x, match.player.y);
  } else {
    match.herd.decoyId = null;
    match.herd.avoidSide = null;
  }
}

function makeSheep(
  match: Match,
  kind: SheepKind,
  x: number,
  y: number,
  scale: ReturnType<typeof scaleOf>,
  hpOverride?: number,
  seedOverride?: number,
): Sheep {
  const def = KINDS[kind];
  const seed = seedOverride ?? Math.floor(match.rng() * 1e9);
  const jitter = 0.9 + match.rng() * 0.2;
  const maxHp = def.hp * scale.hp * (kind === "boss" ? 1 : jitter);
  return {
    id: match.nextId++,
    kind,
    x,
    y,
    vx: 0,
    vy: 0,
    hp: hpOverride ?? maxHp,
    maxHp,
    speed: Math.min(205, def.speed * scale.speed * (0.94 + match.rng() * 0.12)),
    dmg: def.dmg * scale.dmg,
    fenceDps: def.fence * scale.fence,
    intel: clamp(def.intel + scale.intel + (match.rng() - 0.5) * 0.08, 0.05, 1),
    aggr: clamp(def.aggr + (match.rng() - 0.5) * 0.1, 0.05, 1),
    detect: def.detect,
    radius: def.radius,
    seed,
    face: Math.PI / 2,
    phase: match.rng() * 10,
    mode: "enter",
    goalX: x,
    goalY: y + 10,
    targetFence: -1,
    path: null,
    pathI: 0,
    think: match.rng() * 0.3,
    stuck: 0,
    lastX: x,
    lastY: y,
    frustrated: 0,
    evadeT: 0,
    stunT: 0,
    attackCd: 0.4,
    hitFlash: 0,
    dead: false,
    fade: 0,
    rewarded: false,
    chargeT: 0,
    boss: kind === "boss",
  };
}

function spawnSheep(match: Match) {
  const kind = match.spawnQ.shift();
  if (!kind) return;
  const scale = scaleOf(match);
  let spot = SPAWNS[match.spawnI % SPAWNS.length]!;
  match.spawnI++;
  let x = spot.x;
  let y = spot.y;
  const rad = KINDS[kind].radius;
  if (blockedAt(match, x, y, rad)) {
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2;
      const nx = spot.x + Math.cos(a) * 48;
      const ny = spot.y + Math.sin(a) * 48;
      if (!blockedAt(match, nx, ny, rad)) {
        x = nx;
        y = ny;
        break;
      }
    }
  }
  const sheep = makeSheep(match, kind, x, y, scale);
  match.sheep.push(sheep);
  if (kind === "boss") {
    toast(match, "Вожак вышел на луг");
    match.sfx?.("wave");
  }
}

function separation(match: Match, sheep: Sheep) {
  let sx = 0;
  let sy = 0;
  const rad = sheep.radius + 20;
  for (const o of match.sheep) {
    if (o === sheep || o.dead) continue;
    const dx = sheep.x - o.x;
    const dy = sheep.y - o.y;
    const d = Math.hypot(dx, dy);
    if (d > 0.1 && d < rad) {
      sx += (dx / d) * (rad - d);
      sy += (dy / d) * (rad - d);
    }
  }
  return { x: sx * 0.08, y: sy * 0.08 };
}

function steerSheep(match: Match, sheep: Sheep, dt: number) {
  if (sheep.stunT > 0) {
    sheep.stunT -= dt;
    sheep.vx = 0;
    sheep.vy = 0;
    return;
  }
  if (sheep.evadeT > 0) sheep.evadeT -= dt;
  if (sheep.chargeT > 0) sheep.chargeT -= dt;
  let tx = sheep.goalX;
  let ty = sheep.goalY;
  const path = sheep.path;
  if (path && sheep.pathI < path.length && sheep.mode !== "eat") {
    const wp = path[sheep.pathI]!;
    if (dist(sheep.x, sheep.y, wp.x, wp.y) < 16) sheep.pathI++;
    const nwp = path[Math.min(sheep.pathI, path.length - 1)]!;
    tx = nwp.x;
    ty = nwp.y;
  }
  let dx = tx - sheep.x;
  let dy = ty - sheep.y;
  const len = Math.hypot(dx, dy) || 1;
  dx /= len;
  dy /= len;
  const sep = separation(match, sheep);
  dx += sep.x;
  dy += sep.y;
  const nlen = Math.hypot(dx, dy) || 1;
  dx /= nlen;
  dy /= nlen;
  const spd = sheep.mode === "chase" && sheep.kind === "boss" ? sheep.speed * 1.25 : sheep.speed;
  sheep.vx = dx * spd;
  sheep.vy = dy * spd;
  if (spd > 8) sheep.face = Math.atan2(dy, dx);
  sheep.phase += dt * spd * 0.08;
  const step = moveBody(match, sheep.x, sheep.y, sheep.radius, sheep.vx * dt, sheep.vy * dt);
  const moved = dist(sheep.x, sheep.y, step.x, step.y);
  sheep.x = step.x;
  sheep.y = step.y;
  if (moved < 5 * dt && (sheep.vx !== 0 || sheep.vy !== 0)) sheep.stuck += dt;
  else sheep.stuck = Math.max(0, sheep.stuck - dt);
  if (sheep.stuck > 0.9) {
    sheep.stuck = 0;
    sheep.frustrated += 0.8;
    sheep.path = null;
    const a = match.rng() * Math.PI * 2;
    const nx = sheep.x + Math.cos(a) * 36;
    const ny = sheep.y + Math.sin(a) * 36;
    if (!blockedAt(match, nx, ny, sheep.radius)) {
      sheep.x = nx;
      sheep.y = ny;
    }
    sheep.think = 0;
  }
  if (sheep.mode === "flank" || sheep.mode === "smash" || (sheep.mode === "enter" && !hasPassage(match))) {
    sheep.frustrated += dt * 0.35;
  } else if (hasPassage(match)) sheep.frustrated = Math.max(0, sheep.frustrated - dt);
}

function trySmash(match: Match, sheep: Sheep, dt: number) {
  if (sheep.mode === "flank" || sheep.mode === "decoy" || sheep.mode === "evade" || sheep.mode === "eat") return;
  let best: Fence | null = null;
  let bd = sheep.radius + 30;
  for (const f of match.fences) {
    if (!fenceSolid(f)) continue;
    const c = center(f);
    const d = dist(sheep.x, sheep.y, c.x, c.y) - Math.max(f.w, f.h) * 0.35;
    if (d < bd) {
      bd = d;
      best = f;
    }
  }
  if (!best) return;
  const allow =
    sheep.mode === "smash" ||
    sheep.kind === "breaker" ||
    sheep.kind === "armored" ||
    sheep.kind === "boss" ||
    sheep.frustrated > 1.2 ||
    best.id === sheep.targetFence;
  if (!allow) return;
  best.hp -= sheep.fenceDps * dt;
  sheep.hitFlash = Math.max(sheep.hitFlash, 0.05);
  if (best.hp <= 0) {
    best.hp = 0;
    best.open = false;
    match.navDirty = true;
    match.sfx?.("break");
    burst(match, center(best).x, center(best).y, "#c4a574", 8);
    toast(match, best.isGate ? "Ворота проломлены" : "В заборе дыра");
  }
}

function tryEat(match: Match, sheep: Sheep, dt: number) {
  if (!insideGarden(sheep.x, sheep.y)) return;
  let best: Crop | null = null;
  let bd = 26;
  for (const c of match.crops) {
    if (c.hp <= 0) continue;
    const d = dist(sheep.x, sheep.y, c.x, c.y);
    if (d < bd) {
      bd = d;
      best = c;
    }
  }
  if (!best) return;
  const before = best.hp;
  best.hp = Math.max(0, best.hp - (8 + sheep.intel * 4) * dt);
  match.run.gardenLost += before - best.hp;
}

function touchPlayer(match: Match, sheep: Sheep, dt: number) {
  sheep.attackCd -= dt;
  const p = match.player;
  if (sheep.attackCd > 0 || p.iFrame > 0) return;
  if (dist(sheep.x, sheep.y, p.x, p.y) > sheep.radius + PLAYER_R + 2) return;
  const dmg = sheep.dmg;
  p.hp -= dmg;
  p.iFrame = 0.45;
  p.hurt = 0.25;
  sheep.attackCd = sheep.kind === "boss" ? 0.85 : 0.7;
  const dx = p.x - sheep.x;
  const dy = p.y - sheep.y;
  const len = Math.hypot(dx, dy) || 1;
  const kick = moveBody(match, p.x, p.y, PLAYER_R, (dx / len) * 18, (dy / len) * 18);
  p.x = kick.x;
  p.y = kick.y;
  match.cam.shake = Math.max(match.cam.shake, 7);
  match.sfx?.("hurt");
  floater(match, p.x, p.y - 20, `-${Math.round(dmg)}`, "#d64545");
  if (sheep.kind === "boss") sheep.chargeT = 0;
}

function killSheep(match: Match, sheep: Sheep) {
  if (sheep.dead) return;
  sheep.dead = true;
  sheep.fade = 0.42;
  sheep.vx = 0;
  sheep.vy = 0;
  if (!sheep.rewarded) {
    sheep.rewarded = true;
    const coins = coinReward(sheep.kind, sheep.intel, sheep.maxHp, sheep.dmg, sheep.speed, match.wave);
    match.save.coins += coins;
    match.save.stats.totalCoinsEarned += coins;
    match.run.earned += coins;
    match.run.kills += 1;
    match.save.stats.totalKills += 1;
    const threat = sheep.dmg * sheep.maxHp * (1 + sheep.intel);
    if (threat >= match.run.bestScore) {
      match.run.bestScore = threat;
      match.run.bestName = KINDS[sheep.kind].name;
    }
    floater(match, sheep.x, sheep.y - 18, `+${coins}`, "#e2a123");
    match.sfx?.("coin");
  }
  match.sfx?.("die");
  const fx = match.save.equipped.fx;
  const color = fx === "fx-sparks" ? "#e2a123" : fx === "fx-petals" ? "#e7a0b8" : "#f4efe6";
  burst(match, sheep.x, sheep.y, color, fx === "fx-soft" ? 4 : 12);
}

function damageSheep(match: Match, sheep: Sheep, dmg: number, knock: number, stun: number, dir: number) {
  if (sheep.dead) return;
  sheep.hp -= dmg;
  sheep.hitFlash = 0.12;
  sheep.vx += Math.cos(dir) * knock;
  sheep.vy += Math.sin(dir) * knock;
  const push = moveBody(match, sheep.x, sheep.y, sheep.radius, Math.cos(dir) * knock * 0.04, Math.sin(dir) * knock * 0.04);
  sheep.x = push.x;
  sheep.y = push.y;
  if (stun > 0) sheep.stunT = Math.max(sheep.stunT, stun);
  if (sheep.hp <= sheep.maxHp * 0.45 && sheep.aggr < 0.5) sheep.evadeT = Math.max(sheep.evadeT, 0.6);
  if (sheep.kind === "armored" || sheep.kind === "boss") {
    sheep.aggr = Math.min(1, sheep.aggr + 0.08);
    if (sheep.kind === "boss") sheep.chargeT = Math.max(sheep.chargeT, 0.8);
  }
  floater(match, sheep.x, sheep.y - sheep.radius, `${Math.round(dmg)}`, "#f4efe6");
  match.hitStop = Math.max(match.hitStop, sheep.boss ? 0.045 : 0.028);
  match.cam.shake = Math.max(match.cam.shake, sheep.boss ? 8 : 4);
  match.sfx?.("hit");
  if (sheep.hp <= 0) killSheep(match, sheep);
}

function los(match: Match, x0: number, y0: number, x1: number, y1: number) {
  for (const f of match.fences) {
    if (!fenceSolid(f)) continue;
    if (segHitsRect(x0, y0, x1, y1, f)) return false;
  }
  for (const o of match.obstacles) {
    if (distPointSeg(o.x, o.y, x0, y0, x1, y1) < o.r - 4) return false;
  }
  return true;
}

function segHitsRect(x0: number, y0: number, x1: number, y1: number, r: Fence) {
  if (pointIn(x0, y0, r) || pointIn(x1, y1, r)) return true;
  const x2 = r.x + r.w;
  const y2 = r.y + r.h;
  return (
    segSeg(x0, y0, x1, y1, r.x, r.y, x2, r.y) ||
    segSeg(x0, y0, x1, y1, x2, r.y, x2, y2) ||
    segSeg(x0, y0, x1, y1, x2, y2, r.x, y2) ||
    segSeg(x0, y0, x1, y1, r.x, y2, r.x, r.y)
  );
}

function pointIn(x: number, y: number, r: Fence) {
  return x >= r.x && y >= r.y && x <= r.x + r.w && y <= r.y + r.h;
}

function segSeg(ax: number, ay: number, bx: number, by: number, cx: number, cy: number, dx: number, dy: number) {
  const d1 = dir(cx, cy, dx, dy, ax, ay);
  const d2 = dir(cx, cy, dx, dy, bx, by);
  const d3 = dir(ax, ay, bx, by, cx, cy);
  const d4 = dir(ax, ay, bx, by, dx, dy);
  return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
}

function dir(ax: number, ay: number, bx: number, by: number, cx: number, cy: number) {
  return (cx - ax) * (by - ay) - (cy - ay) * (bx - ax);
}

function distPointSeg(px: number, py: number, x0: number, y0: number, x1: number, y1: number) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const l2 = dx * dx + dy * dy || 1;
  let t = ((px - x0) * dx + (py - y0) * dy) / l2;
  t = clamp(t, 0, 1);
  return Math.hypot(px - (x0 + t * dx), py - (y0 + t * dy));
}

function burst(match: Match, x: number, y: number, color: string, n: number) {
  for (let i = 0; i < n; i++) {
    if (match.particles.length > 170) return;
    const a = match.rng() * Math.PI * 2;
    const s = 30 + match.rng() * 90;
    match.particles.push({
      x,
      y,
      vx: Math.cos(a) * s,
      vy: Math.sin(a) * s,
      life: 0.35 + match.rng() * 0.3,
      max: 0.55,
      r: 2 + match.rng() * 3,
      color,
    });
  }
}

function floater(match: Match, x: number, y: number, text: string, color: string) {
  if (match.floaters.length > 24) match.floaters.shift();
  match.floaters.push({ x, y, text, life: 0.8, color });
}

function currentWeapon(match: Match): WeaponDef {
  return weaponById(match.save.equippedWeapon);
}

function weaponState(match: Match) {
  const id = match.save.equippedWeapon;
  return match.save.weapons[id] ?? match.save.weapons.stick!;
}

function spendDurability(match: Match) {
  const st = weaponState(match);
  if (st.durability <= 0) return false;
  st.durability -= 1;
  const id = match.save.equippedWeapon;
  match.run.weaponUse[id] = (match.run.weaponUse[id] ?? 0) + 1;
  if (st.durability === 0) toast(match, "Оружие сломано — нужен ремонт");
  else if (st.durability === Math.ceil(currentWeapon(match).durability * 0.2)) toast(match, "Оружие на исходе");
  return true;
}

function playerAttack(match: Match) {
  const w = currentWeapon(match);
  const st = weaponState(match);
  const p = match.player;
  if (st.durability <= 0) {
    if (match.input.attackEdge) toast(match, "Сломано. Отремонтируйте в инвентаре");
    return;
  }
  if (w.kind === "melee") {
    if (!match.input.attackEdge || p.cd > 0) return;
    if (!spendDurability(match)) return;
    p.cd = w.cooldown;
    p.swing = 0.18;
    p.swingDur = 0.18;
    p.swingDir = p.aim;
    p.swingHits = [];
    if (w.dash > 0) {
      const step = moveBody(match, p.x, p.y, PLAYER_R, Math.cos(p.aim) * w.dash, Math.sin(p.aim) * w.dash);
      p.x = step.x;
      p.y = step.y;
    }
    return;
  }
  if (p.reload > 0 || p.cd > 0) return;
  if (!match.input.attackHeld && !match.input.attackEdge) return;
  if (st.loaded <= 0) {
    startReload(match);
    return;
  }
  if (!spendDurability(match)) return;
  st.loaded -= 1;
  p.cd = w.cooldown;
  const tint = bulletColor(match.save.equipped.weapon);
  for (let i = 0; i < w.pellets; i++) {
    const a = p.aim + (match.rng() - 0.5) * w.spread;
    match.bullets.push({
      x: p.x + Math.cos(a) * 18,
      y: p.y + Math.sin(a) * 18,
      px: p.x,
      py: p.y,
      vx: Math.cos(a) * w.bulletSpeed,
      vy: Math.sin(a) * w.bulletSpeed,
      dmg: w.dmg,
      r: w.pellets > 1 ? 3 : 4,
      life: w.range / w.bulletSpeed,
      pierce: w.pierce,
      hit: [],
      knock: w.knock,
      stun: w.stun,
      color: tint,
    });
  }
  match.sfx?.("shot");
  match.cam.shake = Math.max(match.cam.shake, w.pellets > 1 ? 5 : 2);
  if (st.loaded <= 0) startReload(match);
}

function bulletColor(skin: string) {
  if (skin === "wskin-sakura") return "#e48ab0";
  if (skin === "wskin-night") return "#7eb6ff";
  if (skin === "wskin-gold") return "#e2a123";
  if (skin === "wskin-void") return "#b07cff";
  return "#f4efe6";
}

function startReload(match: Match) {
  const w = currentWeapon(match);
  const st = weaponState(match);
  if (w.kind !== "gun" || match.player.reload > 0) return;
  if (st.loaded >= w.mag || st.reserve <= 0) return;
  match.player.reload = w.reload;
  match.sfx?.("reload");
}

function finishReload(match: Match) {
  const w = currentWeapon(match);
  const st = weaponState(match);
  const need = w.mag - st.loaded;
  const take = Math.min(need, st.reserve);
  st.loaded += take;
  st.reserve -= take;
}

function meleeSweep(match: Match) {
  const p = match.player;
  if (p.swing <= 0) return;
  const w = currentWeapon(match);
  const age = p.swingDur - p.swing;
  if (age < 0.03 || age > 0.13) return;
  for (const s of match.sheep) {
    if (s.dead || p.swingHits.includes(s.id)) continue;
    const d = dist(p.x, p.y, s.x, s.y);
    if (d > w.range + s.radius) continue;
    const ang = Math.atan2(s.y - p.y, s.x - p.x);
    let diff = Math.atan2(Math.sin(ang - p.swingDir), Math.cos(ang - p.swingDir));
    if (Math.abs(diff) > w.arc / 2) continue;
    if (!los(match, p.x, p.y, s.x, s.y)) continue;
    p.swingHits.push(s.id);
    damageSheep(match, s, w.dmg, w.knock, w.stun, ang);
  }
}

function updateBullets(match: Match, dt: number) {
  for (const b of match.bullets) {
    b.px = b.x;
    b.py = b.y;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    if (!los(match, b.px, b.py, b.x, b.y)) {
      b.life = 0;
      continue;
    }
    for (const s of match.sheep) {
      if (s.dead || b.hit.includes(s.id)) continue;
      if (dist(b.x, b.y, s.x, s.y) < s.radius + b.r) {
        b.hit.push(s.id);
        const ang = Math.atan2(b.vy, b.vx);
        damageSheep(match, s, b.dmg, b.knock, b.stun, ang);
        b.pierce -= 1;
        if (b.pierce <= 0) {
          b.life = 0;
          break;
        }
      }
    }
  }
  match.bullets = match.bullets.filter((b) => b.life > 0);
}

function updatePlayer(match: Match, dt: number) {
  const p = match.player;
  const inp = match.input;
  let mx = inp.mx;
  let my = inp.my;
  const len = Math.hypot(mx, my);
  if (len > 1) {
    mx /= len;
    my /= len;
  }
  const wantX = mx * PLAYER_SPEED;
  const wantY = my * PLAYER_SPEED;
  const k = 1 - Math.exp(-14 * dt);
  p.vx += (wantX - p.vx) * k;
  p.vy += (wantY - p.vy) * k;
  if (Math.hypot(p.vx, p.vy) < 4) {
    p.vx = 0;
    p.vy = 0;
  }
  const step = moveBody(match, p.x, p.y, PLAYER_R, p.vx * dt, p.vy * dt);
  p.x = step.x;
  p.y = step.y;
  p.bob += Math.hypot(p.vx, p.vy) * dt * 0.04;
  if (inp.aimOk) p.aim = Math.atan2(inp.aimY - p.y, inp.aimX - p.x);
  else if (len > 0.25) p.aim = Math.atan2(my, mx);
  if (inp.assist) {
    let best: Sheep | null = null;
    let bd = 280;
    for (const s of match.sheep) {
      if (s.dead) continue;
      const d = dist(p.x, p.y, s.x, s.y);
      if (d < bd && los(match, p.x, p.y, s.x, s.y)) {
        bd = d;
        best = s;
      }
    }
    if (best && !inp.aimOk) p.aim = Math.atan2(best.y - p.y, best.x - p.x);
  }
  if (p.cd > 0) p.cd -= dt;
  if (p.swing > 0) p.swing -= dt;
  if (p.iFrame > 0) p.iFrame -= dt;
  if (p.hurt > 0) p.hurt -= dt;
  if (p.reload > 0) {
    p.reload -= dt;
    if (p.reload <= 0) finishReload(match);
  }
  if (inp.reloadEdge) startReload(match);
  if (inp.slot !== null) {
    const w = WEAPONS[inp.slot];
    if (w && match.save.weapons[w.id]?.unlocked) match.save.equippedWeapon = w.id;
  }
  if (inp.cycle !== 0) cycleWeapon(match, inp.cycle);
  playerAttack(match);
  meleeSweep(match);
  if (inp.interactEdge) toggleGate(match);
}

function cycleWeapon(match: Match, dir: number) {
  const owned = WEAPONS.filter((w) => match.save.weapons[w.id]?.unlocked);
  const i = owned.findIndex((w) => w.id === match.save.equippedWeapon);
  const n = owned[(i + dir + owned.length) % owned.length];
  if (n) match.save.equippedWeapon = n.id;
}

function toggleGate(match: Match) {
  const p = match.player;
  let best: Fence | null = null;
  let bd = 56;
  for (const f of match.fences) {
    if (!f.isGate) continue;
    const c = center(f);
    const d = dist(p.x, p.y, c.x, c.y);
    if (d < bd) {
      bd = d;
      best = f;
    }
  }
  if (!best) return;
  if (best.hp <= 0) {
    toast(match, "Ворота разрушены");
    return;
  }
  if (best.open) {
    for (const s of match.sheep) {
      if (!s.dead && circleHitsRect(s.x, s.y, s.radius, best)) {
        toast(match, "В створе кто-то стоит");
        return;
      }
    }
    best.open = false;
  } else best.open = true;
  match.navDirty = true;
  match.sfx?.("ui");
}

function updateCamera(match: Match, dt: number) {
  const p = match.player;
  const look = 26;
  const tx = p.x + Math.cos(p.aim) * look - match.view.w / 2;
  const ty = p.y + Math.sin(p.aim) * look - match.view.h / 2;
  const k = 1 - Math.exp(-7 * dt);
  match.cam.x += (tx - match.cam.x) * k;
  match.cam.y += (ty - match.cam.y) * k;
  match.cam.x = clamp(match.cam.x, 0, Math.max(0, GEO.worldW - match.view.w));
  match.cam.y = clamp(match.cam.y, 0, Math.max(0, GEO.worldH - match.view.h));
  if (match.cam.shake > 0) match.cam.shake = Math.max(0, match.cam.shake - dt * 28);
}

function refreshPrompt(match: Match) {
  const p = match.player;
  match.prompt = null;
  for (const f of match.fences) {
    if (!f.isGate || f.hp <= 0) continue;
    const c = center(f);
    if (dist(p.x, p.y, c.x, c.y) < 58) {
      match.prompt = f.open ? "E — закрыть ворота" : "E — открыть ворота";
      break;
    }
  }
  let alert: Match["alert"] = null;
  for (const s of match.sheep) {
    if (s.dead) continue;
    if (s.boss) alert = "boss";
    if (insideGarden(s.x, s.y)) {
      alert = "garden";
      break;
    }
    if (!alert && s.mode === "smash") alert = "fence";
  }
  match.alert = alert;
}

function checkEnd(match: Match) {
  const cropsLeft = match.crops.reduce((a, c) => a + Math.max(0, c.hp), 0);
  if (match.player.hp <= 0 || cropsLeft <= 0) {
    match.player.hp = Math.max(0, match.player.hp);
    match.phase = "defeat";
    const use = match.run.weaponUse;
    let bestId = match.save.equippedWeapon;
    let bestN = -1;
    for (const [id, n] of Object.entries(use)) {
      if (n > bestN) {
        bestN = n;
        bestId = id;
      }
    }
    match.result = {
      wave: match.wave,
      kills: match.run.kills,
      earned: match.run.earned,
      bestName: match.run.bestName,
      weaponName: weaponById(bestId).name,
      garden: cropsLeft / match.cropMax,
    };
    match.save.run = null;
    match.sfx?.("hurt");
    return;
  }
  if (
    match.phase === "combat" &&
    match.countdown <= 0 &&
    match.spawnQ.length === 0 &&
    match.sheep.every((s) => s.dead)
  ) {
    match.phase = "intermission";
    const bonus = 8 + match.wave * 4;
    match.save.coins += bonus;
    match.save.stats.totalCoinsEarned += bonus;
    match.run.earned += bonus;
    floater(match, match.player.x, match.player.y - 28, `+${bonus}`, "#e2a123");
    toast(match, `Волна ${match.wave} отбита`);
    match.save.stats.bestWave = Math.max(match.save.stats.bestWave, match.wave);
  }
}

export function tick(match: Match, dt: number) {
  match.time += dt;
  if (match.toastT > 0) {
    match.toastT -= dt;
    if (match.toastT <= 0) match.toast = null;
  }
  for (const f of match.floaters) f.life -= dt;
  match.floaters = match.floaters.filter((f) => f.life > 0);
  for (const p of match.particles) {
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += 20 * dt;
  }
  match.particles = match.particles.filter((p) => p.life > 0);
  if (match.paused || match.phase === "defeat") {
    updateCamera(match, dt);
    clearEdges(match);
    return;
  }
  if (match.hitStop > 0) {
    match.hitStop -= dt;
    clearEdges(match);
    updateCamera(match, dt);
    return;
  }
  if (match.navDirty) rebuildNav(match);
  if (match.phase === "combat") {
    if (match.countdown > 0) match.countdown -= dt;
    else {
      const alive = match.sheep.filter((s) => !s.dead).length;
      match.spawnT -= dt;
      if (match.spawnQ.length && match.spawnT <= 0 && alive < 14) {
        spawnSheep(match);
        match.spawnT = 0.55;
      }
    }
  }
  updatePlayer(match, dt);
  updateHerd(match);
  if (match.phase === "combat") {
    for (const s of match.sheep) {
      if (s.dead) {
        s.fade -= dt;
        continue;
      }
      s.think -= dt;
      s.hitFlash = Math.max(0, s.hitFlash - dt);
      s.attackCd = Math.max(0, s.attackCd);
      if (s.think <= 0) {
        s.think = 0.55 - s.intel * 0.28;
        if (s.kind === "boss" && match.rng() < 0.35) s.chargeT = 1.1;
        thinkSheep(match, s);
      }
      steerSheep(match, s, dt);
      trySmash(match, s, dt);
      tryEat(match, s, dt);
      touchPlayer(match, s, dt);
    }
    match.sheep = match.sheep.filter((s) => !s.dead || s.fade > 0);
    updateBullets(match, dt);
    checkEnd(match);
  } else {
    for (const s of match.sheep) s.fade -= dt;
    match.sheep = match.sheep.filter((s) => s.fade > 0 && s.dead);
  }
  refreshPrompt(match);
  updateCamera(match, dt);
  clearEdges(match);
}

function clearEdges(match: Match) {
  match.input.attackEdge = false;
  match.input.interactEdge = false;
  match.input.reloadEdge = false;
  match.input.slot = null;
  match.input.cycle = 0;
}

export function captureRun(match: Match): RunSave {
  return {
    wave: match.wave,
    phase: match.phase === "intermission" ? "intermission" : "combat",
    countdown: match.countdown,
    player: { x: match.player.x, y: match.player.y, hp: match.player.hp, aim: match.player.aim },
    fences: match.fences.map((f) => ({ hp: f.hp, open: f.open })),
    crops: match.crops.map((c) => c.hp),
    sheep: match.sheep
      .filter((s) => !s.dead)
      .map((s) => ({ kind: s.kind, x: s.x, y: s.y, hp: s.hp, seed: s.seed })),
    spawnQ: [...match.spawnQ],
    spawnT: match.spawnT,
    stats: match.run,
  };
}

function pay(match: Match, cost: number): string | null {
  if (cost <= 0) return "Нечего чинить";
  if (match.save.coins < cost) return "Не хватает монет";
  match.save.coins -= cost;
  return null;
}

export function buyWeapon(match: Match, id: string): string | null {
  const was = match.save.weapons[id]?.unlocked;
  const err = tryBuyWeapon(match.save, id);
  if (!err) match.sfx?.(was ? "ui" : "buy");
  return err;
}

export function repairWeapon(match: Match, id: string, fraction: number): string | null {
  const before = match.save.coins;
  const err = tryRepairWeapon(match.save, id, fraction);
  if (!err && match.save.coins !== before) match.sfx?.("repair");
  return err;
}

export function buyAmmo(match: Match, id: string): string | null {
  const err = tryBuyAmmo(match.save, id);
  if (!err) match.sfx?.("buy");
  return err;
}

export function buyCosmetic(match: Match, id: string): string | null {
  const owned = match.save.owned.includes(id);
  const err = tryBuyCosmetic(match.save, id);
  if (!err) match.sfx?.(owned ? "ui" : "buy");
  return err;
}

export function equipCosmetic(match: Match, id: string): string | null {
  const err = tryEquipCosmetic(match.save, id);
  if (!err) match.sfx?.("ui");
  return err;
}

export function repairCrops(match: Match): string | null {
  const missing = match.crops.reduce((a, c) => a + (c.maxHp - c.hp), 0);
  const cost = structureRepairCost(missing);
  const err = pay(match, cost);
  if (err) return err === "Нечего чинить" ? null : err;
  for (const c of match.crops) c.hp = c.maxHp;
  match.sfx?.("repair");
  return null;
}

export function repairFences(match: Match): string | null {
  const missing = match.fences.reduce((a, f) => a + (f.maxHp - Math.max(0, f.hp)), 0);
  const cost = structureRepairCost(missing);
  const err = pay(match, cost);
  if (err) return err === "Нечего чинить" ? null : err;
  for (const f of match.fences) {
    f.hp = f.maxHp;
    if (!f.isGate) f.open = false;
  }
  match.navDirty = true;
  match.sfx?.("repair");
  return null;
}

export function equipWeapon(match: Match, id: string): string | null {
  const err = tryEquipWeapon(match.save, id);
  if (!err) match.sfx?.("ui");
  return err;
}

export function missingCrops(match: Match) {
  return match.crops.reduce((a, c) => a + (c.maxHp - Math.max(0, c.hp)), 0);
}

export function missingFences(match: Match) {
  return match.fences.reduce((a, f) => a + (f.maxHp - Math.max(0, f.hp)), 0);
}

export function snapshot(match: Match): Snapshot {
  const w = currentWeapon(match);
  const st = weaponState(match);
  const boss = match.sheep.find((s) => s.boss && !s.dead);
  const gardenHp = match.crops.reduce((a, c) => a + Math.max(0, c.hp), 0);
  return {
    phase: match.phase,
    paused: match.paused,
    coins: match.save.coins,
    wave: match.wave,
    countdown: match.countdown,
    playerHp: Math.max(0, match.player.hp),
    playerMax: PLAYER_HP,
    garden: match.cropMax > 0 ? gardenHp / match.cropMax : 0,
    weaponId: w.id,
    weaponName: w.name,
    durability: st.durability,
    durabilityMax: w.durability,
    broken: st.durability <= 0,
    warn: st.durability / w.durability <= 0.2,
    loaded: w.kind === "gun" ? st.loaded : null,
    reserve: w.kind === "gun" ? st.reserve : null,
    mag: w.mag,
    reloading: match.player.reload > 0,
    bossHp: boss ? Math.max(0, boss.hp) : null,
    bossMax: boss ? boss.maxHp : null,
    bossName: boss ? KINDS.boss.name : null,
    alert: match.alert,
    prompt: match.prompt,
    toast: match.toast,
    mods: match.mods.map((m) => m.name),
    kills: match.run.kills,
    earned: match.run.earned,
    result: match.result,
    fenceMissing: missingFences(match),
    cropMissing: missingCrops(match),
    runActive: match.phase !== "defeat",
  };
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function playerVelocity(match: Match) {
  return { vx: match.player.vx, vy: match.player.vy };
}
