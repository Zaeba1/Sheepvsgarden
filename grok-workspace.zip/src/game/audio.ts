let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let volume = 0.7;
let muted = false;
let musicOn = true;
let nextNote = 0;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new Ctor();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : volume * 0.35;
    master.connect(ctx.destination);
  }
  return ctx;
}

export function unlockAudio() {
  const c = ac();
  if (c && c.state === "suspended") void c.resume();
}

export function setAudio(next: { volume: number; muted: boolean }) {
  volume = next.volume;
  muted = next.muted;
  if (master) master.gain.value = muted ? 0 : volume * 0.35;
}

function tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0) {
  const c = ac();
  if (!c || !master || muted || volume <= 0) return;
  const t0 = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(gain, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g);
  g.connect(master);
  o.start(t0);
  o.stop(t0 + dur + 0.02);
}

function noise(dur: number, gain: number) {
  const c = ac();
  if (!c || !master || muted || volume <= 0) return;
  const n = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, n, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < n; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const src = c.createBufferSource();
  src.buffer = buf;
  const g = c.createGain();
  g.gain.value = gain;
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = 900;
  src.connect(f);
  f.connect(g);
  g.connect(master);
  src.start();
}

export type Sfx =
  | "hit"
  | "shot"
  | "coin"
  | "hurt"
  | "break"
  | "buy"
  | "wave"
  | "die"
  | "ui"
  | "repair"
  | "reload";

export function playSfx(name: Sfx) {
  unlockAudio();
  switch (name) {
    case "hit":
      noise(0.08, 0.5);
      tone(180, 0.07, "square", 0.08);
      break;
    case "shot":
      noise(0.05, 0.35);
      tone(420, 0.05, "square", 0.05);
      break;
    case "coin":
      tone(880, 0.08, "square", 0.06);
      tone(1320, 0.12, "square", 0.05, 0.06);
      break;
    case "hurt":
      tone(140, 0.16, "sawtooth", 0.07);
      break;
    case "break":
      noise(0.18, 0.45);
      tone(90, 0.2, "triangle", 0.08);
      break;
    case "buy":
      tone(523, 0.08, "triangle", 0.06);
      tone(659, 0.08, "triangle", 0.05, 0.07);
      tone(784, 0.14, "triangle", 0.05, 0.14);
      break;
    case "wave":
      tone(330, 0.1, "triangle", 0.06);
      tone(415, 0.1, "triangle", 0.05, 0.09);
      tone(494, 0.18, "triangle", 0.05, 0.18);
      break;
    case "die":
      tone(360, 0.12, "sine", 0.05);
      tone(220, 0.18, "sine", 0.04, 0.06);
      break;
    case "repair":
      tone(500, 0.06, "square", 0.04);
      tone(700, 0.1, "square", 0.04, 0.05);
      break;
    case "reload":
      tone(240, 0.05, "square", 0.04);
      tone(180, 0.07, "square", 0.04, 0.06);
      break;
    default:
      tone(660, 0.04, "square", 0.04);
  }
}

export function setMusic(on: boolean) {
  musicOn = on;
}

export function musicTick(combat: boolean, dt: number) {
  if (!musicOn || muted || volume <= 0) return;
  const c = ac();
  if (!c) return;
  nextNote -= dt;
  if (nextNote > 0) return;
  nextNote = combat ? 0.42 : 0.62;
  const scale = combat ? [196, 220, 247, 262, 294] : [262, 294, 330, 392, 330];
  const f = scale[Math.floor(Math.random() * scale.length)]!;
  tone(f, 0.28, "triangle", combat ? 0.035 : 0.025);
}
