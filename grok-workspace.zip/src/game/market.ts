import { COSMETICS, WEAPONS, ammoPackCost, cosmeticById, weaponById, weaponRepairCost } from "./content";
import type { SaveData } from "./save";

export function tryBuyWeapon(save: SaveData, id: string): string | null {
  const def = weaponById(id);
  const st = save.weapons[id];
  if (!st) return "Нет такого оружия";
  if (st.unlocked) {
    save.equippedWeapon = id;
    return null;
  }
  if (save.coins < def.unlock) return "Не хватает монет";
  save.coins -= def.unlock;
  st.unlocked = true;
  st.durability = def.durability;
  st.loaded = def.kind === "gun" ? def.mag : 0;
  st.reserve = def.kind === "gun" ? def.mag * 2 : 0;
  save.equippedWeapon = id;
  return null;
}

export function tryRepairWeapon(save: SaveData, id: string, fraction: number): string | null {
  const def = WEAPONS.find((w) => w.id === id);
  const st = save.weapons[id];
  if (!def || !st?.unlocked) return "Оружие не открыто";
  const cost = weaponRepairCost(def, st.durability, fraction);
  if (cost <= 0) return null;
  if (save.coins < cost) return "Не хватает монет";
  save.coins -= cost;
  const missing = def.durability - st.durability;
  st.durability = Math.min(def.durability, st.durability + missing * fraction);
  return null;
}

export function tryBuyAmmo(save: SaveData, id: string): string | null {
  const def = WEAPONS.find((w) => w.id === id);
  const st = save.weapons[id];
  if (!def || def.kind !== "gun" || !st?.unlocked) return "Это не огнестрел";
  const cap = def.mag * 5;
  if (st.reserve >= cap) return "Запас полный";
  const cost = ammoPackCost(def);
  if (save.coins < cost) return "Не хватает монет";
  save.coins -= cost;
  st.reserve = Math.min(cap, st.reserve + def.mag);
  return null;
}

export function tryBuyCosmetic(save: SaveData, id: string): string | null {
  const def = cosmeticById(id);
  if (!def) return "Нет предмета";
  if (!save.owned.includes(id)) {
    if (save.coins < def.price) return "Не хватает монет";
    save.coins -= def.price;
    save.owned.push(def.id);
  }
  save.equipped[def.cat] = def.id;
  return null;
}

export function tryEquipCosmetic(save: SaveData, id: string): string | null {
  const def = COSMETICS.find((c) => c.id === id);
  if (!def) return "Нет предмета";
  if (!save.owned.includes(id)) return "Сначала купите";
  save.equipped[def.cat] = def.id;
  return null;
}

export function tryEquipWeapon(save: SaveData, id: string): string | null {
  if (!save.weapons[id]?.unlocked) return "Сначала откройте";
  save.equippedWeapon = id;
  return null;
}
