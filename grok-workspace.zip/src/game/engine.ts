import { musicTick, playSfx, setAudio, setMusic, unlockAudio } from "./audio";
import { render } from "./draw";
import {
  buyAmmo,
  buyCosmetic,
  buyWeapon,
  captureRun,
  createMatch,
  equipCosmetic,
  equipWeapon,
  nextWave,
  playerVelocity,
  repairCrops,
  repairFences,
  repairWeapon,
  snapshot,
  tick,
  type Match,
  type Snapshot,
} from "./logic";
import { persist, type SaveData } from "./save";

export type Hooks = {
  onSnapshot: (snap: Snapshot) => void;
  onSave: (save: SaveData) => void;
};

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
    };
  }
}

export class Engine {
  private match: Match;
  private canvas: HTMLCanvasElement;
  private keys = new Set<string>();
  private forced: Set<string> | null = null;
  private joy = { x: 0, y: 0 };
  private aim = { x: 0, y: 0, on: false };
  private mouse = { x: 0, y: 0, ok: false };
  private attackHeld = false;
  private attackEdge = false;
  private interactEdge = false;
  private reloadEdge = false;
  private slot: number | null = null;
  private cycle = 0;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private vis = 0;
  private alive = true;
  private dpr = 1;
  private snapT = 0;
  private ro: ResizeObserver | null = null;
  private reduce = false;

  constructor(
    canvas: HTMLCanvasElement,
    save: SaveData,
    private hooks: Hooks,
    mode: "new" | "continue",
  ) {
    const match = createMatch(save, mode);
    if (!match) throw new Error("Нет сохранения забега");
    this.match = match;
    this.canvas = canvas;
    this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setAudio(save.settings);
    setMusic(!save.settings.muted);
    match.sfx = playSfx;
    this.resize();
    this.bind();
    this.hooks.onSnapshot(snapshot(match));
    this.hooks.onSave(save);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
    window.__controlsTest = {
      getYaw: () => {
        const { vx, vy } = playerVelocity(this.match);
        return Math.atan2(-vx, -vy);
      },
      getSpeed: () => {
        const { vx, vy } = playerVelocity(this.match);
        return Math.hypot(vx, vy);
      },
      setKeys: (codes) => {
        this.forced = new Set(codes);
      },
    };
    (window as unknown as { __sheep?: () => unknown }).__sheep = () => ({
      phase: this.match.phase,
      countdown: this.match.countdown,
      coins: this.match.save.coins,
      wave: this.match.wave,
      player: {
        x: Math.round(this.match.player.x),
        y: Math.round(this.match.player.y),
        hp: Math.round(this.match.player.hp),
      },
      sheep: this.match.sheep
        .filter((s) => !s.dead)
        .map((s) => ({
          kind: s.kind,
          mode: s.mode,
          x: Math.round(s.x),
          y: Math.round(s.y),
          hp: Math.round(s.hp),
        })),
      fences: this.match.fences.map((f) => ({
        side: f.side,
        gate: f.isGate,
        hp: Math.round(f.hp),
        open: f.open,
      })),
      garden: this.match.crops.filter((c) => c.hp > 0).length,
    });
  }

  destroy() {
    this.alive = false;
    cancelAnimationFrame(this.raf);
    this.ro?.disconnect();
    this.unbind();
    if (window.__controlsTest) delete window.__controlsTest;
  }

  getMatch() {
    return this.match;
  }

  setPaused(paused: boolean) {
    this.match.paused = paused;
    if (paused) {
      this.match.player.vx = 0;
      this.match.player.vy = 0;
    }
    this.emit(true);
  }

  setJoy(x: number, y: number) {
    this.joy.x = x;
    this.joy.y = y;
  }

  setAimStick(x: number, y: number, on: boolean) {
    this.aim.x = x;
    this.aim.y = y;
    this.aim.on = on;
  }

  setAttack(held: boolean) {
    if (held && !this.attackHeld) this.attackEdge = true;
    this.attackHeld = held;
  }

  interact() {
    this.interactEdge = true;
  }

  reload() {
    this.reloadEdge = true;
  }

  cycleWeapon(dir: number) {
    this.cycle += dir;
  }

  selectSlot(index: number) {
    this.slot = index;
  }

  goNextWave() {
    nextWave(this.match);
    this.store(true);
    this.emit(true);
  }

  doBuyWeapon(id: string) {
    return this.act(() => buyWeapon(this.match, id));
  }
  doRepair(id: string, fraction: number) {
    return this.act(() => repairWeapon(this.match, id, fraction));
  }
  doAmmo(id: string) {
    return this.act(() => buyAmmo(this.match, id));
  }
  doBuyCosmetic(id: string) {
    return this.act(() => buyCosmetic(this.match, id));
  }
  doEquipCosmetic(id: string) {
    return this.act(() => equipCosmetic(this.match, id));
  }
  doEquipWeapon(id: string) {
    return this.act(() => equipWeapon(this.match, id));
  }
  doRepairCrops() {
    return this.act(() => repairCrops(this.match));
  }
  doRepairFences() {
    return this.act(() => repairFences(this.match));
  }

  updateSettings(partial: Partial<SaveData["settings"]>) {
    this.match.save.settings = { ...this.match.save.settings, ...partial };
    setAudio(this.match.save.settings);
    setMusic(!this.match.save.settings.muted);
    this.store(true);
  }

  quit() {
    if (this.match.phase !== "defeat") {
      this.match.save.run = captureRun(this.match);
    }
    this.store(true);
  }

  private act(fn: () => string | null) {
    const err = fn();
    this.store(true);
    this.emit(true);
    return err;
  }

  private store(force: boolean) {
    if (this.match.phase !== "defeat") this.match.save.run = captureRun(this.match);
    if (force) persist(this.match.save);
    this.hooks.onSave(this.match.save);
  }

  private emit(force = false) {
    if (!force && this.snapT < 0.1) return;
    this.snapT = 0;
    this.hooks.onSnapshot(snapshot(this.match));
  }

  private resize = () => {
    const rect = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.max(1, Math.floor(rect.width * this.dpr));
    this.canvas.height = Math.max(1, Math.floor(rect.height * this.dpr));
    this.match.view.w = Math.max(1, rect.width);
    this.match.view.h = Math.max(1, rect.height);
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    this.keys.add(e.code);
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    if (e.code === "Space" || e.code === "KeyJ") this.attackEdge = true;
    if (e.code === "KeyE") this.interactEdge = true;
    if (e.code === "KeyR") this.reloadEdge = true;
    if (e.code === "KeyQ") this.cycle -= 1;
    if (e.code.startsWith("Digit")) {
      const n = Number(e.code.slice(5));
      if (n >= 1 && n <= 9) this.slot = n - 1;
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
    this.attackHeld = false;
  };

  private onPointerDown = (e: PointerEvent) => {
    if (e.button !== 0) return;
    unlockAudio();
    this.aimFromEvent(e);
    this.attackHeld = true;
    this.attackEdge = true;
  };

  private onPointerUp = () => {
    this.attackHeld = false;
  };

  private onPointerMove = (e: PointerEvent) => {
    this.aimFromEvent(e);
    this.mouse.ok = true;
  };

  private aimFromEvent(e: PointerEvent) {
    const rect = this.canvas.getBoundingClientRect();
    this.mouse.x = e.clientX - rect.left + this.match.cam.x;
    this.mouse.y = e.clientY - rect.top + this.match.cam.y;
    this.mouse.ok = true;
  }

  private bind() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("resize", this.resize);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointerup", this.onPointerUp);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
  }

  private unbind() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("resize", this.resize);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
  }

  private sample() {
    const down = (code: string) => (this.forced ? this.forced.has(code) : this.keys.has(code));
    let mx = 0;
    let my = 0;
    if (!this.forced) {
      mx += this.joy.x;
      my += this.joy.y;
    }
    if (down("KeyA") || down("ArrowLeft")) mx -= 1;
    if (down("KeyD") || down("ArrowRight")) mx += 1;
    if (down("KeyW") || down("ArrowUp")) my -= 1;
    if (down("KeyS") || down("ArrowDown")) my += 1;
    const held = this.attackHeld || (!this.forced && (this.keys.has("Space") || this.keys.has("KeyJ")));
    const input = this.match.input;
    input.mx = mx;
    input.my = my;
    input.attackHeld = held;
    input.attackEdge = this.attackEdge || input.attackEdge;
    input.interactEdge = this.interactEdge || input.interactEdge;
    input.reloadEdge = this.reloadEdge || input.reloadEdge;
    input.slot = this.slot;
    input.cycle = this.cycle;
    input.assist = this.match.save.settings.aimAssist && !this.mouse.ok && !this.aim.on;
    if (this.aim.on) {
      input.aimOk = true;
      input.aimX = this.match.player.x + this.aim.x;
      input.aimY = this.match.player.y + this.aim.y;
    } else if (this.mouse.ok && !this.forced) {
      input.aimOk = true;
      input.aimX = this.mouse.x;
      input.aimY = this.mouse.y;
    } else {
      input.aimOk = false;
    }
    this.attackEdge = false;
    this.interactEdge = false;
    this.reloadEdge = false;
    this.slot = null;
    this.cycle = 0;
  }

  private frame = (now: number) => {
    if (!this.alive) return;
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.vis += dt;
    this.acc += dt;
    this.snapT += dt;
    let steps = 0;
    while (this.acc >= 1 / 60 && steps < 4) {
      this.sample();
      tick(this.match, 1 / 60);
      this.acc -= 1 / 60;
      steps++;
    }
    if (this.reduce) this.match.cam.shake = 0;
    const ctx = this.canvas.getContext("2d");
    if (ctx) {
      ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      render(ctx, this.match, this.vis);
    }
    if (!this.match.save.settings.muted) musicTick(this.match.phase === "combat" && !this.match.paused, dt);
    this.match.autosave += dt;
    if (this.match.autosave > 4 && this.match.phase !== "defeat") {
      this.match.autosave = 0;
      this.store(true);
    }
    this.emit(false);
    this.raf = requestAnimationFrame(this.frame);
  };
}
