import { createFileRoute } from "@tanstack/react-router";
import { SheepGame } from "@/components/sheep-game";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SheepGame />;
}
