import { useEffect, useRef, useState, type MutableRefObject, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import {
  Backpack,
  Coins,
  Heart,
  Pause,
  Settings,
  ShoppingBag,
  Sprout,
  Swords,
  Volume2,
  VolumeX,
  Wrench,
} from "lucide-react";
import {
  CATS,
  CAT_LABEL,
  COSMETICS,
  RARITY_LABEL,
  WEAPONS,
  ammoPackCost,
  structureRepairCost,
  weaponRepairCost,
  type CosmeticCat,
  type Rarity,
} from "@/game/content";
import { drawIcon, drawPoster } from "@/game/draw";
import { Engine } from "@/game/engine";
import type { Snapshot } from "@/game/logic";
import { tryBuyAmmo, tryBuyCosmetic, tryBuyWeapon, tryEquipWeapon, tryRepairWeapon } from "@/game/market";
import { playSfx, setAudio, unlockAudio } from "@/game/audio";
import { freshSave, loadSave, persist, type SaveData } from "@/game/save";

type Modal = null | "shop" | "inventory" | "settings" | "confirm";

const btn =
  "min-h-12 rounded-2xl border-2 border-ink px-4 font-display text-base font-extrabold disabled:opacity-40";
const primary = `${btn} bg-moss text-paper`;
const quiet = `${btn} bg-paper text-ink`;
const danger = `${btn} bg-berry text-paper`;

export function SheepGame() {
  const [save, setSave] = useState(freshSave);
  const [screen, setScreen] = useState<"menu" | "play">("menu");
  const [modal, setModal] = useState<Modal>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [mode, setMode] = useState<"new" | "continue">("new");
  const [playId, setPlayId] = useState(0);
  const [note, setNote] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const engineRef = useRef<Engine | null>(null);
  const saveRef = useRef(save);
  saveRef.current = save;

  useEffect(() => {
    const loaded = loadSave();
    setSave(loaded);
    setAudio(loaded.settings);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Escape" || screen !== "play") return;
      setPaused((p) => !p);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [screen]);

  useEffect(() => {
    engineRef.current?.setPaused(paused || modal !== null);
  }, [paused, modal]);

  function commit(live: SaveData) {
    setSave(structuredClone(live));
  }

  function begin(next: "new" | "continue") {
    unlockAudio();
    setMode(next);
    setModal(null);
    setPaused(false);
    setNote(null);
    setScreen("play");
    setPlayId((n) => n + 1);
  }

  function exitToMenu() {
    setScreen("menu");
    setModal(null);
    setPaused(false);
    setSnap(null);
  }

  function menuAct(fn: (s: SaveData) => string | null) {
    const live = saveRef.current;
    const before = live.coins;
    const err = fn(live);
    setNote(err);
    if (!err) {
      playSfx(live.coins < before ? "buy" : "ui");
      persist(live);
      commit(live);
    }
    return err;
  }

  const shopFromEngine = screen === "play" && engineRef.current;
  const api = {
    save,
    buyWeapon: (id: string) =>
      shopFromEngine ? engineRef.current!.doBuyWeapon(id) : menuAct((s) => tryBuyWeapon(s, id)),
    repair: (id: string, fraction: number) =>
      shopFromEngine ? engineRef.current!.doRepair(id, fraction) : menuAct((s) => tryRepairWeapon(s, id, fraction)),
    ammo: (id: string) => (shopFromEngine ? engineRef.current!.doAmmo(id) : menuAct((s) => tryBuyAmmo(s, id))),
    cosmetic: (id: string) =>
      shopFromEngine ? engineRef.current!.doBuyCosmetic(id) : menuAct((s) => tryBuyCosmetic(s, id)),
    equipWeapon: (id: string) =>
      shopFromEngine ? engineRef.current!.doEquipWeapon(id) : menuAct((s) => tryEquipWeapon(s, id)),
  };

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-moss text-ink">
      {screen === "menu" ? (
        <Menu
          save={save}
          note={note}
          onPlay={() => (save.run ? setModal("confirm") : begin("new"))}
          onContinue={() => begin("continue")}
          onShop={() => setModal("shop")}
          onBag={() => setModal("inventory")}
          onSettings={() => setModal("settings")}
        />
      ) : (
        <GameScreen
          playId={playId}
          mode={mode}
          save={saveRef.current}
          engineRef={engineRef}
          snap={snap}
          setSnap={setSnap}
          onSave={commit}
          paused={paused}
          setPaused={setPaused}
          onExit={exitToMenu}
          onShop={() => setModal("shop")}
          onBag={() => setModal("inventory")}
          onSettings={() => setModal("settings")}
          note={note}
          setNote={setNote}
        />
      )}
      {modal === "shop" && (
        <Shop save={save} note={note} onClose={() => setModal(null)} api={api} />
      )}
      {modal === "inventory" && (
        <Inventory save={save} note={note} onClose={() => setModal(null)} api={api} />
      )}
      {modal === "settings" && (
        <SettingsPanel
          save={save}
          onClose={() => setModal(null)}
          onChange={(partial) => {
            if (engineRef.current && screen === "play") engineRef.current.updateSettings(partial);
            else {
              save.settings = { ...save.settings, ...partial };
              setAudio(save.settings);
              persist(save);
              commit(save);
            }
          }}
        />
      )}
      {modal === "confirm" && (
        <Overlay>
          <h2 className="font-display text-2xl font-extrabold">Начать заново?</h2>
          <p className="text-sm text-ink/70">Текущий забег сбросится. Монеты, оружие и скины останутся.</p>
          <button className={danger} onClick={() => begin("new")}>
            Start
          </button>
          <button className={quiet} onClick={() => setModal(null)}>
            Назад
          </button>
        </Overlay>
      )}
    </main>
  );
}

function Menu({
  save,
  note,
  onPlay,
  onContinue,
  onShop,
  onBag,
  onSettings,
}: {
  save: SaveData;
  note: string | null;
  onPlay: () => void;
  onContinue: () => void;
  onShop: () => void;
  onBag: () => void;
  onSettings: () => void;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let raf = 0;
    let last = performance.now();
    let t = 0;
    const loop = (now: number) => {
      t += Math.min(0.05, (now - last) / 1000);
      last = now;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        drawPoster(ctx, rect.width, rect.height, t, save.equipped.sky, save.equipped.environment, save.equipped.sheep, save.equipped.vegetable);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [save.equipped]);
  return (
    <div className="relative h-full">
      <canvas ref={ref} className="absolute inset-0 h-full w-full" />
      <div className="relative flex h-full items-center justify-center p-4">
        <section className="flex w-full max-w-md flex-col gap-4 rounded-3xl border-2 border-ink bg-paper p-5">
          <div>
            <p className="text-xs font-extrabold tracking-wide text-moss">ОВОЩИ ПОД УГРОЗОЙ</p>
            <h1 className="font-display text-4xl font-extrabold leading-none">Sheep AI</h1>
            <p className="mt-2 text-sm text-ink/70">
              Овцы ищут лазейки, ломают забор и умнеют с каждой волной. Держите капусту.
            </p>
          </div>
          <div className="flex gap-3 text-sm font-extrabold">
            <span className="inline-flex items-center gap-1">
              <Coins className="size-4 text-gold" /> {save.coins}
            </span>
            <span>Рекорд: волна {save.stats.bestWave}</span>
          </div>
          {note && <p className="text-sm font-bold text-berry">{note}</p>}
          <button className={primary} onClick={onPlay}>
            <span className="block text-lg leading-tight">Start</span>
            <span className="block text-xs font-bold">Новая игра</span>
          </button>
          <button className={quiet} disabled={!save.run} onClick={onContinue}>
            Продолжить
          </button>
          <div className="grid grid-cols-3 gap-2">
            <button className={quiet} onClick={onShop}>
              <ShoppingBag className="mx-auto size-5" />
              Магазин
            </button>
            <button className={quiet} onClick={onBag}>
              <Backpack className="mx-auto size-5" />
              Инвентарь
            </button>
            <button className={quiet} onClick={onSettings}>
              <Settings className="mx-auto size-5" />
              Настройки
            </button>
          </div>
          <p className="desktop-only text-xs text-ink/70">
            WASD — бег, мышь — прицел, ЛКМ — удар, E — ворота, R — перезарядка, Q — другое оружие, 1–9 — слот.
          </p>
        </section>
      </div>
    </div>
  );
}

function GameScreen({
  playId,
  mode,
  save,
  engineRef,
  snap,
  setSnap,
  onSave,
  paused,
  setPaused,
  onExit,
  onShop,
  onBag,
  onSettings,
  note,
  setNote,
}: {
  playId: number;
  mode: "new" | "continue";
  save: SaveData;
  engineRef: MutableRefObject<Engine | null>;
  snap: Snapshot | null;
  setSnap: (s: Snapshot) => void;
  onSave: (s: SaveData) => void;
  paused: boolean;
  setPaused: (p: boolean) => void;
  onExit: () => void;
  onShop: () => void;
  onBag: () => void;
  onSettings: () => void;
  note: string | null;
  setNote: (s: string | null) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let engine: Engine;
    try {
      engine = new Engine(
        canvas,
        save,
        {
          onSnapshot: setSnap,
          onSave,
        },
        mode,
      );
    } catch {
      setNote("Сохранение забега повреждено");
      onExit();
      return;
    }
    engineRef.current = engine;
    return () => {
      engine.quit();
      engine.destroy();
      if (engineRef.current === engine) engineRef.current = null;
    };
  }, [playId]);

  const s = snap;
  return (
    <div className="relative h-full">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />
      {s && (
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3">
          <div className="flex flex-wrap items-start gap-2">
            <HudCard>
              <Coins className="size-4 text-gold" />
              <span className="font-extrabold">{s.coins}</span>
            </HudCard>
            <HudCard>Волна {s.wave}</HudCard>
            <HudCard>
              <Heart className="size-4 text-berry" />
              <Meter value={s.playerHp / s.playerMax} tone="bg-berry" />
            </HudCard>
            <HudCard>
              <Sprout className="size-4 text-moss" />
              <Meter value={s.garden} tone="bg-moss" />
            </HudCard>
            <button className={`${quiet} pointer-events-auto min-h-11 px-3`} onClick={() => setPaused(true)}>
              <Pause className="size-5" />
            </button>
          </div>
          <div className="flex items-end justify-between gap-3">
            <HudCard>
              <Swords className="size-4" />
              <div className="min-w-36">
                <div className="text-sm font-extrabold">{s.weaponName}</div>
                <Meter value={s.durability / Math.max(1, s.durabilityMax)} tone={s.warn ? "bg-berry" : "bg-gold"} />
                <div className="text-xs font-bold text-ink/70">
                  {s.broken ? "Сломано" : s.reloading ? "Перезарядка" : s.loaded !== null ? `${s.loaded} / ${s.reserve}` : "Ближний бой"}
                </div>
              </div>
            </HudCard>
            <div className="desktop-only max-w-xs text-right text-xs font-bold text-paper">
              {s.prompt ?? "Держите овец снаружи"}
            </div>
          </div>
        </div>
      )}
      {s?.bossHp !== null && s?.bossMax && (
        <div className="pointer-events-none absolute inset-x-0 top-20 mx-auto w-full max-w-md px-4">
          <div className="rounded-2xl border-2 border-ink bg-paper px-3 py-2">
            <div className="text-xs font-extrabold">{s.bossName}</div>
            <Meter value={s.bossHp / s.bossMax} tone="bg-gold" />
          </div>
        </div>
      )}
      {s?.alert && (
        <div className="pointer-events-none absolute top-20 left-1/2 -translate-x-1/2 rounded-full border-2 border-ink bg-berry px-4 py-1 text-sm font-extrabold text-paper">
          {s.alert === "garden" ? "Овцы в огороде" : s.alert === "boss" ? "Вожак на поле" : "Ломают забор"}
        </div>
      )}
      {s && s.countdown <= 0 && s.mods.length > 0 && (
        <div className="pointer-events-none absolute top-16 right-3 rounded-2xl border-2 border-ink bg-paper px-3 py-1 text-xs font-extrabold">
          {s.mods.join(" · ")}
        </div>
      )}
      {(s?.toast || note) && (
        <div className="pointer-events-none absolute top-28 left-1/2 -translate-x-1/2 rounded-full bg-ink px-4 py-2 text-sm font-extrabold text-paper">
          {note ?? s?.toast}
        </div>
      )}
      <div className="touch-only pointer-events-none absolute inset-x-0 bottom-4 flex items-end justify-between px-4">
        <Stick
          label="Движение"
          onVec={(x, y) => engineRef.current?.setJoy(x, y)}
        />
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          {s?.prompt && (
            <button className={quiet} onClick={() => engineRef.current?.interact()}>
              Ворота
            </button>
          )}
          <button className={quiet} onClick={() => engineRef.current?.cycleWeapon(1)}>
            Оружие
          </button>
          <button
            className="size-20 rounded-full border-2 border-ink bg-berry text-sm font-extrabold text-paper"
            onPointerDown={(e) => {
              e.preventDefault();
              engineRef.current?.setAttack(true);
            }}
            onPointerUp={() => engineRef.current?.setAttack(false)}
            onPointerCancel={() => engineRef.current?.setAttack(false)}
          >
            Удар
          </button>
        </div>
        <Stick
          label="Прицел"
          onVec={(x, y) => engineRef.current?.setAimStick(x, y, Math.hypot(x, y) > 0.25)}
        />
      </div>
      {paused && s?.phase !== "defeat" && (
        <Overlay>
          <h2 className="font-display text-2xl font-extrabold">Пауза</h2>
          <button className={primary} onClick={() => setPaused(false)}>
            Продолжить
          </button>
          <button className={quiet} onClick={onShop}>
            Магазин
          </button>
          <button className={quiet} onClick={onBag}>
            Инвентарь
          </button>
          <button className={quiet} onClick={onSettings}>
            Настройки
          </button>
          <button className={danger} onClick={onExit}>
            В меню
          </button>
        </Overlay>
      )}
      {s?.phase === "intermission" && !paused && (
        <Overlay>
          <h2 className="font-display text-2xl font-extrabold">Волна {s.wave} отбита</h2>
          <p className="text-sm text-ink/70">
            Убито {s.kills}. Заработано {s.earned} монет. Огород {Math.round(s.garden * 100)}%.
          </p>
          <button
            className={quiet}
            disabled={structureRepairCost(s.fenceMissing) <= 0}
            onClick={() => setNote(engineRef.current?.doRepairFences() ?? null)}
          >
            <Wrench className="mr-2 inline size-4" />
            Забор · {structureRepairCost(s.fenceMissing)}
          </button>
          <button
            className={quiet}
            disabled={structureRepairCost(s.cropMissing) <= 0}
            onClick={() => setNote(engineRef.current?.doRepairCrops() ?? null)}
          >
            <Sprout className="mr-2 inline size-4" />
            Урожай · {structureRepairCost(s.cropMissing)}
          </button>
          <button className={quiet} onClick={onShop}>
            Магазин
          </button>
          <button className={primary} onClick={() => engineRef.current?.goNextWave()}>
            Дальше
          </button>
        </Overlay>
      )}
      {s?.phase === "defeat" && s.result && (
        <Overlay>
          <h2 className="font-display text-2xl font-extrabold">Огород пал</h2>
          <ul className="grid gap-1 text-sm font-bold">
            <li>Волна: {s.result.wave}</li>
            <li>Овец снято: {s.result.kills}</li>
            <li>Монет за забег: {s.result.earned}</li>
            <li>Самый опасный: {s.result.bestName}</li>
            <li>Оружие: {s.result.weaponName}</li>
            <li>Урожай остался: {Math.round(s.result.garden * 100)}%</li>
          </ul>
          <button
            className={primary}
            onClick={() => {
              onExit();
            }}
          >
            В меню
          </button>
        </Overlay>
      )}
    </div>
  );
}

function Shop({
  save,
  note,
  onClose,
  api,
}: {
  save: SaveData;
  note: string | null;
  onClose: () => void;
  api: {
    buyWeapon: (id: string) => string | null;
    cosmetic: (id: string) => string | null;
  };
}) {
  const [cat, setCat] = useState<CosmeticCat | "arms">("arms");
  const [rarity, setRarity] = useState<Rarity | "all">("all");
  const [sel, setSel] = useState(WEAPONS[0]!.id);
  const items =
    cat === "arms"
      ? WEAPONS.map((w) => ({ id: w.id, name: w.name, desc: w.blurb, price: w.unlock, rarity: "common" as Rarity, owned: save.weapons[w.id]?.unlocked ?? false }))
      : COSMETICS.filter((c) => c.cat === cat && (rarity === "all" || c.rarity === rarity)).map((c) => ({
          id: c.id,
          name: c.name,
          desc: c.desc,
          price: c.price,
          rarity: c.rarity,
          owned: save.owned.includes(c.id),
        }));
  const current = items.find((i) => i.id === sel) ?? items[0];
  return (
    <section className="absolute inset-0 z-30 overflow-y-auto bg-paper">
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 p-4 pb-10">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-extrabold">Магазин</h2>
          <span className="inline-flex items-center gap-1 font-extrabold">
            <Coins className="size-4 text-gold" /> {save.coins}
          </span>
        </div>
        <div className="flex gap-2 overflow-x-auto">
          <button className={cat === "arms" ? primary : quiet} onClick={() => setCat("arms")}>
            Оружие
          </button>
          {CATS.map((c) => (
            <button key={c} className={cat === c ? primary : quiet} onClick={() => setCat(c)}>
              {CAT_LABEL[c]}
            </button>
          ))}
        </div>
        {cat !== "arms" && (
          <div className="flex flex-wrap gap-2">
            <button className={rarity === "all" ? primary : quiet} onClick={() => setRarity("all")}>
              Все
            </button>
            {(Object.keys(RARITY_LABEL) as Rarity[]).map((r) => (
              <button key={r} className={rarity === r ? primary : quiet} onClick={() => setRarity(r)}>
                {RARITY_LABEL[r]}
              </button>
            ))}
          </div>
        )}
        {note && <p className="text-sm font-bold text-berry">{note}</p>}
        <div className="grid gap-3 sm:grid-cols-[1fr_220px]">
          <div className="grid gap-2">
            {items.map((item) => (
              <button
                key={item.id}
                className={`rounded-2xl border-2 p-3 text-left ${sel === item.id ? "border-moss bg-moss/10" : "border-ink bg-paper"}`}
                onClick={() => setSel(item.id)}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-extrabold">{item.name}</span>
                  <span className="text-sm font-extrabold text-gold">{item.owned ? "есть" : item.price}</span>
                </div>
                <div className={`text-xs font-bold ${rarityTone(item.rarity)}`}>{RARITY_LABEL[item.rarity]}</div>
              </button>
            ))}
          </div>
          {current && (
            <div className="rounded-3xl border-2 border-ink p-3">
              <Preview cat={cat === "arms" ? "weapon" : cat} id={cat === "arms" ? save.equipped.weapon : current.id} />
              <h3 className="mt-2 font-extrabold">{current.name}</h3>
              <p className="text-sm text-ink/70">{current.desc}</p>
              {cat === "arms" && <p className="mt-1 text-xs font-bold text-ink/70">Косметика не меняет урон. Это отдельная вкладка.</p>}
              <button
                className={`${primary} mt-3 w-full`}
                onClick={() => {
                  if (cat === "arms") api.buyWeapon(current.id);
                  else api.cosmetic(current.id);
                }}
              >
                {current.owned ? "Надеть" : `Купить · ${current.price}`}
              </button>
            </div>
          )}
        </div>
        <button className={quiet} onClick={onClose}>
          Назад
        </button>
      </div>
    </section>
  );
}

function Inventory({
  save,
  note,
  onClose,
  api,
}: {
  save: SaveData;
  note: string | null;
  onClose: () => void;
  api: {
    repair: (id: string, fraction: number) => string | null;
    ammo: (id: string) => string | null;
    equipWeapon: (id: string) => string | null;
    cosmetic: (id: string) => string | null;
  };
}) {
  const ownedWeapons = WEAPONS.filter((w) => save.weapons[w.id]?.unlocked);
  return (
    <section className="absolute inset-0 z-30 overflow-y-auto bg-paper">
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 p-4 pb-10">
        <h2 className="font-display text-2xl font-extrabold">Инвентарь</h2>
        <p className="inline-flex items-center gap-1 font-extrabold">
          <Coins className="size-4 text-gold" /> {save.coins}
        </p>
        {note && <p className="text-sm font-bold text-berry">{note}</p>}
        <div className="grid gap-3">
          {ownedWeapons.map((w) => {
            const st = save.weapons[w.id]!;
            const full = weaponRepairCost(w, st.durability, 1);
            const half = weaponRepairCost(w, st.durability, 0.5);
            const on = save.equippedWeapon === w.id;
            return (
              <article key={w.id} className="rounded-2xl border-2 border-ink p-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-extrabold">{w.name}</h3>
                  <span className="text-xs font-bold">{on ? "В руках" : ""}</span>
                </div>
                <p className="text-sm text-ink/70">{w.blurb}</p>
                <div className="mt-2">
                  <Meter value={st.durability / w.durability} tone={st.durability / w.durability <= 0.2 ? "bg-berry" : "bg-gold"} />
                  <p className="text-xs font-bold text-ink/70">
                    Прочность {Math.ceil(st.durability)}/{w.durability}
                    {w.kind === "gun" ? ` · патроны ${st.loaded}/${st.reserve}` : ""}
                  </p>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {!on && (
                    <button className={quiet} onClick={() => api.equipWeapon(w.id)}>
                      Взять
                    </button>
                  )}
                  <button className={quiet} disabled={full <= 0} onClick={() => api.repair(w.id, 1)}>
                    Полный ремонт · {full}
                  </button>
                  <button className={quiet} disabled={half <= 0} onClick={() => api.repair(w.id, 0.5)}>
                    Половина · {half}
                  </button>
                  {w.kind === "gun" && (
                    <button className={quiet} onClick={() => api.ammo(w.id)}>
                      Обойма · {ammoPackCost(w)}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
        <h3 className="font-display text-xl font-extrabold">Скины</h3>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {COSMETICS.filter((c) => save.owned.includes(c.id)).map((c) => {
            const on = save.equipped[c.cat] === c.id;
            return (
              <button key={c.id} className={`rounded-2xl border-2 p-3 text-left ${on ? "border-moss" : "border-ink"}`} onClick={() => api.cosmetic(c.id)}>
                <Preview cat={c.cat} id={c.id} />
                <div className="mt-1 text-sm font-extrabold">{c.name}</div>
                <div className={`text-xs font-bold ${rarityTone(c.rarity)}`}>{on ? "Надето" : RARITY_LABEL[c.rarity]}</div>
              </button>
            );
          })}
        </div>
        <button className={quiet} onClick={onClose}>
          Назад
        </button>
      </div>
    </section>
  );
}

function SettingsPanel({
  save,
  onClose,
  onChange,
}: {
  save: SaveData;
  onClose: () => void;
  onChange: (partial: Partial<SaveData["settings"]>) => void;
}) {
  const s = save.settings;
  return (
    <section className="absolute inset-0 z-30 flex items-center justify-center bg-ink/40 p-4">
      <div className="flex w-full max-w-md flex-col gap-4 rounded-3xl border-2 border-ink bg-paper p-5">
        <h2 className="font-display text-2xl font-extrabold">Настройки</h2>
        <label className="grid gap-2 text-sm font-extrabold">
          Громкость
          <input
            className="accent-moss"
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={s.volume}
            onChange={(e) => onChange({ volume: Number(e.target.value) })}
          />
        </label>
        <button className={quiet} onClick={() => onChange({ muted: !s.muted })}>
          {s.muted ? <VolumeX className="mr-2 inline size-4" /> : <Volume2 className="mr-2 inline size-4" />}
          {s.muted ? "Звук выключен" : "Звук включён"}
        </button>
        <button className={quiet} onClick={() => onChange({ shake: !s.shake })}>
          Тряска экрана: {s.shake ? "да" : "нет"}
        </button>
        <button className={quiet} onClick={() => onChange({ aimAssist: !s.aimAssist })}>
          Помощь прицела: {s.aimAssist ? "да" : "нет"}
        </button>
        <p className="text-xs text-ink/70">Помощь прицела наводится на ближайшую овцу, если нет мыши или правого стика.</p>
        <button className={primary} onClick={onClose}>
          Готово
        </button>
      </div>
    </section>
  );
}

function Overlay({ children }: { children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-ink/35 p-4">
      <div className="flex w-full max-w-md flex-col gap-3 rounded-3xl border-2 border-ink bg-paper p-5">{children}</div>
    </div>
  );
}

function HudCard({ children }: { children: ReactNode }) {
  return (
    <div className="pointer-events-none flex min-h-11 items-center gap-2 rounded-2xl border-2 border-ink bg-paper px-3 py-1 text-sm font-bold">
      {children}
    </div>
  );
}

function Meter({ value, tone }: { value: number; tone: string }) {
  const width = `${Math.max(0, Math.min(100, Math.round(value * 100)))}%`;
  return (
    <div className="h-2 w-24 overflow-hidden rounded-full border border-ink bg-paper">
      <div className={`h-full ${tone}`} style={{ width }} />
    </div>
  );
}

function Stick({ label, onVec }: { label: string; onVec: (x: number, y: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [k, setK] = useState({ x: 0, y: 0 });
  function read(e: ReactPointerEvent<HTMLDivElement>) {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    let x = (e.clientX - (r.left + r.width / 2)) / (r.width * 0.36);
    let y = (e.clientY - (r.top + r.height / 2)) / (r.height * 0.36);
    const len = Math.hypot(x, y);
    if (len > 1) {
      x /= len;
      y /= len;
    }
    setK({ x, y });
    onVec(x, y);
  }
  return (
    <div
      ref={ref}
      role="slider"
      aria-label={label}
      aria-valuemin={-1}
      aria-valuemax={1}
      aria-valuenow={Math.round(k.x * 100) / 100}
      className="pointer-events-auto relative size-32 touch-none rounded-full border-2 border-ink bg-paper/80"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        read(e);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) read(e);
      }}
      onPointerUp={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        setK({ x: 0, y: 0 });
        onVec(0, 0);
      }}
    >
      <div
        className="absolute top-1/2 left-1/2 size-12 rounded-full border-2 border-ink bg-moss"
        style={{ transform: `translate(calc(-50% + ${k.x * 34}px), calc(-50% + ${k.y * 34}px))` }}
      />
    </div>
  );
}

function Preview({ cat, id }: { cat: string; id: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    drawIcon(ctx, cat, id, canvas.width, canvas.height);
  }, [cat, id]);
  return <canvas ref={ref} width={180} height={110} className="h-24 w-full rounded-xl border-2 border-ink bg-paper" />;
}

function rarityTone(r: Rarity) {
  if (r === "exotic" || r === "epic") return "text-berry";
  if (r === "legendary" || r === "rare") return "text-gold";
  if (r === "uncommon") return "text-moss";
  return "text-ink/70";
}
