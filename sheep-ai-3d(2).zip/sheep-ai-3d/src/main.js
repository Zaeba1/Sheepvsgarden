// Sheep AI 3D — точка входа. Собирает модули, строит сцену, запускает цикл.
import * as THREE from 'three';
import { CFG } from './config.js';
import { makeRng } from './utils/math.js';
import { GameLoop } from './core/loop.js';
import { PhysicsWorld } from './physics/world2d.js';
import { buildTerrain } from './world/terrain.js';
import { buildVegetation } from './world/vegetation.js';
import { buildProps } from './world/props.js';
import { buildSheepMesh, makeSheepMaterials } from './entities/sheepModel.js';
import { Sheep } from './entities/sheep.js';
import { herdForces, propagatePanic, startleNear } from './ai/herd.js';
import { TouchInput } from './input/touchInput.js';
import { CameraController } from './camera/cameraController.js';
import { InteractionSystem } from './interaction/interaction.js';
import { Particles } from './effects/particles.js';
import { AudioSystem } from './audio/audio.js';
import { Hud } from './ui/hud.js';

function boot() {
  const app = document.getElementById('app');
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  app.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(CFG.colors.sky);
  scene.fog = new THREE.Fog(CFG.colors.fog, 34, 70);

  const camera = new THREE.PerspectiveCamera(CFG.camera.fov, innerWidth / innerHeight, 0.1, 120);

  // --- освещение: мягкий день ---
  const hemi = new THREE.HemisphereLight(0xcfe8ff, 0x6a8f5a, 0.9);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff3d6, 1.6);
  sun.position.set(18, 26, 10);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const sc = CFG.world.half + 6;
  sun.shadow.camera.left = -sc; sun.shadow.camera.right = sc;
  sun.shadow.camera.top = sc; sun.shadow.camera.bottom = -sc;
  sun.shadow.camera.far = 80;
  sun.shadow.bias = -0.0004;
  scene.add(sun);

  // --- мир ---
  const phys = new PhysicsWorld();
  const terrain = buildTerrain();
  scene.add(terrain.mesh);
  const veg = buildVegetation(terrain.heightAt);
  scene.add(veg.group);
  const props = buildProps(scene, phys, terrain.heightAt);

  // синхронизация draggable-мешей с физическими телами
  const draggables = props.draggables;

  // --- овцы ---
  const rng = makeRng(2026);
  const sheepMats = makeSheepMaterials();
  // sheep.js строит модель через фабрику ниже (инъекция, чтобы держать модули раздельными)
  globalThis.__buildSheepMesh = buildSheepMesh;
  const sheep = [];
  for (let i = 0; i < CFG.sheep.count; i++) {
    sheep.push(new Sheep(rng, scene, phys, sheepMats, veg.grassSpots));
  }

  // --- системы ---
  const cam = new CameraController(camera, renderer.domElement);
  // ворота — не физическое тело; ловим их 3D-raycast'ом по мешу
  const gatePicker = (raycaster) => {
    const hits = raycaster.intersectObject(props.gate.mesh, false);
    if (!hits.length) return null;
    return { ref: props.gate, kind: 'gate', tag: 'gate', x: props.gate.mesh.position.x,
             z: props.gate.mesh.position.z, radius: 1.2 };
  };
  const input = new TouchInput(renderer.domElement, camera, phys, terrain, gatePicker);
  const particles = new Particles(scene);
  const audio = new AudioSystem();
  const interaction = new InteractionSystem({
    input, sheep, cameraCtl: cam, particles, audio, props,
  });
  interaction._scene(scene);
  const hud = new Hud(null, audio); // loop присвоим ниже

  // аудио требует жеста — включаем по первому касанию
  const unlock = () => { audio._ensure(); audio.resume(); };
  renderer.domElement.addEventListener('pointerdown', unlock, { once: true });

  // --- цикл ---
  const state = { sheep: sheep.length, happy: 0, fleeing: 0 };
  let panicAcc = 0;

  const update = (dt) => {
    phys.step(dt);
    for (const s of sheep) {
      s.update(dt, sheep, herdForces);
      // взгляд в сторону приманки — любопытство
      if (s.brain.state === 'go_to' && s.brain.lure) {
        // лёгкий наклон головы уже обрабатывает аниматор
      }
    }
    // распространение испуга — дискретно, 5 раз в секунду (не каждый кадр)
    panicAcc += dt;
    if (panicAcc > 0.2) {
      panicAcc = 0;
      for (const s of sheep) propagatePanic(s, sheep);
    }
    // синхронизация копен
    for (const d of draggables) {
      d.mesh.position.x = d.body.x;
      d.mesh.position.z = d.body.z;
      d.mesh.position.y = terrain.heightAt(d.body.x, d.body.z) + 0.65;
      d.mesh.rotation.x += (d.body.vx + d.body.vz) * dt * 0.4; // кочение
    }
    interaction.update(dt);
    particles.update(dt);
    // статистика
    let happy = 0, fleeing = 0;
    for (const s of sheep) {
      if (s.brain.state === 'booped') happy++;
      if (s.brain.state === 'flee') fleeing++;
    }
    state.happy = happy; state.fleeing = fleeing;
  };

  const render = (dt) => {
    cam.update(dt);
    hud.update(dt, state);
    renderer.render(scene, camera);
  };

  const loop = new GameLoop(update, render);
  hud.loop = loop;
  loop.start();

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  window.__booted = true;
  document.getElementById('loading').style.opacity = '0';
  setTimeout(() => document.getElementById('loading').remove(), 600);
}

try {
  boot();
} catch (err) {
  const el = document.getElementById('loading');
  if (el) el.textContent = 'Ошибка запуска: ' + err.message;
  console.error(err);
}
