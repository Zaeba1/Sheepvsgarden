// Связка ввода и мира: тапы, приманка (hold), перетаскивание сена и ворот.
import * as THREE from 'three';
import { CFG } from '../config.js';
import { v2, clamp } from '../utils/math.js';
import { startleNear } from '../ai/herd.js';

export class InteractionSystem {
  constructor({ input, sheep, cameraCtl, particles, audio, props }) {
    this.sheep = sheep; this.cam = cameraCtl;
    this.particles = particles; this.audio = audio;
    this.props = props;
    this.lure = null;             // {x,z,mesh,ttl,active}
    this.drag = null;             // {kind, body/mesh, gate?}

    // --- визуал приманки ---
    const ringGeo = new THREE.RingGeometry(0.5, 0.62, 32);
    ringGeo.rotateX(-Math.PI / 2);
    this.lureMesh = new THREE.Mesh(ringGeo,
      new THREE.MeshBasicMaterial({ color: 0xfff2b0, transparent: true, opacity: 0.9 }));
    this.lureMesh.visible = false;
    input.on('hold', (e) => this._startLure(e.ground));
    input.on('dragStart', (e) => this._dragStart(e));
    input.on('dragMove', (e) => this._dragMove(e));
    input.on('dragEnd', () => this._dragEnd());
    input.on('tap', (e) => this._tap(e));
  }

  _scene(scene) { this.scene = scene; scene.add(this.lureMesh); }

  _startLure(g) {
    const half = CFG.world.half - 1.5;
    const x = clamp(g.x, -half, half), z = clamp(g.z, -half, half);
    if (!this.lure) {
      this.lure = { x, z, ttl: CFG.input.lureLife, active: true };
    } else { this.lure.x = x; this.lure.z = z; this.lure.ttl = CFG.input.lureLife; this.lure.active = true; }
    for (const s of this.sheep) s.brain.setLure(this.lure);
    this.audio.chime();
    this.particles.ring(x, z, 0xfff2b0);
  }

  _tap(e) {
    const g = e.ground;
    if (e.body && e.body.tag === 'sheep') {
      const s = e.body.ref;
      s.boop(g.x, g.z);
      this.audio.bleat(0.7 + Math.random() * 0.3, true);
      this.particles.hearts(e.body.x, e.body.z);
      this.cam.setFocus(new THREE.Vector3(e.body.x, 0, e.body.z), 0.6);
    } else if (e.body && e.body.tag === 'hay') {
      // лёгкий тычок в копну — она катится
      const dx = e.body.x - g.x, dz = e.body.z - g.z;
      const l = Math.hypot(dx, dz) || 1;
      e.body.vx += dx / l * 3; e.body.vz += dz / l * 3;
      this.audio.thump();
      this.particles.puff(e.body.x, e.body.z, 0xd9b64a);
    } else {
      // тап по земле — щелчок и лёгкий испуг совсем рядом
      startleNear(this.sheep, g.x, g.z, 1.2, 0.35);
      this.audio.tick();
      this.particles.ring(g.x, g.z, 0xffffff, 0.6);
    }
  }

  _dragStart(e) {
    if (e.body && e.body.tag === 'hay') {
      this.drag = { kind: 'hay', body: e.body };
      e.body.mass = 3;
    } else if (e.body && e.body.kind === 'gate') {
      this.drag = { kind: 'gate', gate: e.body };
    } else if (e.fromGround) {
      // перетаскивание по земле — ведём приманку за пальцем
      this._startLure(e.ground);
      this.drag = { kind: 'lure' };
    }
  }

  _dragMove(e) {
    const g = e.ground;
    if (!this.drag) return;
    if (this.drag.kind === 'hay') {
      const b = this.drag.body;
      // пружинное притягивание к точке под пальцем — «тяни копну»
      const dx = g.x - b.x, dz = g.z - b.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.4) {
        // пружинное притягивание: скорость к цели, ограниченная по модулю
        const k = Math.min(d * 3.2, 5.5);
        b.vx = clamp(b.vx + (dx / d) * k * 0.12, -5, 5);
        b.vz = clamp(b.vz + (dz / d) * k * 0.12, -5, 5);
      }
      this.cam.setFocus(new THREE.Vector3(b.x, 0, b.z), 0.25);
    } else if (this.drag.kind === 'gate') {
      const gate = this.drag.gate;
      // горизонтальный жест открывает/закрывает ворота
      gate.setOpen(clamp(gate.open + 0.0 + (this._lastGx !== undefined ? (g.x - this._lastGx) * 0.15 : 0), 0, 1));
      this._lastGx = g.x;
      if (gate.open > 0.05 && !gate._creaked) { gate._creaked = true; this.audio.creak(); }
      if (gate.open <= 0.05) gate._creaked = false;
    } else if (this.drag.kind === 'lure' && this.lure) {
      const half = CFG.world.half - 1.5;
      this.lure.x = clamp(g.x, -half, half);
      this.lure.z = clamp(g.z, -half, half);
      this.lure.ttl = CFG.input.lureLife;
    }
  }

  _dragEnd() {
    if (this.drag && this.drag.kind === 'lure' && this.lure) {
      // приманку можно оставить: она живёт lureLife секунд
      for (const s of this.sheep) s.brain.setLure(this.lure);
    }
    this._lastGx = undefined;
    this.drag = null;
  }

  update(dt) {
    if (this.lure) {
      this.lure.ttl -= dt;
      if (this.lure.ttl <= 0) {
        this.lure.active = false; this.lure = null;
        this.lureMesh.visible = false;
        for (const s of this.sheep) s.brain.setLure(null);
      } else {
        this.lureMesh.visible = true;
        this.lureMesh.position.set(this.lure.x, 0.08, this.lure.z);
        const p = 1 + Math.sin(performance.now() * 0.004) * 0.12;
        this.lureMesh.scale.setScalar(p * CFG.input.lureRadius * 0.5);
        this.lureMesh.material.opacity = clamp(this.lure.ttl, 0, 1) * 0.9;
      }
    }
  }
}
