# assets/

Игра **не требует** внешних файлов: вся графика (овцы, игрок, доски, капуста, земля, фон, иконки)
рисуется в `js/assets.js` на Canvas с двойной чёткостью, звук синтезируется через Web Audio.
Поэтому лицензионных ограничений и атрибуции нет: все ресурсы созданы для этого проекта.

## Как заменить спрайт на свой PNG/WEBP
Создайте `assets/overrides.json` (работает при публикации по http/https, например на GitHub Pages):

```json
{
  "item_hammer": "assets/hammer.png",
  "item_shovel": "assets/shovel.png",
  "item_stone": "assets/stone.png",
  "board_oak_0": "assets/board_oak_0.png",
  "post_oak": "assets/post.png",
  "cabbage_0": "assets/cabbage.png",
  "backdrop": "assets/backdrop.png"
}
```

Имена: `item_<hammer|shovel|stone|sledge>`, `board_<oak|birch|red|blue>_<0|1|2>`,
`post_<скин>`, `cabbage_<0..3>`, `backdrop`. Если картинка не загрузилась, остаётся встроенная графика,
в консоль пишется предупреждение.
