/*
 * Физика забора (верле-частицы). Каждая доска — две частицы-конца с жёсткой связью,
 * «гвозди» (пружины к исходному месту) и стыки с соседними досками, которые рвутся при растяжении.
 */
(function () {
  'use strict';
  var G = 1500;
  var HALF = 8.5;               // половина толщины доски
  var NAIL_BREAK = 34;          // смещение, при котором вырывается гвоздь
  var Fence = { boards: [], joints: [], skin: 'oak', drag: null, events: null };

  function P(x, y) { return { x: x, y: y, px: x, py: y }; }
  function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y; return Math.sqrt(dx * dx + dy * dy); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function jointLimit(j) {
    var r = Math.min(Fence.boards[j.bi].reinf, Fence.boards[j.bj].reinf);
    return j.rest * (1.9 + 0.4 * r);
  }
  function maxHpFor(reinf) { return 60 + 20 * reinf; }

  Fence.reset = function (skin) {
    Fence.skin = skin || Fence.skin;
    Fence.boards = []; Fence.joints = []; Fence.drag = null;
    var fl = C.FENCE_L_X, fr = C.FENCE_R_X;
    for (var i = 0; i < C.BOARD_N; i++) {
      var y = C.GROUND - C.PITCH * (i + 0.5) - 1;
      var b = { i: i, a: P(fl, y), b: P(fr, y), len: C.FENCE_L, hx0: fl, hy0: y, hx1: fr, hy1: y,
        nA: true, nB: true, hp: 60, maxHp: 60, reinf: 0, dead: false, flash: 0, variant: i % 3 };
      Fence.boards.push(b);
      if (i > 0) {
        Fence.joints.push({ p: Fence.boards[i - 1].a, q: b.a, rest: C.PITCH, broken: false, bi: i - 1, bj: i });
        Fence.joints.push({ p: Fence.boards[i - 1].b, q: b.b, rest: C.PITCH, broken: false, bi: i - 1, bj: i });
      }
    }
  };

  function emit(name, a, b, c) { if (Fence.events && Fence.events[name]) Fence.events[name](a, b, c); }

  Fence.kill = function (b, dirX) {
    if (b.dead) return;
    b.dead = true; b.nA = false; b.nB = false; b.hp = 0;
    Fence.joints.forEach(function (j) { if (j.bi === b.i || j.bj === b.i) j.broken = true; });
    var d = dirX || (Math.random() < 0.7 ? -1 : 1);
    [b.a, b.b].forEach(function (p, k) {
      p.px = p.x - d * (3.2 + Math.random() * 2.4);
      p.py = p.y + (4 + Math.random() * 3 + k);
    });
    emit('break', b);
  };

  Fence.damage = function (b, dmg, dirX) {
    if (b.dead) return false;
    b.hp -= dmg; b.flash = 0.18;
    if (b.hp <= 0) { Fence.kill(b, dirX); return true; }
    return false;
  };

  /* Ремонт/укрепление. Возвращает 'revive' | 'heal' | 'reinforce' | 'max' */
  Fence.repair = function (b) {
    if (b.dead) {
      b.dead = false; b.hp = 35; b.flash = 0.2;
      return Fence.tryReplant(b) ? 'revive' : 'revive_far';
    }
    if (b.hp < b.maxHp - 0.5) { b.hp = Math.min(b.maxHp, b.hp + 30); b.flash = 0.2; Fence.tryReplant(b); return 'heal'; }
    if (!(b.nA && b.nB)) { return Fence.tryReplant(b) ? 'replant' : 'far'; }
    if (b.reinf < 3) { b.reinf++; b.maxHp = maxHpFor(b.reinf); b.hp = b.maxHp; b.flash = 0.25; return 'reinforce'; }
    return 'max';
  };

  Fence.tryReplant = function (b) {
    if (b.nA && b.nB) return true;
    var da = dist(b.a, { x: b.hx0, y: b.hy0 }) + dist(b.b, { x: b.hx1, y: b.hy1 });
    var db = dist(b.a, { x: b.hx1, y: b.hy1 }) + dist(b.b, { x: b.hx0, y: b.hy0 });
    if (Math.min(da, db) > 190) return false;
    b.a.x = b.a.px = b.hx0; b.a.y = b.a.py = b.hy0;
    b.b.x = b.b.px = b.hx1; b.b.y = b.b.py = b.hy1;
    b.nA = b.nB = true;
    Fence.joints.forEach(function (j) { if (j.bi === b.i || j.bj === b.i) j.broken = false; });
    emit('replant', b);
    return true;
  };

  Fence.segDist = function (b, x, y) {
    var ax = b.a.x, ay = b.a.y, bx = b.b.x, by = b.b.y, dx = bx - ax, dy = by - ay;
    var l2 = dx * dx + dy * dy || 1, t = clamp(((x - ax) * dx + (y - ay) * dy) / l2, 0, 1);
    var px = ax + dx * t, py = ay + dy * t, ex = x - px, ey = y - py;
    return { d: Math.sqrt(ex * ex + ey * ey), t: t };
  };

  Fence.nearest = function (x, y, maxD) {
    var best = null, bd = maxD;
    Fence.boards.forEach(function (b) { var r = Fence.segDist(b, x, y); if (r.d < bd) { bd = r.d; best = b; } });
    return best;
  };

  /* ----- перетаскивание ----- */
  Fence.beginDrag = function (x, y) {
    var best = null, bd = 17, bt = 0.5;
    Fence.boards.forEach(function (b) { var r = Fence.segDist(b, x, y); if (r.d < bd) { bd = r.d; best = b; bt = r.t; } });
    if (!best) return false;
    var mode = bt < 0.27 ? 'a' : bt > 0.73 ? 'b' : 'both';
    Fence.drag = { b: best, mode: mode, tx: x, ty: y, ox: 0, oy: 0 };
    if (mode === 'both') { Fence.drag.ox = (best.a.x + best.b.x) / 2 - x; Fence.drag.oy = (best.a.y + best.b.y) / 2 - y; }
    else { var p = mode === 'a' ? best.a : best.b; Fence.drag.ox = p.x - x; Fence.drag.oy = p.y - y; }
    emit('grab', best);
    return true;
  };
  Fence.dragTo = function (x, y) { if (Fence.drag) { Fence.drag.tx = x; Fence.drag.ty = y; } };
  Fence.endDrag = function () { Fence.drag = null; };

  function applyDrag() {
    var d = Fence.drag; if (!d) return;
    var b = d.b, tx = d.tx + d.ox, ty = d.ty + d.oy;
    if (d.mode === 'both') {
      var cx = (b.a.x + b.b.x) / 2, cy = (b.a.y + b.b.y) / 2;
      var dx = tx - cx, dy = ty - cy, l = Math.sqrt(dx * dx + dy * dy);
      var m = Math.min(l, 22); if (l > 0.001) { dx = dx / l * m * 0.6; dy = dy / l * m * 0.6; } else { dx = 0; dy = 0; }
      b.a.x += dx; b.a.y += dy; b.b.x += dx; b.b.y += dy;
    } else {
      var p = d.mode === 'a' ? b.a : b.b;
      var ddx = tx - p.x, ddy = ty - p.y, ll = Math.sqrt(ddx * ddx + ddy * ddy);
      if (ll > 0.001) { var mv = Math.min(ll, 22) * 0.6; p.x += ddx / ll * mv; p.y += ddy / ll * mv; }
    }
  }

  function groundCollide(p) {
    var k = 0;
    if (World.isSolid(p.x, p.y + 7)) {
      while (World.isSolid(p.x, p.y + 7) && k < 70) { p.y -= 1; k++; }
      p.py = p.y;
      p.px = p.x - (p.x - p.px) * 0.55;
    }
    if (p.x < 4) p.x = 4;
    if (p.x > C.W - 4) p.x = C.W - 4;
  }

  function stick(p, q, rest, k) {
    var dx = q.x - p.x, dy = q.y - p.y, l = Math.sqrt(dx * dx + dy * dy) || 0.0001;
    var diff = (l - rest) / l * 0.5 * k;
    p.x += dx * diff; p.y += dy * diff; q.x -= dx * diff; q.y -= dy * diff;
  }

  Fence.update = function (dt) {
    var steps = 2, h = dt / steps, bi, i, b, j;
    for (var s = 0; s < steps; s++) {
      for (bi = 0; bi < Fence.boards.length; bi++) {
        b = Fence.boards[bi];
        [b.a, b.b].forEach(function (p) {
          var vx = (p.x - p.px) * 0.985, vy = (p.y - p.py) * 0.985;
          p.px = p.x; p.py = p.y;
          p.x += vx; p.y += vy + G * h * h;
        });
      }
      for (i = 0; i < 4; i++) {
        applyDrag();
        for (bi = 0; bi < Fence.boards.length; bi++) {
          b = Fence.boards[bi];
          stick(b.a, b.b, b.len, 1);
          if (b.nA) { b.a.x += (b.hx0 - b.a.x) * 0.14; b.a.y += (b.hy0 - b.a.y) * 0.14; }
          if (b.nB) { b.b.x += (b.hx1 - b.b.x) * 0.14; b.b.y += (b.hy1 - b.b.y) * 0.14; }
        }
        for (j = 0; j < Fence.joints.length; j++) {
          var jt = Fence.joints[j];
          if (!jt.broken) stick(jt.p, jt.q, jt.rest, 0.4);
        }
        for (bi = 0; bi < Fence.boards.length; bi++) { groundCollide(Fence.boards[bi].a); groundCollide(Fence.boards[bi].b); }
      }
    }
    // разрушение креплений от растяжения
    for (bi = 0; bi < Fence.boards.length; bi++) {
      b = Fence.boards[bi];
      if (b.flash > 0) b.flash -= dt;
      var lim = NAIL_BREAK + 14 * b.reinf;
      if (b.nA && dist(b.a, { x: b.hx0, y: b.hy0 }) > lim) { b.nA = false; emit('nail', b, b.a); }
      if (b.nB && dist(b.b, { x: b.hx1, y: b.hy1 }) > lim) { b.nB = false; emit('nail', b, b.b); }
    }
    for (j = 0; j < Fence.joints.length; j++) {
      var jj = Fence.joints[j];
      if (!jj.broken && dist(jj.p, jj.q) > jointLimit(jj)) { jj.broken = true; emit('joint', jj); }
    }
  };

  /* ----- столкновения AABB (овцы) с досками ----- */
  Fence.collideBox = function (e, pushPower) {
    var touched = false, k = pushPower === undefined ? 0.3 : pushPower;
    for (var bi = 0; bi < Fence.boards.length; bi++) {
      var b = Fence.boards[bi];
      var minX = Math.min(b.a.x, b.b.x) - HALF, maxX = Math.max(b.a.x, b.b.x) + HALF;
      var minY = Math.min(b.a.y, b.b.y) - HALF, maxY = Math.max(b.a.y, b.b.y) + HALF;
      if (e.x + e.hw < minX || e.x - e.hw > maxX || e.y + e.hh < minY || e.y - e.hh > maxY) continue;
      var free = !(b.nA && b.nB);
      var wBoard = free ? 0.5 : 0.1 * k;
      for (var si = 0; si <= 10; si++) {
        var t = si / 10, px = b.a.x + (b.b.x - b.a.x) * t, py = b.a.y + (b.b.y - b.a.y) * t;
        var rx = e.hw + HALF, ry = e.hh + HALF;
        var dx = px - e.x, dy = py - e.y;
        if (Math.abs(dx) < rx && Math.abs(dy) < ry) {
          var ox = rx - Math.abs(dx), oy = ry - Math.abs(dy);
          touched = true;
          if (ox < oy) {
            var sx = dx > 0 ? -1 : 1;
            e.x += sx * ox * (1 - wBoard);
            b.a.x -= sx * ox * wBoard * 0.5; b.b.x -= sx * ox * wBoard * 0.5;
            if (e.vx * sx < 0) e.vx = 0;
            e.hitX = -sx;
          } else {
            var sy = dy > 0 ? -1 : 1;
            e.y += sy * oy * (1 - wBoard * 0.4);
            if (sy < 0) { e.ground = true; if (e.vy > 0) e.vy = 0; } else if (e.vy < 0) e.vy = 0;
          }
        }
      }
    }
    return touched;
  };

  /* ----- анализ для ИИ ----- */
  Fence.clearHeight = function () {
    var xs = [C.FENCE_L_X + 14, C.FENCE_X, C.FENCE_R_X - 14], best = Infinity;
    xs.forEach(function (x) {
      var gy = World.surfaceY(x), maxBottom = -Infinity;
      Fence.boards.forEach(function (b) {
        var lo = Math.min(b.a.x, b.b.x), hi = Math.max(b.a.x, b.b.x);
        if (x < lo - HALF || x > hi + HALF) return;
        var t = hi - lo < 1 ? 0.5 : clamp((x - b.a.x) / (b.b.x - b.a.x || 1), 0, 1);
        var y = b.a.y + (b.b.y - b.a.y) * t;
        if (y - HALF > gy - 2 + 40) return;
        var bottom = y + HALF;
        if (bottom > maxBottom && y < gy + 6) maxBottom = bottom;
      });
      var free = maxBottom === -Infinity ? 999 : gy - maxBottom;
      if (free < best) best = free;
    });
    return best;
  };

  Fence.topHeight = function () {
    var top = 0, gy = C.GROUND;
    Fence.boards.forEach(function (b) {
      var cx = (b.a.x + b.b.x) / 2;
      if (cx < C.FENCE_L_X - 30 || cx > C.FENCE_R_X + 30) return;
      var h = gy - (Math.min(b.a.y, b.b.y) - HALF);
      if (h > top) top = h;
    });
    return top;
  };

  Fence.integrity = function () {
    var sum = 0;
    Fence.boards.forEach(function (b) {
      if (b.dead) return;
      sum += (b.hp / b.maxHp) * ((b.nA && b.nB) ? 1 : 0.45);
    });
    return Math.round(sum / Fence.boards.length * 100);
  };

  Fence.HALF = HALF;
  window.Fence = Fence;
})();
