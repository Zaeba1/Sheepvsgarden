/* Игрок: движение, прыжок, предметы в руках, удары, лопата (копать/насыпать), отрисовка. */
(function () {
  'use strict';
  var SWING_T = 0.32;
  var Player = {
    x: 380, y: 0, hw: 12, hh: 27, vx: 0, vy: 0, face: 1, ground: false,
    held: null, swing: 0, swingId: 0, hitDone: true, cd: 0, still: 0, anim: 0, stepT: 0,
    dirt: 0, maxDirt: 90, mode: 'dig', shake: 0, landT: 0, wasAir: false, hitX: 0, hurtT: 0
  };

  Player.reset = function () {
    Player.x = 380; Player.y = C.GROUND - Player.hh - 2; Player.vx = Player.vy = 0; Player.face = 1;
    Player.swing = 0; Player.cd = 0; Player.still = 0; Player.dirt = 0; Player.mode = 'dig'; Player.hitDone = true;
    Player.held = Items.setup();
    Player.held.state = 'held';
  };

  Player.heldKind = function () { return Player.held ? Player.held.kind : null; };

  /* ----- предметы ----- */
  Player.equip = function (kind) {
    if (Player.held && Player.held.kind === kind) {
      if (kind === 'shovel') {
        Player.mode = Player.mode === 'dig' ? 'pile' : 'dig';
        Game.toast(Player.mode === 'dig' ? 'Лопата: КОПАТЬ' : 'Лопата: НАСЫПАТЬ (земли: ' + Player.dirt + ')');
        Sfx.play('click');
      }
      return;
    }
    var bag = Items.ofKind(kind, ['bag']);
    if (!bag.length) {
      var gone = Items.ofKind(kind, ['gone']), sheep = Items.ofKind(kind, ['sheep']), gr = Items.ofKind(kind, ['ground']);
      if (sheep.length) Game.toast('Предмет украла овца!');
      else if (gr.length) Game.toast('Предмет лежит на земле — подбери его');
      else if (gone.length) Game.toast('Сломан. Новый появится через ' + Math.ceil(gone[0].timer) + ' с');
      return;
    }
    if (Player.held) Player.held.state = 'bag';
    var best = bag.sort(function (a, b) { return b.dur - a.dur; })[0];
    best.state = 'held'; Player.held = best; Player.swing = 0;
    Sfx.play('click');
  };

  Player.pickup = function (it) {
    if (it.state !== 'ground' || it.noPick > 0) return;
    it.state = 'bag'; it.vx = it.vy = 0;
    if (!Player.held) { it.state = 'held'; Player.held = it; }
    Game.toast('Подобран: ' + Items.DEF[it.kind].name);
    Sfx.play('click');
  };

  Player.drop = function () {
    var it = Player.held;
    if (!it) { Game.toast('В руках пусто'); return; }
    Player.held = null; Player.still = 0;
    var vx = Player.face * (it.kind === 'stone' ? 270 : 150) + Player.vx * 0.5;
    Items.throwItem(it, Player.x + Player.face * 16, Player.y - 12, vx, it.kind === 'stone' ? -230 : -160);
    Sfx.play('swing');
  };

  /* ----- действие ----- */
  Player.tryAction = function () {
    if (Player.cd > 0 || Game.state !== 'play') return;
    if (!Player.held) { Game.toast('В руках пусто — тапни по инструменту'); return; }
    var d = Items.DEF[Player.held.kind];
    Player.swing = SWING_T; Player.hitDone = false; Player.cd = d.cd; Player.swingId++; Player.still = 0;
    Sfx.play('swing');
  };

  function hitbox() {
    var d = Items.DEF[Player.held.kind];
    var x0 = Player.face > 0 ? Player.x + 2 : Player.x - 2 - d.reach;
    return { x0: x0, x1: x0 + d.reach, y0: Player.y - Player.hh - 6, y1: Player.y + Player.hh + 4, reach: d.reach };
  }

  function applyHit() {
    var it = Player.held; if (!it) return;
    var kind = it.kind, d = Items.DEF[kind], hb = hitbox(), hitSheep = false, i;
    for (i = 0; i < Game.sheep.length; i++) {
      var s = Game.sheep[i];
      if (s.dead || s.lastSwing === Player.swingId) continue;
      // овцу, роющую туннель под ногами, можно ударить сверху (кротовая охота)
      var below = s.kin ? 46 : 0;
      if (s.x + s.hw > hb.x0 && s.x - s.hw < hb.x1 && s.y + s.hh > hb.y0 && s.y - s.hh < hb.y1 + below) {
        s.lastSwing = Player.swingId;
        var dmg = Items.dmg(kind) * (kind === 'stone' ? 0.8 : 1);
        s.hurt(dmg, Player.face, d.kb, 'player');
        hitSheep = true;
      }
    }
    if (hitSheep) { Items.wear(it, 1); Game.shake(kind === 'sledge' ? 7 : 3); return; }

    var hx = (hb.x0 + hb.x1) / 2, hy = Player.y + 4;
    if (kind === 'hammer') {
      var b = Fence.nearest(hx, hy, 40) || Fence.nearest(hx, hy - 30, 46);
      if (!b) {
        // свободная доска поблизости
        for (var k = 0; k < Fence.boards.length; k++) {
          var bb = Fence.boards[k], mx = (bb.a.x + bb.b.x) / 2, my = (bb.a.y + bb.b.y) / 2;
          if (!(bb.nA && bb.nB) && Math.abs(mx - hx) < 70 && Math.abs(my - hy) < 60) { b = bb; break; }
        }
      }
      if (b) {
        var res = Fence.repair(b);
        var mx2 = (b.a.x + b.b.x) / 2, my2 = (b.a.y + b.b.y) / 2;
        if (res === 'revive_far' || res === 'far') {
          Game.toast('Перетащи доску ближе к её месту в заборе и ударь снова');
          Sfx.play('thud');
        } else if (res === 'max') {
          Game.toast('Доска уже укреплена по максимуму');
        } else {
          Items.wear(it, res === 'reinforce' ? 2 : 1);
          Sfx.play('repair'); Game.burst('wood', mx2, my2, 6);
          if (res === 'reinforce') { Game.toast('Доска укреплена (ур. ' + b.reinf + ')'); AI.onReinforce(b); }
          else if (res === 'revive' || res === 'replant') Game.toast('Доска на месте');
        }
        Game.shake(2);
      }
    } else if (kind === 'sledge') {
      var b2 = Fence.nearest(hx, hy, 42) || Fence.nearest(hx, hy - 30, 48);
      if (b2) {
        Fence.damage(b2, Items.dmg('sledge') * 0.9, Player.face);
        Items.wear(it, 1); Sfx.play('hit'); Game.shake(6);
        Game.burst('wood', (b2.a.x + b2.b.x) / 2, (b2.a.y + b2.b.y) / 2, 8);
      }
    } else if (kind === 'shovel') {
      var tx = Player.x + Player.face * 34, gy = World.surfaceY(tx);
      var R = 14 + 3 * Items.level('shovel');
      if (Player.mode === 'dig') {
        if (Player.dirt >= Player.maxDirt) { Game.toast('Мешок полон — переключи лопату на НАСЫПАТЬ'); return; }
        var n = World.carveCircle(tx, gy + 5, R);
        if (n) {
          Player.dirt = Math.min(Player.maxDirt, Player.dirt + n);
          Items.wear(it, 0.5); Sfx.play('dig'); Game.burst('dirt', tx, gy, 8); Game.shake(1.5);
        }
      } else {
        if (Player.dirt <= 0) { Game.toast('Нет земли — сначала накопай'); return; }
        var m = World.fillCircle(tx, gy - 6, R, Player.dirt);
        if (m) {
          Player.dirt -= m; Items.wear(it, 0.5); Sfx.play('dig'); Game.burst('dirt', tx, gy - 6, 8);
        }
      }
    } else if (kind === 'stone') {
      Sfx.play('thud');
    }
  }

  Player.update = function (dt, input) {
    var ax = input.ax, sp = 190;
    if (Player.hurtT > 0) Player.hurtT -= dt;
    var tvx = ax * sp;
    Player.vx += (tvx - Player.vx) * Math.min(1, dt * (Player.ground ? 14 : 5));
    if (Math.abs(ax) > 0.2) Player.face = ax > 0 ? 1 : -1;
    if (input.jump && Player.ground) {
      Player.vy = -640; Player.ground = false; Sfx.play('jump'); Player.still = 0;
    }
    input.jump = false;
    Player.vy = Math.min(900, Player.vy + 1800 * dt);
    World.move(Player, Player.vx * dt, Player.vy * dt);
    if (Player.x < Player.hw) Player.x = Player.hw;
    if (Player.x > C.W - Player.hw) Player.x = C.W - Player.hw;
    if (Player.wasAir && Player.ground) { Player.landT = 0.18; Sfx.play('land'); Game.burst('dust', Player.x, Player.y + Player.hh, 4); }
    Player.wasAir = !Player.ground;
    if (Player.landT > 0) Player.landT -= dt;

    if (Player.ground && Math.abs(Player.vx) > 10) {
      Player.anim += Math.abs(Player.vx) * dt * 0.06;
      Player.stepT += Math.abs(Player.vx) * dt;
      if (Player.stepT > 46) { Player.stepT = 0; Sfx.play('step'); }
    } else if (Player.ground) { Player.anim *= 0.9; }

    if (Player.ground && Math.abs(Player.vx) < 8 && Player.swing <= 0) Player.still += dt;
    else Player.still = 0;

    if (Player.cd > 0) Player.cd -= dt;
    if (Player.swing > 0) {
      Player.swing -= dt;
      if (!Player.hitDone && Player.swing <= SWING_T * 0.5) { Player.hitDone = true; applyHit(); }
    } else if (input.actionHeld && Player.cd <= 0) {
      Player.tryAction();
    }

    // автоподбор брошенных/потерянных предметов
    for (var i = 0; i < Items.list.length; i++) {
      var it = Items.list[i];
      if (it.state === 'ground' && it.noPick <= 0 && Math.abs(it.x - Player.x) < 30 && Math.abs(it.y - Player.y) < 40 && Math.hypot(it.vx, it.vy) < 140) {
        Player.pickup(it);
      }
    }
  };

  /* ----- отрисовка ----- */
  function ease(t) { return t * t * (3 - 2 * t); }

  Player.draw = function (g, t) {
    var P = Assets.player(), x = Player.x, y = Player.y, moving = Player.ground && Math.abs(Player.vx) > 12;
    var ph = Player.anim, bob = moving ? Math.abs(Math.sin(ph)) * -2 : Math.sin(t * 2) * 0.5;
    if (Player.landT > 0) bob += 2.5;
    g.save();
    g.fillStyle = 'rgba(0,0,0,.28)';
    var gy = Player.ground ? y + Player.hh : Math.max(y + Player.hh, World.surfaceY(x));
    g.beginPath(); g.ellipse(x, gy, 17, 4.5, 0, 0, 7); g.fill();
    g.translate(x, y); g.scale(Player.face, 1);
    // задние нога и рука
    var la = moving ? Math.sin(ph) * 0.65 : 0, air = !Player.ground;
    if (air) la = Player.vy < 0 ? 0.5 : -0.3;
    function leg(a) { g.save(); g.translate(-1, 11 + bob * 0.3); g.rotate(a); g.drawImage(P.leg.c, -6, 0, 12, 22); g.restore(); }
    g.globalAlpha = 0.85; leg(-la); g.globalAlpha = 1;
    var armBack = moving ? -Math.sin(ph) * 0.7 : 0.1;
    g.save(); g.translate(-3, -6 + bob); g.rotate(armBack); g.globalAlpha = 0.85; g.drawImage(P.arm.c, -5, 0, 10, 24); g.restore();
    g.globalAlpha = 1;
    g.drawImage(P.torso.c, -13, -9 + bob, 26, 24);
    leg(la);
    g.drawImage(P.head.c, -15, -31 + bob + (moving ? Math.sin(ph * 2) * 0.6 : 0), 30, 32);
    // рука с предметом
    var arm = moving ? Math.sin(ph) * 0.5 + 0.3 : 0.35, rot = 0.25;
    if (Player.swing > 0) {
      var k = 1 - Player.swing / SWING_T;
      arm = -2.4 + (ease(Math.min(1, k * 1.15))) * 3.7; rot = arm * 0.95 + 0.15;
    }
    var sx = 3, syy = -6 + bob, hx = sx + Math.sin(arm) * 19, hy = syy + Math.cos(arm) * 19;
    if (Player.held) {
      Items.drawSprite(g, Player.held.kind, hx + 2, hy, rot, 0.82);
    }
    g.save(); g.translate(sx, syy); g.rotate(arm); g.drawImage(P.arm.c, -5, 0, 10, 24); g.restore();
    g.restore();
    // зона удара (подсказка)
    if (Player.swing > 0 && Player.held) {
      var hb = hitbox();
      g.save(); g.globalAlpha = 0.18 * (Player.swing / SWING_T); g.fillStyle = '#fff';
      g.beginPath(); g.ellipse((hb.x0 + hb.x1) / 2, Player.y + 4, hb.reach / 2, 22, 0, 0, 7); g.fill(); g.restore();
    }
  };

  window.Player = Player;
})();
