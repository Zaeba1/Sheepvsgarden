/* Синтезированные звуки через Web Audio API (файлов не требуется). */
(function () {
  'use strict';
  var ctx = null, master = null, enabled = true, last = {}, noiseBuf = null;

  function ensure() {
    if (!ctx) {
      try {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return false;
        ctx = new AC();
        master = ctx.createGain();
        master.gain.value = 0.45;
        master.connect(ctx.destination);
        noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
        var d = noiseBuf.getChannelData(0);
        for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      } catch (e) { ctx = null; return false; }
    }
    if (ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
    return true;
  }

  function tone(f0, f1, dur, type, vol, delay) {
    var t = ctx.currentTime + (delay || 0);
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.3, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + dur + 0.05);
  }

  function noise(dur, vol, freq, q, delay, type) {
    var t = ctx.currentTime + (delay || 0);
    var s = ctx.createBufferSource(); s.buffer = noiseBuf;
    var f = ctx.createBiquadFilter(); f.type = type || 'bandpass';
    f.frequency.value = freq || 1000; f.Q.value = q || 1;
    var g = ctx.createGain();
    g.gain.setValueAtTime(vol || 0.3, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t, Math.random() * 0.2); s.stop(t + dur + 0.02);
  }

  var GAP = { step: 120, jump: 80, break: 60, dig: 110, hit: 60, steal: 100, coin: 60, buy: 100, lose: 500, bleat: 400, swing: 70, thud: 80, click: 40 };

  var Sfx = {
    unlock: ensure,
    setEnabled: function (b) { enabled = !!b; },
    isEnabled: function () { return enabled; },
    play: function (name) {
      if (!enabled) return;
      var now = performance.now();
      if (last[name] && now - last[name] < (GAP[name] || 50)) return;
      last[name] = now;
      if (!ensure()) return;
      try {
        switch (name) {
          case 'step': noise(0.05, 0.08, 400 + Math.random() * 200, 0.8, 0, 'lowpass'); break;
          case 'jump': tone(280, 620, 0.16, 'square', 0.12); break;
          case 'land': noise(0.08, 0.14, 300, 0.7, 0, 'lowpass'); break;
          case 'break': noise(0.35, 0.5, 900, 0.5); tone(140, 50, 0.25, 'sawtooth', 0.22); noise(0.2, 0.3, 2400, 1, 0.05); break;
          case 'dig': noise(0.14, 0.28, 700 + Math.random() * 400, 0.9); break;
          case 'hit': tone(220, 70, 0.16, 'square', 0.25); noise(0.1, 0.3, 1500, 1); break;
          case 'thud': tone(110, 55, 0.12, 'sine', 0.3); break;
          case 'swing': noise(0.1, 0.12, 2200, 0.6, 0, 'highpass'); break;
          case 'steal': tone(500, 520, 0.08, 'triangle', 0.22); tone(760, 1100, 0.14, 'triangle', 0.22, 0.09); break;
          case 'coin': tone(988, 988, 0.08, 'square', 0.14); tone(1319, 1319, 0.18, 'square', 0.14, 0.07); break;
          case 'buy': tone(523, 523, 0.09, 'triangle', 0.22); tone(659, 659, 0.09, 'triangle', 0.22, 0.09); tone(784, 784, 0.2, 'triangle', 0.22, 0.18); break;
          case 'lose': tone(440, 440, 0.25, 'sawtooth', 0.2); tone(370, 370, 0.25, 'sawtooth', 0.2, 0.25); tone(311, 311, 0.25, 'sawtooth', 0.2, 0.5); tone(220, 130, 0.7, 'sawtooth', 0.22, 0.75); break;
          case 'bleat': var f = 380 + Math.random() * 120; tone(f, f * 0.78, 0.38, 'sawtooth', 0.09); tone(f * 1.5, f * 1.1, 0.3, 'square', 0.03); break;
          case 'click': tone(700, 700, 0.04, 'square', 0.1); break;
          case 'repair': tone(330, 330, 0.06, 'square', 0.15); tone(495, 495, 0.1, 'square', 0.15, 0.07); break;
        }
      } catch (e) { /* звук не критичен */ }
    }
  };
  window.Sfx = Sfx;
})();
