/* Игровой цикл, состояние раунда, частицы, отрисовка сцены. */
(function () {
  'use strict';
  var canvas, ctx, dpr = 1, view = { sc: 1, ox: 0, oy: 0, w: 960, h: 540 };
  var parts = [], floats = [], acc = 0, last = 0, errCount = 0, hudT = 0, shakeV = 0, animT = 0, overT = 0, hinted = false;

  var Game = {
    state: 'menu', sheep: [], time: 0, over: false, spawnQ: [], nextId: 1,
    stats: { kills: 0, coins: 0, steals: 0, tunnels: 0, boards: 0, jumps: 0, time: 0 },

    init: function () {
      canvas = document.getElementById('game'); ctx = canvas.getContext('2d');
      window.addEventListener('resize', resize); window.addEventListener('orientationchange', function () { setTimeout(resize, 200); });
      resize();
      World.init(); Fence.reset(Save.data.skins.fence); AI.reset(); Player.reset();
      Fence.events = {
        'break': function (b) { Sfx.play('break'); Game.burst('wood', (b.a.x + b.b.x) / 2, (b.a.y + b.b.y) / 2, 14); Game.shake(5); },
        nail: function (b, p) { Sfx.play('thud'); Game.burst('wood', p.x, p.y, 3); },
        joint: function () { Sfx.play('thud'); },
        grab: function () { Sfx.play('click'); },
        replant: function (b) { Sfx.play('repair'); Game.burst('wood', (b.a.x + b.b.x) / 2, (b.a.y + b.b.y) / 2, 5); }
      };
      Items.onBreak = function (it, x, y) {
        Game.toast(Items.DEF[it.kind].name + ' сломан! Новый появится через ' + Items.DEF[it.kind].respawn + ' с');
        Sfx.play('break'); Game.burst('wood', x, y, 10);
      };
      Items.onRespawn = function (it) { Game.toast('В сумке снова: ' + Items.DEF[it.kind].name); };
      requestAnimationFrame(function (t) { last = t; frame(t); });
    },

    start: function () {
      Save.data.games++; Save.save();
      World.init(); Fence.reset(Save.data.skins.fence); AI.reset(); Player.reset();
      parts = []; floats = [];
      Game.sheep = []; Game.time = 0; Game.over = false; Game.nextId = 1; overT = 0;
      Game.spawnQ = [3, 14, 26, 40, 56];
      Game.stats = { kills: 0, coins: 0, steals: 0, tunnels: 0, boards: 0, jumps: 0, time: 0 };
      UI.hideAll(); UI.buildToolbar(); UI.refreshToolbar(true);
      Game.state = 'play';
      Game.toast(hinted ? 'Защити капусту!' : 'Тяни доски пальцем, бей овец молотком, не стой с инструментом без дела!', 3500);
      hinted = true;
    },
    pause: function () { if (Game.state !== 'play') return; Game.state = 'pause'; UI.show('menuPause'); UI.Input.actionHeld = false; },
    resume: function () { if (Game.state !== 'pause') return; UI.hide('menuPause'); Game.state = 'play'; last = performance.now(); },
    toast: function (m, ms) { UI.toast(m, ms); },
    shake: function (v) { shakeV = Math.max(shakeV, v); },
    toWorld: function (cx, cy) { return { x: (cx - view.ox) / view.sc, y: (cy - view.oy) / view.sc }; },

    difficulty: function () { return Math.min(1, Game.time / 420); },

    spawnSheep: function (respawn) {
      if (Game.sheep.length >= 5) return;
      var s = new Sheep(Game.nextId++, Sheep.rollStats(Game.difficulty(), AI.group.xp, respawn), 20 + Math.random() * 30);
      Game.sheep.push(s);
      Game.burst('poof', s.x, s.y, 8);
    },

    killSheep: function (s) {
      if (s.dead) return;
      s.dead = true; s.kin = false;
      var i = Game.sheep.indexOf(s); if (i >= 0) Game.sheep.splice(i, 1);
      var coins = 8 + Math.round(s.cunning * 10) + Math.round(Game.difficulty() * 4);
      Save.addCoins(coins);
      Game.stats.kills++; Game.stats.coins += coins;
      floats.push({ x: s.x, y: s.y - 30, text: '+' + coins, t: 1.4 });
      Game.burst('poof', s.x, s.y, 12); Game.burst('coin', s.x, s.y - 10, 7);
      Sfx.play('coin'); Game.shake(3);
      Game.spawnQ.push(6);
      if (s.ai) s.ai.dig = null;
    },

    gameOver: function () {
      if (Game.over) return;
      Game.over = true; Game.state = 'ending'; overT = 1.3;
      Game.stats.time = Game.time;
      if (Game.time > Save.data.bestTime) Save.data.bestTime = Math.floor(Game.time);
      if (Game.stats.kills > Save.data.bestKills) Save.data.bestKills = Game.stats.kills;
      Save.save(); Sfx.play('lose');
    },

    /* указатель */
    pointerDown: function (x, y) {
      var i, it;
      for (i = 0; i < Items.list.length; i++) {
        it = Items.list[i];
        if (it.state === 'ground' && Math.abs(it.x - x) < 34 && Math.abs(it.y - y) < 34) {
          if (Math.abs(it.x - Player.x) < 170 && Math.abs(it.y - Player.y) < 90) { it.noPick = 0; Player.pickup(it); }
          else Game.toast('Предмет далеко — подойди ближе');
          return false;
        }
      }
      if (Fence.beginDrag(x, y)) {
        var b = Fence.drag.b, mx = (b.a.x + b.b.x) / 2;
        if (Math.abs(mx - Player.x) > 360) { Fence.endDrag(); Game.toast('Слишком далеко — подойди ближе'); return false; }
        return true;
      }
      return false;
    },
    pointerMove: function (x, y) {
      if (!Fence.drag) return;
      Fence.dragTo(x, y);
      if (Math.abs(x - Player.x) > 480) Fence.endDrag();
    },
    pointerUp: function () { Fence.endDrag(); },

    burst: function (kind, x, y, n) {
      var fx = Save.data.skins.fx;
      for (var i = 0; i < n && parts.length < 420; i++) {
        var a = Math.random() * Math.PI * 2, sp = 30 + Math.random() * 110, p = { x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60, t: 0, life: 0.6, size: 3, g: 500, kind: kind, rot: Math.random() * 6, col: '#fff' };
        switch (kind) {
          case 'dust': p.col = 'rgba(225,205,165,.8)'; p.size = 3 + Math.random() * 4; p.g = -30; p.life = 0.5; p.vy *= 0.4; break;
          case 'dirt': p.col = ['#7a4a22', '#5a3416', '#946034'][i % 3]; p.size = 2 + Math.random() * 3; p.life = 0.7; break;
          case 'wood': p.col = ['#c98f4f', '#8a5424', '#e8b878'][i % 3]; p.size = 2 + Math.random() * 3; p.life = 0.8; break;
          case 'star': p.col = '#ffe14a'; p.size = 4 + Math.random() * 3; p.g = 200; p.life = 0.6; break;
          case 'coin': p.col = '#ffc61e'; p.size = 4; p.vy = -150 - Math.random() * 120; p.vx *= 0.5; p.life = 0.9; break;
          case 'poof': p.col = 'rgba(255,255,255,.85)'; p.size = 5 + Math.random() * 6; p.g = -20; p.life = 0.55; p.vx *= 0.7; break;
        }
        parts.push(p);
        if (i % 2 === 0 && (kind === 'dust' || kind === 'wood' || kind === 'dirt')) {
          if (fx === 'sparkle') parts.push({ x: x, y: y, vx: p.vx, vy: p.vy - 40, t: 0, life: 0.7, size: 4, g: 120, kind: 'star', rot: 0, col: '#ffe98a' });
          if (fx === 'leaves') parts.push({ x: x, y: y, vx: p.vx * 0.6, vy: p.vy - 20, t: 0, life: 1.0, size: 4, g: 60, kind: 'wood', rot: p.rot, col: i % 4 === 0 ? '#5cb82e' : '#8fd65a' });
        }
      }
    },

    update: update
  };

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    var w = window.innerWidth, h = window.innerHeight;
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    view.w = w; view.h = h; view.sc = Math.min(w / C.W, h / C.H);
    view.ox = (w - C.W * view.sc) / 2; view.oy = (h - C.H * view.sc) / 2;
  }

  /* ---------- обновление ---------- */
  function update(dt) {
    animT += dt;
    if (Game.state === 'ending') {
      overT -= dt;
      Game.sheep.forEach(function (s) { s.update(dt, Game); });
      updateParts(dt);
      if (overT <= 0) { Game.state = 'over'; UI.showOver(Game.stats); }
      return;
    }
    if (Game.state !== 'play') return;
    Game.time += dt;
    AI.setDifficulty(Game.difficulty());
    Player.update(dt, UI.Input);
    Fence.update(dt);
    Items.update(dt, Game);

    for (var q = Game.spawnQ.length - 1; q >= 0; q--) {
      Game.spawnQ[q] -= dt;
      if (Game.spawnQ[q] <= 0) { Game.spawnQ.splice(q, 1); Game.spawnSheep(Game.time > 15); }
    }
    var list = Game.sheep.slice(), i, j;
    for (i = 0; i < list.length; i++) if (!list[i].dead) list[i].update(dt, Game);

    // мягкое расталкивание овец и игрока
    for (i = 0; i < Game.sheep.length; i++) {
      var a = Game.sheep[i];
      for (j = i + 1; j < Game.sheep.length; j++) {
        var b = Game.sheep[j];
        if (a.kin || b.kin || a.ai.state === 'break' && b.ai.state === 'break') continue;
        var dx = b.x - a.x, ov = a.hw * 1.7 - Math.abs(dx);
        if (ov > 0 && Math.abs(b.y - a.y) < a.hh) { var d = (dx >= 0 ? 1 : -1) * Math.min(ov, 40 * dt + 0.2); a.x -= d * 0.5; b.x += d * 0.5; }
      }
      if (!a.kin && Math.abs(a.x - Player.x) < a.hw + Player.hw - 2 && Math.abs(a.y - Player.y) < a.hh + Player.hh - 4) {
        var pd = a.x >= Player.x ? 1 : -1; a.x += pd * 40 * dt; Player.x -= pd * 55 * dt;
      }
      if (!a.kin && !Game.over && a.x > C.GARDEN_X && a.y + a.hh <= C.GROUND + 6) { Game.gameOver(); break; }
    }
    World.flush();
    updateParts(dt);
    for (i = floats.length - 1; i >= 0; i--) { floats[i].t -= dt; floats[i].y -= 28 * dt; if (floats[i].t <= 0) floats.splice(i, 1); }
    hudT -= dt;
    if (hudT <= 0) { hudT = 0.2; UI.refreshHud(Game); UI.refreshToolbar(false); }
  }

  function updateParts(dt) {
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i];
      p.t += dt; if (p.t >= p.life) { parts.splice(i, 1); continue; }
      p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += dt * 8;
      if (p.kind !== 'poof' && p.kind !== 'dust' && p.vy > 0 && World.isSolid(p.x, p.y)) { p.vy *= -0.3; p.vx *= 0.6; p.y -= 2; }
    }
    shakeV *= Math.pow(0.002, dt);
  }

  /* ---------- отрисовка ---------- */
  function drawBoard(g, b, skin) {
    var spr = Assets.board(skin, b.variant), dx = b.b.x - b.a.x, dy = b.b.y - b.a.y, len = Math.hypot(dx, dy), ang = Math.atan2(dy, dx);
    g.save();
    g.translate((b.a.x + b.b.x) / 2, (b.a.y + b.b.y) / 2); g.rotate(ang);
    var w = len + 4, h = 19;
    g.drawImage(spr.c, -w / 2, -h / 2, w, h);
    // укрепление: металлические полосы и болты
    if (b.reinf > 0) {
      g.fillStyle = b.reinf >= 3 ? '#e0b64a' : '#8f98a8';
      [-w / 2 + 12, w / 2 - 22].forEach(function (x) { g.fillRect(x, -h / 2 + 0.5, 9, h - 1); });
      g.fillStyle = '#2b2d33';
      for (var k = 0; k < b.reinf; k++) { g.beginPath(); g.arc(-w / 2 + 16.5, -4 + k * 4, 1.3, 0, 7); g.arc(w / 2 - 17.5, -4 + k * 4, 1.3, 0, 7); g.fill(); }
    }
    // трещины
    var f = b.hp / b.maxHp;
    if (f < 0.66 || b.dead) {
      g.strokeStyle = 'rgba(30,15,5,.75)'; g.lineWidth = 1.2; g.beginPath();
      g.moveTo(-10, -h / 2); g.lineTo(-6, -2); g.lineTo(-11, 3); g.lineTo(-7, h / 2);
      if (f < 0.33 || b.dead) { g.moveTo(14, -h / 2); g.lineTo(10, 0); g.lineTo(16, 4); g.lineTo(12, h / 2); }
      g.stroke();
    }
    if (!(b.nA && b.nB) && !b.dead) { g.fillStyle = 'rgba(255,60,40,.35)'; g.fillRect(-w / 2, -h / 2, w, h); }
    if (b.dead) { g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(-w / 2, -h / 2, w, h); }
    if (b.flash > 0) { g.globalAlpha = Math.min(0.7, b.flash * 4); g.fillStyle = '#fff'; g.fillRect(-w / 2, -h / 2, w, h); }
    g.restore();
  }

  function drawBubble(g, s) {
    var bb = s.bubble; if (!bb) return;
    var x = s.x, y = s.y - s.hh - 40 - (1 - Math.min(1, bb.t * 3)) * 0, w = Math.max(26, bb.text.length * 8 + 14);
    g.save(); g.globalAlpha = Math.min(1, bb.t * 3);
    g.fillStyle = '#fff'; g.strokeStyle = '#3a2a1a'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(x - w / 2 + 8, y - 10); g.arcTo(x - w / 2, y - 10, x - w / 2, y + 6, 8); g.arcTo(x - w / 2, y + 12, x + w / 2, y + 12, 8);
    g.lineTo(x - 4, y + 12); g.lineTo(x - 6, y + 20); g.lineTo(x + 4, y + 12);
    g.arcTo(x + w / 2, y + 12, x + w / 2, y - 10, 8); g.arcTo(x + w / 2, y - 10, x - w / 2, y - 10, 8); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#3a2a1a'; g.font = 'bold 13px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(bb.text, x, y + 1);
    g.restore();
  }

  function drawParts(g) {
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i], k = 1 - p.t / p.life;
      g.save(); g.globalAlpha = Math.max(0, Math.min(1, k * 1.6)); g.fillStyle = p.col; g.translate(p.x, p.y);
      if (p.kind === 'star') {
        g.rotate(p.rot); g.beginPath();
        for (var s = 0; s < 8; s++) { var r = s % 2 ? p.size * 0.45 : p.size; g.lineTo(Math.cos(s * Math.PI / 4) * r, Math.sin(s * Math.PI / 4) * r); }
        g.closePath(); g.fill();
      } else if (p.kind === 'wood' || p.kind === 'dirt') { g.rotate(p.rot); g.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2 + 1); }
      else if (p.kind === 'coin') { g.beginPath(); g.ellipse(0, 0, Math.abs(Math.cos(p.rot * 1.5)) * p.size + 0.8, p.size, 0, 0, 7); g.fill(); g.strokeStyle = '#a06a00'; g.lineWidth = 1; g.stroke(); }
      else { g.beginPath(); g.arc(0, 0, p.size * (kind2(p) ), 0, 7); g.fill(); }
      g.restore();
    }
    function kind2(p) { return p.kind === 'poof' || p.kind === 'dust' ? 0.6 + (p.t / p.life) * 0.8 : 1; }
  }

  function render() {
    var g = ctx, w = view.w, h = view.h, sc = view.sc, i;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    var gy = view.oy + 330 * sc;
    var sky = g.createLinearGradient(0, 0, 0, gy); sky.addColorStop(0, '#7cc8f5'); sky.addColorStop(1, '#bfe8ff');
    g.fillStyle = sky; g.fillRect(0, 0, w, gy);
    g.fillStyle = '#4a2c14'; g.fillRect(0, gy, w, h - gy);
    g.fillStyle = '#6db243'; g.fillRect(0, gy - 30 * sc, 0, 0);

    var shx = shakeV > 0.2 ? (Math.random() - 0.5) * shakeV : 0, shy = shakeV > 0.2 ? (Math.random() - 0.5) * shakeV : 0;
    g.setTransform(dpr * sc, 0, 0, dpr * sc, dpr * (view.ox + shx), dpr * (view.oy + shy));
    g.beginPath(); g.rect(0, 0, C.W, C.H); g.clip();
    var bd = Assets.backdrop(); g.drawImage(bd.c, 0, 0, bd.w, bd.h);
    // земля
    g.drawImage(World.canvas, 0, C.Y0, C.W, C.H - C.Y0);
    // огород
    var gp = Assets.garden(); g.drawImage(gp.c, 640, C.GROUND - 17, gp.w, gp.h);
    for (i = 0; i < 6; i++) {
      var cb = Assets.cabbage(i % 4), cx = 690 + i * 45, sw = Math.sin(animT * 1.5 + i) * 0.015;
      g.save(); g.translate(cx, C.GROUND - 2); g.rotate(sw); g.drawImage(cb.c, -27, -46, 54, 50); g.restore();
    }
    var skin = Save.data.skins.fence, sheepSkin = Save.data.skins.sheep;
    var post = Assets.post(skin);
    g.drawImage(post.c, C.FENCE_X - 55, C.GROUND - 144, 22, 150);
    g.drawImage(post.c, C.FENCE_X + 33, C.GROUND - 144, 22, 150);
    Items.drawGround(g, animT);
    // овцы позади забора
    for (i = 0; i < Game.sheep.length; i++) if (Game.sheep[i].x > C.FENCE_X) Game.sheep[i].draw(g, animT, sheepSkin);
    for (i = 0; i < Fence.boards.length; i++) drawBoard(g, Fence.boards[i], skin);
    if (Fence.drag) {
      var db = Fence.drag.b; g.save(); g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 2; g.setLineDash([5, 4]);
      g.beginPath(); g.moveTo(db.a.x, db.a.y); g.lineTo(db.b.x, db.b.y); g.stroke();
      g.setLineDash([]); g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.arc(Fence.drag.tx, Fence.drag.ty, 9, 0, 7); g.fill(); g.restore();
    }
    for (i = 0; i < Game.sheep.length; i++) if (Game.sheep[i].x <= C.FENCE_X) Game.sheep[i].draw(g, animT, sheepSkin);
    Player.draw(g, animT);
    drawParts(g);
    for (i = 0; i < Game.sheep.length; i++) drawBubble(g, Game.sheep[i]);
    // индикатор внимания овцы (кража)
    var maxw = 0, shown = null;
    Game.sheep.forEach(function (s) {
      var st = s.ai.state;
      if (st === 'steal_watch' && s.ai.need) { var v = Math.min(1, s.ai.watch / s.ai.need); if (v > maxw) { maxw = v; shown = s; } }
      if ((st === 'steal_sneak' || st === 'steal_grab') && 1 > maxw) { maxw = 1; shown = s; }
    });
    if (shown && Player.held) {
      var bx = Player.x - 22, by = Player.y - 50;
      g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(bx - 1, by - 1, 44, 8);
      g.fillStyle = maxw > 0.75 ? '#ff4a3a' : '#ffc83a'; g.fillRect(bx, by, 42 * maxw, 6);
      g.fillStyle = '#fff'; g.font = 'bold 11px system-ui,sans-serif'; g.textAlign = 'center'; g.fillText('овца следит! двигайся', Player.x, by - 4);
    }
    g.font = 'bold 16px system-ui, sans-serif'; g.textAlign = 'center';
    for (i = 0; i < floats.length; i++) {
      var f = floats[i]; g.globalAlpha = Math.min(1, f.t * 2);
      g.lineWidth = 3; g.strokeStyle = '#6a4300'; g.strokeText(f.text, f.x, f.y); g.fillStyle = '#ffd43a'; g.fillText(f.text, f.x, f.y);
    }
    g.globalAlpha = 1;
    // джойстик
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    var st = UI.Input.stick;
    if (Game.state === 'play') {
      var cx0 = st.id >= 0 ? st.ox : Math.min(90, w * 0.14), cy0 = st.id >= 0 ? st.oy : h - Math.min(100, h * 0.28);
      var kx = cx0, ky = cy0;
      if (st.id >= 0) { var ddx = st.x - st.ox, ddy = st.y - st.oy, dl = Math.hypot(ddx, ddy) || 1, m = Math.min(dl, 46); kx = cx0 + ddx / dl * m; ky = cy0 + ddy / dl * m; }
      g.globalAlpha = st.id >= 0 ? 0.55 : 0.22; g.fillStyle = '#fff'; g.beginPath(); g.arc(cx0, cy0, 46, 0, 7); g.fill();
      g.globalAlpha = st.id >= 0 ? 0.85 : 0.35; g.fillStyle = '#ffe9a8'; g.beginPath(); g.arc(kx, ky, 22, 0, 7); g.fill();
      g.globalAlpha = 1;
    }
  }

  function frame(ts) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.1, (ts - last) / 1000); last = ts; acc += dt;
    try {
      var n = 0;
      while (acc >= 1 / 60 && n < 4) { update(1 / 60); acc -= 1 / 60; n++; }
      if (n === 4) acc = 0;
      render(); errCount = 0;
    } catch (e) {
      console.error('Ошибка в игровом цикле', e);
      if (++errCount > 20 && Game.state === 'play') { Game.state = 'pause'; UI.show('menuPause'); UI.toast('Произошла ошибка — игра на паузе', 4000); errCount = 0; }
    }
  }

  window.Game = Game;
})();
