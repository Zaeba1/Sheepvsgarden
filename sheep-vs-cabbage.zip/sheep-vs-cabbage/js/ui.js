/* Интерфейс: HUD, панель инструментов, меню, ввод (джойстик, кнопки, указатель, клавиатура). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var Input = { ax: 0, jump: false, actionHeld: false, stick: { id: -1, ox: 0, oy: 0, x: 0, y: 0 }, drag: -1, keys: {} };
  var toastT = null, shopReturn = 'menuStart';

  var UI = {
    Input: Input,
    init: function () {
      // иконки HUD, нарисованные в игре
      var coin = Assets.dataURL(Assets.coin()), clock = Assets.dataURL(Assets.clock());
      $('coins').innerHTML = '<img src="' + coin + '" width="18" height="18" style="vertical-align:-3px"> <span id="coinVal">0</span>';
      $('timeBox').innerHTML = '<img src="' + clock + '" width="18" height="18" style="vertical-align:-3px"> <span id="timeVal">0</span>с';
      $('cabbageBox').innerHTML = '<img src="' + Assets.dataURL(Assets.cabbage(0)) + '" width="22" height="20" style="vertical-align:-5px"> <span id="cabbageVal">100</span>%';

      $('btnPlay').onclick = function () { Sfx.unlock(); Game.start(); };
      $('btnHelp').onclick = function () { UI.show('menuHelp'); };
      $('btnHelpClose').onclick = function () { UI.hide('menuHelp'); };
      $('btnPause').onclick = function () { Game.pause(); };
      $('btnResume').onclick = function () { Game.resume(); };
      $('btnRestart').onclick = function () { UI.hideAll(); Game.start(); };
      $('btnAgain').onclick = function () { UI.hideAll(); Game.start(); };
      $('btnSound').onclick = function () { UI.setSound(!Sfx.isEnabled()); };
      function openShop(from) { shopReturn = from; UI.hideAll(); UI.renderShop(); UI.show('menuShop'); }
      $('btnShopStart').onclick = function () { openShop('menuStart'); };
      $('btnShopPause').onclick = function () { openShop('menuPause'); };
      $('btnShopOver').onclick = function () { openShop('menuOver'); };
      $('btnShopClose').onclick = function () { UI.hide('menuShop'); UI.show(shopReturn); UI.refreshToolbar(true); };
      UI.setSound(Save.data.sound, true);

      // кнопки действий
      function press(el, fn, hold) {
        el.addEventListener('pointerdown', function (e) { e.preventDefault(); Sfx.unlock(); try { el.setPointerCapture(e.pointerId); } catch (x) {} fn(true); });
        el.addEventListener('pointerup', function (e) { e.preventDefault(); fn(false); });
        el.addEventListener('pointercancel', function () { fn(false); });
      }
      press($('btnAction'), function (down) { Input.actionHeld = down; if (down && Game.state === 'play') Player.tryAction(); });
      press($('btnJump'), function (down) { if (down) Input.jump = true; });
      press($('btnDrop'), function (down) { if (down && Game.state === 'play') Player.drop(); });

      UI.buildToolbar();
      UI.bindCanvas();
      UI.bindKeys();
      document.addEventListener('touchmove', function (e) { e.preventDefault(); }, { passive: false });
      document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    },

    setSound: function (on, silent) {
      Sfx.setEnabled(on); Save.data.sound = on; Save.save();
      $('btnSound').textContent = 'Звук: ' + (on ? 'вкл' : 'выкл');
      if (!silent) Sfx.play('click');
    },

    show: function (id) { $(id).classList.remove('hidden'); },
    hide: function (id) { $(id).classList.add('hidden'); },
    hideAll: function () { ['menuStart', 'menuHelp', 'menuPause', 'menuOver', 'menuShop'].forEach(UI.hide); },

    toast: function (msg, ms) {
      var t = $('toast'); t.textContent = msg; t.classList.add('show');
      clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, ms || 2200);
    },

    renderShop: function () {
      $('shopCoins').textContent = Save.data.coins;
      Shop.render($('shopList'), function () { $('shopCoins').textContent = Save.data.coins; UI.renderShop(); });
    },

    showOver: function (st) {
      function m(s) { return Math.floor(s / 60) + ':' + ('0' + Math.floor(s % 60)).slice(-2); }
      $('stats').innerHTML = 'Время: <b>' + m(st.time) + '</b> (рекорд ' + m(Save.data.bestTime) + ')<br>' +
        'Побеждено овец: <b>' + st.kills + '</b><br>Монет за раунд: <b>' + st.coins + '</b><br>' +
        'Краж: ' + st.steals + ' · Туннелей: ' + st.tunnels + ' · Сломано досок: ' + st.boards + ' · Прыжков: ' + st.jumps;
      UI.show('menuOver');
    },

    /* панель инструментов */
    buildToolbar: function () {
      var bar = $('toolbar'); bar.innerHTML = '';
      var kinds = ['hammer', 'shovel', 'stone'];
      if (Save.data.tools.sledge) kinds.push('sledge');
      kinds.forEach(function (k) {
        var b = document.createElement('button'); b.className = 'tool'; b.dataset.kind = k;
        var im = document.createElement('img'); im.src = Assets.itemIcon(k); im.style.cssText = 'width:34px;height:34px;object-fit:contain;pointer-events:none';
        var dur = document.createElement('div'); dur.className = 'dur'; dur.innerHTML = '<i></i>';
        var cnt = document.createElement('span'); cnt.style.cssText = 'position:absolute;top:2px;right:5px;font-size:12px;font-weight:800;color:#ffe9a8'; cnt.className = 'cnt';
        b.appendChild(im); b.appendChild(cnt); b.appendChild(dur);
        b.addEventListener('pointerdown', function (e) { e.preventDefault(); Sfx.unlock(); if (Game.state === 'play') Player.equip(k); });
        bar.appendChild(b);
      });
      UI._kinds = kinds.join();
    },
    refreshToolbar: function (force) {
      var kinds = ['hammer', 'shovel', 'stone'].concat(Save.data.tools.sledge ? ['sledge'] : []).join();
      if (force && UI._kinds !== kinds) UI.buildToolbar();
      var bar = $('toolbar'), held = Player.held ? Player.held.kind : null;
      Array.prototype.forEach.call(bar.children, function (b) {
        var k = b.dataset.kind, bag = Items.ofKind(k, ['bag', 'held']);
        var cur = Player.held && Player.held.kind === k ? Player.held : bag.sort(function (a, c) { return c.dur - a.dur; })[0];
        b.classList.toggle('sel', held === k);
        b.classList.toggle('empty', !cur);
        b.querySelector('.dur i').style.width = cur ? Math.max(0, cur.dur / cur.maxDur * 100) + '%' : '0%';
        b.querySelector('.dur i').style.background = cur && cur.dur / cur.maxDur < 0.25 ? '#e0533c' : '#7ddc4a';
        b.querySelector('.cnt').textContent = k === 'stone' ? bag.length + '' : (k === 'shovel' && held === 'shovel' ? (Player.mode === 'dig' ? '⛏' : '▲') : '');
      });
    },
    refreshHud: function (g) {
      $('coinVal').textContent = Save.data.coins;
      $('timeVal').textContent = Math.floor(g.time);
      var integ = Fence.integrity();
      $('cabbageVal').textContent = integ;
      $('cabbageBox').style.borderColor = integ < 35 ? '#ff5a4a' : integ < 65 ? '#ffd24a' : 'rgba(255,230,160,.5)';
    },

    /* ---------- ввод ---------- */
    bindCanvas: function () {
      var cv = $('game');
      cv.addEventListener('pointerdown', function (e) {
        e.preventDefault(); Sfx.unlock();
        if (Game.state !== 'play') return;
        var zone = e.clientX < window.innerWidth * 0.36 && e.clientY > window.innerHeight * 0.36;
        if (zone && Input.stick.id < 0) {
          Input.stick.id = e.pointerId; Input.stick.ox = Input.stick.x = e.clientX; Input.stick.oy = Input.stick.y = e.clientY;
          try { cv.setPointerCapture(e.pointerId); } catch (x) {}
          return;
        }
        var p = Game.toWorld(e.clientX, e.clientY);
        if (Game.pointerDown(p.x, p.y)) { Input.drag = e.pointerId; try { cv.setPointerCapture(e.pointerId); } catch (x) {} }
      });
      cv.addEventListener('pointermove', function (e) {
        e.preventDefault();
        if (e.pointerId === Input.stick.id) {
          Input.stick.x = e.clientX; Input.stick.y = e.clientY;
          var dx = e.clientX - Input.stick.ox, dy = e.clientY - Input.stick.oy;
          var a = Math.max(-1, Math.min(1, dx / 46));
          Input.ax = Math.abs(a) < 0.15 ? 0 : a;
          if (dy < -48 && !Input.stick.jumped) { Input.jump = true; Input.stick.jumped = true; }
          if (dy > -20) Input.stick.jumped = false;
        } else if (e.pointerId === Input.drag) {
          var p = Game.toWorld(e.clientX, e.clientY); Game.pointerMove(p.x, p.y);
        }
      });
      function up(e) {
        if (e.pointerId === Input.stick.id) { Input.stick.id = -1; Input.ax = 0; Input.stick.jumped = false; }
        if (e.pointerId === Input.drag) { Input.drag = -1; Game.pointerUp(); }
      }
      cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    },
    bindKeys: function () {
      function upd() {
        var k = Input.keys; Input.ax = (k.ArrowRight || k.KeyD ? 1 : 0) - (k.ArrowLeft || k.KeyA ? 1 : 0);
        Input.actionHeld = !!(k.KeyF || k.KeyJ || k.Enter);
      }
      window.addEventListener('keydown', function (e) {
        if (e.repeat) return;
        Input.keys[e.code] = true; upd();
        if (Game.state !== 'play') { if (e.code === 'KeyP' || e.code === 'Escape') Game.resume(); return; }
        if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') { Input.jump = true; e.preventDefault(); }
        if (e.code === 'KeyF' || e.code === 'KeyJ' || e.code === 'Enter') Player.tryAction();
        if (e.code === 'KeyQ') Player.drop();
        if (e.code === 'Digit1') Player.equip('hammer');
        if (e.code === 'Digit2') Player.equip('shovel');
        if (e.code === 'Digit3') Player.equip('stone');
        if (e.code === 'Digit4' && Save.data.tools.sledge) Player.equip('sledge');
        if (e.code === 'KeyP' || e.code === 'Escape') Game.pause();
      });
      window.addEventListener('keyup', function (e) { Input.keys[e.code] = false; upd(); });
      window.addEventListener('blur', function () { Input.keys = {}; Input.ax = 0; Input.actionHeld = false; if (Game.state === 'play') Game.pause(); });
    }
  };
  window.UI = UI;
})();
