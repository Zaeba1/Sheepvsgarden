/* Сохранение прогресса в localStorage (монеты, настройки, покупки). */
(function () {
  'use strict';
  var KEY = 'sheep_vs_cabbage_save_v1';

  function defaults() {
    return {
      coins: 0,
      sound: true,
      bestTime: 0,
      bestKills: 0,
      games: 0,
      upgrades: { hammer: 0, shovel: 0, stone: 0 },
      tools: { sledge: false },
      skins: { sheep: 'classic', fence: 'oak', fx: 'dust' },
      owned: { classic: true, oak: true, dust: true }
    };
  }

  var data = defaults();

  function merge(t, s) {
    for (var k in s) {
      if (!Object.prototype.hasOwnProperty.call(s, k)) continue;
      if (s[k] && typeof s[k] === 'object' && !Array.isArray(s[k]) && t[k] && typeof t[k] === 'object') merge(t[k], s[k]);
      else t[k] = s[k];
    }
  }

  function load() {
    try {
      var raw = window.localStorage.getItem(KEY);
      if (raw) merge(data, JSON.parse(raw));
    } catch (e) { console.warn('Не удалось загрузить сохранение', e); }
  }

  function save() {
    try { window.localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* приватный режим */ }
  }

  window.Save = {
    data: data,
    load: load,
    save: save,
    addCoins: function (n) { data.coins += n; save(); },
    spend: function (n) { if (data.coins < n) return false; data.coins -= n; save(); return true; }
  };
})();
