/* Овца: характеристики, физика, получение урона, скелетная (процедурная) анимация и отрисовка. */
(function () {
  'use strict';
  var GRAV = 1700;
  function rr(a, b) { return a + Math.random() * (b - a); }
  function cl(v, a, b) { return v < a ? a : v > b ? b : v; }

  function Sheep(id, stats, x) {
    this.id = id;
    this.x = x; this.y = C.GROUND - 15 - 2;
    this.hw = 21; this.hh = 15;
    this.vx = 0; this.vy = 0; this.face = 1; this.ground = false; this.hitX = 0;
    for (var k in stats) this[k] = stats[k];
    this.walkSpeed = 60 + 62 * this.speed;
    this.runSpeed = this.walkSpeed * 1.55;
    this.hp = this.maxHp;
    this.item = null; this.stun = 0; this.flash = 0; this.dead = false; this.lastSwing = -1; this.kin = false;
    this.ph = Math.random() * 6; this.landT = 0; this.wasAir = false; this.animState = null; this.pose = 0;
    this.bubble = null; this.t = Math.random() * 10; this.spawnT = 0.5; this.stepT = 0;
    this.lane = (id % 3) * 3 - 3;
    this.ai = AI.newBrain(this);
  }

  Sheep.rollStats = function (diff, xp, respawned) {
    var pen = respawned ? 0.12 : 0;
    return {
      speed: cl(rr(0.25, 0.75) + diff * 0.15, 0.1, 1),
      strength: cl(rr(0.25, 0.8) + diff * 0.1, 0.1, 1),
      stamina: cl(rr(0.3, 0.8) + diff * 0.1, 0.1, 1),
      bravery: cl(rr(0.2, 0.8), 0.05, 1),
      attention: cl(rr(0.3, 0.85) + diff * 0.1, 0.1, 1),
      cunning: cl(rr(0.3, 0.75) + diff * 0.2 - pen + Math.min(0.12, xp * 0.012), 0.1, 1),
      learn: cl(rr(0.3, 0.85), 0.1, 1),
      maxHp: Math.min(100, 60 + Math.floor(diff * 8) * 4)
    };
  };

  // максимум ~124 px при силе 1: целый забор (~128 px) перепрыгнуть нельзя, только повреждённый или опущенный
  Sheep.prototype.jumpApex = function () { return 62 + this.strength * 62; };
  Sheep.prototype.jumpV = function (apex) { return Math.sqrt(2 * GRAV * (apex || this.jumpApex())); };
  Sheep.GRAV = GRAV;

  Sheep.prototype.say = function (txt, t) { this.bubble = { text: txt, t: t || 1.1 }; };

  Sheep.prototype.hurt = function (dmg, dir, kb, src) {
    if (this.dead || this.spawnT > 0.3) return;
    this.hp -= dmg;
    this.flash = 0.16;
    this.stun = src === 'thrown' ? 0.35 : 0.5 + Math.min(0.3, dmg / 100);
    this.kin = false;
    this.vx = dir * (kb || 200) * (1.1 - this.strength * 0.4);
    this.vy = -200;
    this.face = dir > 0 ? -1 : 1;
    this.hitDir = dir;
    if (this.item) {
      Items.toGround(this.item, this.x, this.y - 10, dir * 90 + (Math.random() - 0.5) * 60, -250, 0.8);
      this.item = null;
      Game.toast('Овца выронила предмет!');
    }
    Sfx.play('hit');
    Game.burst('star', this.x, this.y - 10, 5);
    AI.onHurt(this, src);
    if (this.hp <= 0) Game.killSheep(this);
  };

  Sheep.prototype.update = function (dt, G) {
    this.t += dt;
    if (this.flash > 0) this.flash -= dt;
    if (this.spawnT > 0) this.spawnT -= dt;
    if (this.bubble) { this.bubble.t -= dt; if (this.bubble.t <= 0) this.bubble = null; }
    this.animState = null;
    if (this.stun > 0) this.stun -= dt;
    else AI.think(this, dt, G);

    if (this.kin) { this.vx = 0; this.vy = 0; this.ground = false; }
    else {
      this.vy = Math.min(900, this.vy + GRAV * dt);
      World.move(this, this.vx * dt, this.vy * dt);
      Fence.collideBox(this, this.strength);
      Items.collideBox(this, this.strength);
      if (this.x < this.hw) this.x = this.hw;
      if (this.x > C.W - this.hw) this.x = C.W - this.hw;
    }
    var air = !this.ground && !this.kin;
    if (this.wasAir && this.ground) {
      this.landT = 0.22;
      if (Math.abs(this.vy) < 1) { Sfx.play('thud'); Game.burst('dust', this.x, this.y + this.hh, 3); }
    }
    this.wasAir = air;
    if (this.landT > 0) this.landT -= dt;
    var sp = Math.abs(this.vx);
    if (this.ground && sp > 8) {
      this.ph += sp * dt * 0.075;
      this.stepT += sp * dt;
      if (this.stepT > 52) { this.stepT = 0; if (Math.abs(this.x - Player.x) < 400) Sfx.play('step'); }
    }
  };

  Sheep.prototype.currentAnim = function () {
    if (this.stun > 0) return 'hit';
    if (this.animState) return this.animState;
    if (!this.ground && !this.kin) return this.vy < 0 ? 'jump' : 'fall';
    if (this.landT > 0) return 'land';
    var sp = Math.abs(this.vx);
    if (sp > this.walkSpeed * 1.25) return 'run';
    if (sp > 8) return 'walk';
    return 'idle';
  };

  /* ----- рисование глаз ----- */
  function eye(g, x, y, r, mode, lookX, lookY) {
    if (mode === 'happy') {
      g.strokeStyle = '#1c1a22'; g.lineWidth = 1.8; g.lineCap = 'round';
      g.beginPath(); g.arc(x, y + r * 0.5, r * 0.8, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); return;
    }
    if (mode === 'hit') {
      g.strokeStyle = '#1c1a22'; g.lineWidth = 1.8; g.lineCap = 'round';
      g.beginPath(); g.moveTo(x - r * 0.7, y - r * 0.7); g.lineTo(x + r * 0.5, y); g.lineTo(x - r * 0.7, y + r * 0.7); g.stroke(); return;
    }
    g.fillStyle = '#1c1a22'; g.beginPath(); g.arc(x, y, r + 0.9, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
    var pr = mode === 'wide' ? r * 0.38 : r * 0.55;
    g.fillStyle = '#1c1a22'; g.beginPath(); g.arc(x + lookX * r * 0.35, y + lookY * r * 0.3, pr, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(x + lookX * r * 0.35 - pr * 0.35, y + lookY * r * 0.3 - pr * 0.4, pr * 0.32, 0, 7); g.fill();
    if (mode === 'smug') {          // полуприкрытые «хитрые» глаза
      g.fillStyle = '#5b5666';
      g.beginPath(); g.moveTo(x - r - 1, y - r - 1); g.lineTo(x + r + 1, y - r - 1); g.lineTo(x + r + 1, y - r * 0.1); g.lineTo(x - r - 1, y + r * 0.25); g.closePath(); g.fill();
      g.strokeStyle = '#1c1a22'; g.lineWidth = 1.2;
      g.beginPath(); g.moveTo(x - r - 1, y + r * 0.25); g.lineTo(x + r + 1, y - r * 0.1); g.stroke();
    }
  }

  Sheep.prototype.draw = function (g, t, skin) {
    var Pt = Assets.sheep(skin || 'classic');
    var a = this.currentAnim(), ph = this.ph, st = this.t;
    var legAmp = 0, bodyDy = 0, bodyRot = 0, headRot = 0, headDx = 0, headDy = 0, tail = Math.sin(st * 3) * 0.15;
    var earAng = Math.PI - 0.35, eyeMode = 'normal', lunge = 0, frontScratch = 0;
    var moving = Math.abs(this.vx) > 8;
    var breath = Math.sin(st * 2.2) * 0.7;

    switch (a) {
      case 'walk': legAmp = 0.55; bodyDy = -Math.abs(Math.sin(ph)) * 1.8; headDy = Math.sin(ph * 2) * 0.8; headRot = Math.sin(ph) * 0.05; tail = Math.sin(ph) * 0.25; break;
      case 'run': case 'flee': legAmp = 0.9; bodyDy = -Math.abs(Math.sin(ph)) * 3.6; bodyRot = 0.05; headRot = -0.08; tail = -0.5 + Math.sin(ph * 2) * 0.2; earAng = Math.PI - 0.05; if (a === 'flee') eyeMode = 'wide'; break;
      case 'sneak': legAmp = 0.38; bodyDy = 2.5; headDy = 3; headRot = 0.18; eyeMode = 'smug'; tail = Math.sin(st * 9) * 0.1; break;
      case 'jump': legAmp = 0; bodyRot = -0.2; tail = -0.7; earAng = Math.PI - 0.9; break;
      case 'fall': bodyRot = 0.14; tail = -0.4; earAng = Math.PI - 1.0; eyeMode = 'wide'; break;
      case 'land': bodyDy = 3.4 * (this.landT / 0.22); headDy = 2; break;
      case 'dig': bodyDy = 3; bodyRot = 0.1 + Math.sin(st * 14) * 0.03; headRot = 0.6; headDy = 4; frontScratch = 1; tail = Math.sin(st * 10) * 0.35; break;
      case 'bash': var p = this.pose; bodyDy = 1; headRot = p < 0.5 ? -0.4 * (p / 0.5) : -0.4 + 1.4 * Math.min(1, (p - 0.5) / 0.2); lunge = p > 0.55 ? 7 : -3 * p; bodyRot = p > 0.55 ? 0.1 : -0.05; eyeMode = 'wide'; break;
      case 'steal': headDx = 5; headRot = -0.12; headDy = -1; eyeMode = 'smug'; legAmp = moving ? 0.35 : 0; bodyDy = 1.5; lunge = this.pose * 4; break;
      case 'hit': bodyRot = -0.28; headRot = -0.5; bodyDy = -2; eyeMode = 'hit'; earAng = Math.PI - 1.1; tail = -1; break;
      case 'alert': case 'observe': headDy = -4; headRot = -0.22; earAng = Math.PI + 0.55; eyeMode = 'wide'; bodyDy = a === 'alert' ? -Math.abs(Math.sin(st * 14)) * 2.2 : 0; tail = Math.sin(st * 6) * 0.2; break;
      case 'happy': bodyDy = -Math.abs(Math.sin(st * 9)) * 5; headRot = Math.sin(st * 9) * 0.15; eyeMode = 'happy'; tail = Math.sin(st * 22) * 0.7; earAng = Math.PI + 0.3; break;
      case 'push': bodyDy = 2; headRot = 0.4; legAmp = 0.5; lunge = 3; eyeMode = 'wide'; break;
      default: headRot = Math.sin(st * 1.3) * 0.06; headDy = breath * 0.5; bodyDy = breath * 0.4;
    }
    if (this.flash > 0 && Math.floor(this.flash * 40) % 2 === 0) eyeMode = 'hit';

    var spawnS = this.spawnT > 0 ? 1 - this.spawnT / 0.5 : 1;
    g.save();
    // тень
    var fy = this.y + this.hh;
    var sh = this.ground || this.kin ? fy : Math.max(fy, World.surfaceY(this.x));
    var hgt = Math.max(0, sh - fy);
    g.fillStyle = 'rgba(0,0,0,' + (0.3 - Math.min(0.2, hgt / 400)).toFixed(2) + ')';
    g.beginPath(); g.ellipse(this.x, sh + 1, 26 - hgt * 0.04, 5, 0, 0, 7); g.fill();

    g.translate(this.x, fy + this.lane * 0.0);
    if (spawnS < 1) { g.globalAlpha = spawnS; g.scale(0.7 + 0.3 * spawnS, 0.7 + 0.3 * spawnS); }
    g.scale(this.face, 1);
    if (this.flash > 0) { /* белая вспышка при ударе реализована через композитинг ниже */ }

    // ноги: далёкие
    var hipY = -13 + bodyDy * 0.5;
    function leg(x, ang, far) {
      g.save(); g.translate(x, hipY); g.rotate(ang);
      if (far) g.globalAlpha *= 0.72;
      g.drawImage(Pt.leg.c, -5.5, 0, 11, 20);
      g.restore();
    }
    var s1 = Math.sin(ph) * legAmp, s2 = -s1;
    if (a === 'jump') { s1 = -0.7; s2 = 0.6; }
    if (a === 'fall') { s1 = 0.4; s2 = -0.4; }
    var fa = frontScratch ? Math.sin(st * 20) * 0.9 - 0.2 : s1;
    var fb = frontScratch ? Math.sin(st * 20 + 3) * 0.9 - 0.2 : s2;
    leg(8 + lunge * 0.4, fb, true);
    leg(-11, s1, true);
    leg(14 + lunge * 0.4, fa, false);
    leg(-16, s2, false);

    // тело
    g.save();
    g.translate(0 + lunge * 0.6, -25 + bodyDy); g.rotate(bodyRot);
    // хвост
    g.save(); g.translate(-26, -4); g.rotate(tail); g.drawImage(Pt.tail.c, -8, -9, 20, 20); g.restore();
    g.drawImage(Pt.body.c, -35, -28, 70, 56);
    // голова
    var hx = 24 + headDx + lunge * 0.4, hy = -8 + headDy;
    g.save(); g.translate(hx, hy); g.rotate(headRot);
    // дальнее ухо
    g.save(); g.translate(-3, -16); g.rotate(earAng + 0.25); g.globalAlpha *= 0.8; g.drawImage(Pt.ear.c, -2, -6, 18, 12); g.restore();
    g.drawImage(Pt.head.c, -10, -24, 36, 34);
    var lx = Math.cos(st * 0.7) * 0.6, ly = 0.1;
    var pd = Player;
    if (Math.abs(pd.x - this.x) < 300) { lx = (pd.x - this.x) * this.face > 0 ? 0.8 : -0.6; ly = (pd.y - this.y) > 20 ? 0.6 : (pd.y - this.y) < -20 ? -0.5 : 0; }
    eye(g, 1, -8.5, 3.0, eyeMode, lx, ly);
    eye(g, 11, -9.5, 3.9, eyeMode, lx, ly);
    // ближнее ухо
    g.save(); g.translate(-1, -14); g.rotate(earAng); g.drawImage(Pt.ear.c, -2, -6, 18, 12); g.restore();
    // предмет в зубах
    if (this.item) {
      var kind = this.item.kind, ir = kind === 'stone' ? 0 : 1.3;
      if (a === 'bash') ir = 0.6 + this.pose * 1.2;
      Items.drawSprite(g, kind, 22, 6, ir, kind === 'stone' ? 0.8 : 0.62);
    }
    g.restore();
    g.restore();

    // вспышка при ударе
    if (this.flash > 0) {
      g.globalAlpha = 0.35; g.fillStyle = '#fff';
      g.beginPath(); g.ellipse(0, -25, 28, 22, 0, 0, 7); g.fill();
    }
    g.restore();
  };

  window.Sheep = Sheep;
})();
