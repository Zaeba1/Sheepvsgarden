/* Точка входа. */
(function () {
  'use strict';
  /* Необязательная подмена спрайтов: если рядом лежит assets/overrides.json вида
     {"board_oak_0":"assets/board.png","item_hammer":"assets/hammer.png"}, картинки подгружаются поверх
     процедурной графики. Нет файла или картинка не грузится: игра спокойно продолжает с встроенной графикой. */
  function loadOverrides() {
    if (!window.fetch || location.protocol === 'file:') return;
    fetch('assets/overrides.json').then(function (r) { return r.ok ? r.json() : null; }).then(function (map) {
      if (!map) return;
      Object.keys(map).forEach(function (k) { Assets.override(k, map[k]); });
    }).catch(function () { /* файла нет: это нормально */ });
  }

  function boot() {
    try {
      Save.load();
      Assets.init();
      if (!Assets.ready) console.warn('Графика сгенерирована с ошибками', Assets.errors);
      UI.init();
      Game.init();
      UI.show('menuStart');
      loadOverrides();
    } catch (e) {
      console.error(e);
      var d = document.createElement('div');
      d.style.cssText = 'position:fixed;inset:0;background:#222;color:#fff;padding:20px;font:16px sans-serif;z-index:99';
      d.textContent = 'Не удалось запустить игру: ' + e.message;
      document.body.appendChild(d);
    }
  }
  window.addEventListener('error', function (e) { console.error('JS error:', e.message, e.filename, e.lineno); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
