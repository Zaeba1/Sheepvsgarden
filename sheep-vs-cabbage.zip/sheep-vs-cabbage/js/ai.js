/*
 * ИИ овец: конечный автомат + utility-выбор способа прорыва.
 * Решения зависят от состояния забора, предметов, расстояний, угроз и общего «опыта стада» (Group).
 */
(function () {
  'use strict';
  var GRAV = 1700;
  function rr(a, b) { return a + Math.random() * (b - a); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  var Group = null, DIFF = 0;
  function newGroup() {
    return { xp: 0, success: { jump: 0, 'break': 0, dig: 0, steal: 0 }, fail: { jump: 0, 'break': 0, dig: 0, steal: 0 },
      filled: 0, filledX: [], reinf: 0, plans: [], hurt: 0 };
  }

  var AI = {
    get group() { return Group; },
    reset: function () { Group = newGroup(); DIFF = 0; },
    setDifficulty: function (d) { DIFF = d; },
    newBrain: function (s) {
      return { state: 'enter', t: 0, pen: { jump: 0, 'break': 0, dig: 0, tunnel: 0 }, stuck: 0, lastX: s.x, lastT: 0, obst: 0,
        board: null, dig: null, jump: null, goalX: 0, next: null, atk: 0, stealCd: rr(4, 12), watch: 0, nervous: 0, grab: 0,
        fleeT: 0, reactCd: 0, alertT: 0, distractCd: rr(5, 12), bumpT: 0, block: 0, target: null, exploreT: rr(5, 11) * (1 - DIFF * 0.4), choice: '' };
    },
    onReinforce: function () { if (Group) Group.reinf++; },
    onFill: function (x) {
      if (!Group) return;
      Group.filled++; Group.filledX.push(x); if (Group.filledX.length > 8) Group.filledX.shift();
    },
    onHurt: function (s, src) {
      var b = s.ai; if (Group) Group.hurt++;
      if (b.dig) { b.dig = null; s.kin = false; Group.fail.dig++; }
      if (b.state === 'steal_grab' || b.state === 'steal_sneak' || b.state === 'steal_watch') Group.fail.steal++, b.stealCd = rr(6, 11);
      b.jump = null;
      go(s, 'flee'); b.fleeT = rr(0.9, 1.8) * (1.2 - s.bravery * 0.6);
    }
  };

  function go(s, state) { var b = s.ai; b.state = state; b.t = 0; b.stuck = 0; b.lastX = s.x; b.lastT = 0; b.obst = 0; }

  function tryJump(s, apex) {
    if (!s.ground) return;
    s.vy = -s.jumpV(apex); s.ground = false; Sfx.play('jump');
  }

  /* Идёт к x. true — пришла. */
  function walkTo(s, x, speed, dt, tol, noHop) {
    var b = s.ai, d = x - s.x;
    if (Math.abs(d) <= (tol || 6)) { s.vx *= 0.6; return true; }
    var dir = d > 0 ? 1 : -1;
    s.vx += (dir * speed - s.vx) * Math.min(1, dt * 8);
    s.face = dir;
    if (s.hitX === dir && s.ground && !noHop) {
      b.obst += dt;
      if (b.obst > 0.22) { tryJump(s, 72); b.obst = 0; }
    } else b.obst = 0;
    return false;
  }

  function stuckCheck(s, dt) {
    var b = s.ai; b.lastT += dt;
    if (b.lastT > 0.8) {
      if (Math.abs(s.x - b.lastX) < 6) b.stuck += b.lastT; else b.stuck = 0;
      b.lastX = s.x; b.lastT = 0;
    }
    return b.stuck;
  }

  /* ---------- планы туннеля ---------- */
  function buildPlan(x0) {
    var fr = C.FENCE_R_X, xe = fr + 90, yT = C.GROUND + 12 + 18 + 0;   // центр туннеля по y (с запасом)
    var cy = C.GROUND + 12 + 36 - 15;
    return { x0: x0, xe: xe, wp: [
      { x: x0, y: World.surfaceY(x0) - 15 }, { x: x0 + 56, y: cy }, { x: xe - 56, y: cy }, { x: xe, y: World.surfaceY(xe) - 15 }
    ] };
  }
  function planOpen(plan) {
    var pts = 0;
    for (var i = 0; i < plan.wp.length - 1; i++) {
      var a = plan.wp[i], b = plan.wp[i + 1], n = Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 8);
      for (var k = 0; k <= n; k++) {
        var x = a.x + (b.x - a.x) * k / n, y = a.y + (b.y - a.y) * k / n;
        if (y > C.GROUND + 20 && World.overlaps(x, y, 19, 13)) return false;
        pts++;
      }
    }
    return true;
  }
  function findOpenTunnel() {
    for (var i = 0; i < Group.plans.length; i++) {
      if (planOpen(Group.plans[i]) && !Items.blockingStone(Group.plans[i].x0 + 56, Group.plans[i].wp[1].y, 30, 20)) return Group.plans[i];
    }
    return null;
  }
  function chooseDigX(s) {
    var fl = C.FENCE_L_X, cands = [fl - 100, fl - 140, fl - 70], best = cands[0], bs = 1e9;
    cands.forEach(function (x) {
      var pen = 0;
      Group.filledX.forEach(function (fx) { if (Math.abs(fx - x) < 90) pen += 1; });
      var sc = pen * (0.5 + s.cunning) + Math.random() * (1.2 - s.cunning);
      if (sc < bs) { bs = sc; best = x; }
    });
    return best;
  }

  /* ---------- выбор действия (utility) ---------- */
  function decide(s, G) {
    var b = s.ai, free = Fence.clearHeight();
    if (free >= 36) { b.choice = 'pass'; go(s, 'pass'); return; }
    var top = Fence.topHeight(), apex = s.jumpApex(), item = s.item ? s.item.kind : null;
    var learn = 0.5 + s.learn, opts = [], u;

    if (apex > top + 6) {
      u = 0.4 + 0.35 * s.strength + 0.15 * s.bravery + 0.1 * Math.min(Group.success.jump, 3) * learn - 0.12 * Math.min(Group.fail.jump, 3);
      opts.push(['jump', u - (b.pen.jump > 0 ? 0.5 : 0)]);
    }
    var low = Fence.boards.filter(function (x) { return !x.dead; }).sort(function (a, c) { return c.a.y - a.a.y; }).slice(0, 2);
    var hard = 0;
    low.forEach(function (x) { hard += x.hp / 60 + x.reinf * 0.5; });
    hard = low.length ? hard / low.length : 0;
    u = 0.22 + 0.18 * s.strength - hard * 0.12 + 0.06 * Math.min(Group.success['break'], 3) * learn;
    u += item === 'sledge' ? 0.7 : item === 'hammer' ? 0.62 : item === 'stone' ? 0.2 : 0;
    opts.push(['break', u - (b.pen['break'] > 0 ? 0.5 : 0)]);

    var tun = findOpenTunnel();
    if (tun) opts.push(['tunnel', 0.95 - (b.pen.tunnel > 0 ? 0.6 : 0)]);
    u = 0.36 + 0.18 * s.cunning + (item === 'shovel' ? 0.55 : 0) + 0.08 * Math.min(Group.success.dig, 3) * learn - 0.07 * Math.min(Group.filled, 5);
    opts.push(['dig', u - (b.pen.dig > 0 ? 0.5 : 0)]);
    opts.push(['wait', 0.1 + 0.1 * s.attention]);

    var best = null, bs = -1e9;
    opts.forEach(function (o) {
      var sc = o[1] + (Math.random() - 0.5) * 0.3 * (1.1 - s.cunning);
      if (sc > bs) { bs = sc; best = o[0]; }
    });
    b.choice = best;
    switch (best) {
      case 'jump': b.jump = null; go(s, 'jump_run'); break;
      case 'break': b.board = null; go(s, 'break'); break;
      case 'dig': b.dig = null; b.goalX = chooseDigX(s); go(s, 'dig_goto'); break;
      case 'tunnel': b.goalX = tun.x0 - 14; go(s, 'tunnel_go'); break;
      default: go(s, 'wait'); b.goalX = rr(0.9, 1.9) * (1.3 - s.attention * 0.5);
    }
    if (best !== 'wait') s.say(best === 'dig' ? '?' : '!', 0.7);
  }

  /* ---------- кража ---------- */
  function checkSteal(s) {
    var b = s.ai, P = Player;
    if (s.item || b.stealCd > 0 || !P.held || s.x > C.FENCE_L_X) return false;
    var d = Math.abs(P.x - s.x), range = 110 + 250 * s.attention;
    if (d > range || Math.abs(P.y - s.y) > 80 || P.still < 0.7) return false;
    go(s, 'steal_notice'); b.watch = 0; s.say('!', 0.8); Sfx.play('bleat');
    return true;
  }
  function checkGrabGround(s, dt) {
    var b = s.ai;
    if (s.item || s.cunning < 0.3 || Math.random() > dt * (0.5 + s.cunning)) return false;
    var best = null, bd = 300;
    for (var i = 0; i < Items.list.length; i++) {
      var it = Items.list[i];
      if (it.state !== 'ground' || it.noPick > 0 || Math.hypot(it.vx, it.vy) > 60) continue;
      if (Math.abs(it.y - s.y) > 45 || (it.x > C.FENCE_L_X) !== (s.x > C.FENCE_L_X)) continue;
      var d = Math.abs(it.x - s.x) + (it.kind === 'stone' ? 120 : 0);
      if (Math.abs(it.x - Player.x) < 40 && Player.held == null && Math.abs(Player.x - s.x) < 150) continue;
      if (d < bd) { bd = d; best = it; }
    }
    if (!best) return false;
    b.target = best; go(s, 'grab_ground'); s.say('?', 0.8);
    return true;
  }
  function checkDistract(s, G, dt) {
    var b = s.ai, P = Player;
    if (b.distractCd > 0 || s.cunning < 0.4 || Math.random() > dt * 0.35 * s.cunning) return false;
    var worker = null, other = false;
    G.sheep.forEach(function (o) {
      if (o.dead || o === s) return;
      if (o.ai.state === 'distract') other = true;
      if ((o.ai.state === 'break' || o.ai.state === 'dig') && Math.abs(o.x - P.x) < 280) worker = o;
    });
    if (!worker || other) return false;
    go(s, 'distract'); b.distractT = rr(4, 6.5); b.bumpT = 0.8; s.say('бе-е!', 0.9);
    return true;
  }

  function stealAbort(s, flee) {
    var b = s.ai;
    Group.fail.steal += flee ? 1 : 0;
    b.stealCd = rr(5, 10) * (1.3 - s.cunning * 0.5);
    if (flee) { go(s, 'flee'); b.fleeT = rr(0.9, 1.5); s.say('!', 0.7); } else go(s, 'approach');
  }

  function celebrate(s, dur, next) { go(s, 'celebrate'); s.ai.goalX = dur; s.ai.next = next || 'decide'; }

  /* ---------- основной цикл мышления ---------- */
  AI.think = function (s, dt, G) {
    var b = s.ai, P = Player, i;
    b.t += dt;
    if (b.stealCd > 0) b.stealCd -= dt;
    if (b.reactCd > 0) b.reactCd -= dt;
    if (b.distractCd > 0) b.distractCd -= dt;
    for (var k in b.pen) if (b.pen[k] > 0) b.pen[k] -= dt;

    if (G.over) { s.animState = 'happy'; s.vx *= 0.9; return; }

    var busy = b.state === 'dig' || b.state === 'celebrate' || b.state === 'flee' || b.state === 'enter' || b.state === 'steal_grab' || b.state === 'jump_run';
    // реакция на опасность: игрок с молотком рядом
    if (!busy && P.held && (P.held.kind === 'hammer' || P.held.kind === 'sledge') && b.reactCd <= 0 &&
        Math.abs(P.x - s.x) < 80 && Math.abs(P.y - s.y) < 60 && b.state !== 'break') {
      b.reactCd = 2.5;
      var fp = ((1 - s.bravery) * 0.75 + (s.hp < s.maxHp * 0.4 ? 0.3 : 0)) * (P.swing > 0 ? 1 : 0.55);
      if (Math.random() < fp) { go(s, 'flee'); b.fleeT = rr(1.1, 2.0); s.say('!', 0.8); Sfx.play('bleat'); }
      else { b.alertT = 0.5; }
    }
    if (b.alertT > 0 && (b.state === 'approach' || b.state === 'wait' || b.state === 'explore')) {
      b.alertT -= dt; s.animState = 'alert'; s.vx *= 0.8; return;
    }

    switch (b.state) {
      case 'enter': {
        s.animState = null;
        walkTo(s, 90, s.walkSpeed, dt, 5);
        if (b.t > 0.8) go(s, 'explore');
        break;
      }
      case 'explore': {
        if (checkSteal(s) || checkGrabGround(s, dt)) break;
        if (!b.goalX || Math.abs(s.x - b.goalX) < 8 || b.t > 6) { b.goalX = rr(120, 440); b.t = Math.min(b.t, 0.1); b.pause = rr(0.4, 1.6); }
        if (b.pause > 0) { b.pause -= dt; s.vx *= 0.8; if (b.pause > 0.3 && Math.random() < dt * 0.4) s.face = -s.face; }
        else walkTo(s, b.goalX, s.walkSpeed * 0.8, dt, 8);
        b.exploreT -= dt;
        if (b.exploreT <= 0) { b.goalX = 0; go(s, 'approach'); }
        break;
      }
      case 'approach': {
        if (checkSteal(s) || checkGrabGround(s, dt) || checkDistract(s, G, dt)) break;
        var tx = C.FENCE_L_X - Fence.HALF - s.hw - 3, far = Math.abs(tx - s.x) > 140;
        if (s.x > tx + 30) { // уже за линией забора (например, спрыгнула на доску): просто идём вперёд
          go(s, 'decide'); break;
        }
        if (walkTo(s, tx, far ? s.runSpeed : s.walkSpeed, dt, 10, true)) { decide(s, G); break; }
        if (stuckCheck(s, dt) > 2.5) { b.pen['break'] = 4; decide(s, G); }
        break;
      }
      case 'decide': decide(s, G); break;
      case 'wait': {
        s.animState = 'observe'; s.vx *= 0.8;
        if (checkSteal(s) || checkDistract(s, G, dt)) break;
        if (b.t > b.goalX) decide(s, G);
        break;
      }
      case 'pass': {
        if (Fence.clearHeight() < 30 && s.x < C.FENCE_L_X - 2 && !findOpenTunnel()) { decide(s, G); break; }
        walkTo(s, C.W - 40, s.runSpeed, dt, 6);
        if (stuckCheck(s, dt) > 2) { b.pen.tunnel = 6; b.pen['break'] = 3; decide(s, G); }
        break;
      }
      case 'tunnel_go': {
        if (walkTo(s, b.goalX, s.runSpeed, dt, 8)) go(s, 'pass');
        else if (stuckCheck(s, dt) > 2.5) { b.pen.tunnel = 8; decide(s, G); }
        break;
      }
      case 'jump_run': stateJump(s, dt, G); break;
      case 'break': stateBreak(s, dt, G); break;
      case 'dig_goto': {
        if (walkTo(s, b.goalX, s.runSpeed, dt, 6)) { b.dig = null; go(s, 'dig'); s.vx = 0; }
        else if (stuckCheck(s, dt) > 2.5) { b.pen.dig = 6; decide(s, G); }
        break;
      }
      case 'dig': stateDig(s, dt, G); break;

      /* кража */
      case 'steal_notice': {
        s.animState = 'alert'; s.vx *= 0.8; s.face = P.x > s.x ? 1 : -1;
        if (!P.held) { go(s, 'approach'); break; }
        if (b.t > 0.55) { go(s, 'steal_watch'); b.watch = 0; }
        break;
      }
      case 'steal_watch': {
        var d = Math.abs(P.x - s.x); s.face = P.x > s.x ? 1 : -1;
        if (!P.held) { stealAbort(s, false); break; }
        s.animState = 'observe';
        var ideal = 150;
        if (d > ideal + 30) walkTo(s, P.x - s.face * ideal, s.walkSpeed * 0.8, dt, 10);
        else if (d < ideal - 50) s.vx += (-s.face * s.walkSpeed * 0.6 - s.vx) * Math.min(1, dt * 6);
        else s.vx *= 0.8;
        if (P.still > 0.5) b.watch += dt; else b.watch = Math.max(0, b.watch - dt * 2);
        var need = 1.2 + (1 - s.cunning) * 2.0 + (1 - s.bravery) * 0.8;
        b.need = need;
        var facing = P.face * (s.x - P.x) > 0;
        if (d < 100 && (P.swing > 0 || (facing && Math.abs(P.vx) > 110))) { stealAbort(s, true); break; }
        if (b.t > 14 || d > 110 + 300 * s.attention) { stealAbort(s, false); break; }
        if (b.watch >= need) { go(s, 'steal_sneak'); b.nervous = 0; }
        break;
      }
      case 'steal_sneak': {
        if (!P.held) { stealAbort(s, false); break; }
        var dx = P.x - s.x, dd = Math.abs(dx); s.face = dx > 0 ? 1 : -1;
        s.animState = 'sneak';
        var facing2 = P.face * (s.x - P.x) > 0;
        if (P.swing > 0 && dd < 110) { stealAbort(s, true); break; }
        if (Math.abs(P.vx) > 60 || (facing2 && P.still < 0.3)) {
          b.nervous += dt; s.vx *= 0.7;
          if (b.nervous > 1.8) { stealAbort(s, false); break; }
        } else s.vx += (s.face * s.walkSpeed * 0.5 - s.vx) * Math.min(1, dt * 6);
        if (dd < 44) { go(s, 'steal_grab'); b.grab = 0; s.vx = 0; }
        if (b.t > 10) stealAbort(s, false);
        break;
      }
      case 'steal_grab': {
        b.grab += dt; s.animState = 'steal'; s.pose = Math.min(1, b.grab / 0.45); s.vx *= 0.8;
        s.face = P.x > s.x ? 1 : -1;
        if (b.grab >= 0.45) {
          var ok = false;
          if (P.held) {
            var aware = P.face * (s.x - P.x) > 0;
            var p = 0.3 + 0.5 * s.cunning + (aware ? -0.18 : 0.12) - Math.min(Math.abs(P.vx) / 200, 0.5);
            if (Math.abs(P.x - s.x) > 62 || Math.abs(P.vx) > 110) p = 0;
            ok = Math.random() < clamp(p, 0.02, 0.95);
          }
          if (ok) {
            var it = P.held; P.held = null;
            it.state = 'held' === it.state ? 'sheep' : 'sheep'; it.sheep = s; s.item = it;
            Group.success.steal++; Group.xp++; G.stats.steals++;
            Game.toast('Овца украла ' + Items.DEF[it.kind].name.toLowerCase() + '!');
            Sfx.play('steal'); s.say('хе-хе', 1.3);
            alertNear(s, G);
            b.stealCd = rr(10, 18);
            celebrate(s, 0.8, 'escape');
          } else {
            Group.fail.steal++;
            s.say('ой!', 0.8); s.vx = -s.face * 140; s.vy = -160;
            stealAbort(s, true);
          }
        }
        break;
      }
      case 'grab_ground': {
        var it2 = b.target;
        if (!it2 || it2.state !== 'ground' || s.item) { go(s, 'approach'); break; }
        if (walkTo(s, it2.x, s.runSpeed, dt, 12) || (Math.abs(it2.x - s.x) < 26 && Math.abs(it2.y - s.y) < 34)) {
          it2.state = 'sheep'; it2.sheep = s; s.item = it2; it2.vx = it2.vy = 0;
          s.say('хе-хе', 1.1); Sfx.play('steal'); G.stats.steals++; Group.success.steal++;
          Game.toast('Овца подобрала ' + Items.DEF[it2.kind].name.toLowerCase());
          celebrate(s, 0.6, 'decide');
        } else if (stuckCheck(s, dt) > 2.5 || b.t > 8) go(s, 'approach');
        break;
      }
      case 'escape': {   // после кражи: убегаем от игрока, затем действуем
        var away = s.x >= P.x ? 1 : -1;
        if (Math.abs(P.x - s.x) > 200 || b.t > 2.2) { go(s, 'decide'); break; }
        s.vx += (away * s.runSpeed - s.vx) * Math.min(1, dt * 8); s.face = away;
        if (s.x < 40 || s.x > C.FENCE_L_X - s.hw - 5) { s.vx *= 0.5; if (b.t > 0.8) go(s, 'decide'); }
        break;
      }
      case 'flee': {
        b.fleeT -= dt; s.animState = null;
        var aw = s.x >= P.x ? 1 : -1;
        if (s.x < 60) aw = 1;
        if (s.x > C.FENCE_L_X - s.hw - 10) aw = -1;
        s.vx += (aw * s.runSpeed - s.vx) * Math.min(1, dt * 8); s.face = aw;
        if (Math.abs(s.vx) > 8 && s.ground) s.animState = 'flee';
        if (s.hitX === aw && s.ground) tryJump(s, 72);
        if (b.fleeT <= 0) go(s, s.item ? 'decide' : 'approach');
        break;
      }
      case 'celebrate': {
        s.animState = 'happy'; s.vx *= 0.8;
        if (b.t > b.goalX) go(s, b.next || 'decide');
        break;
      }
      case 'distract': {
        b.distractT -= dt;
        var side = s.x < P.x ? -1 : 1, tx2 = P.x + side * 70;
        if (Math.abs(s.x - tx2) > 20 && b.bumpT > 0) walkTo(s, tx2, s.runSpeed, dt, 18);
        else s.vx *= 0.8;
        s.face = P.x > s.x ? 1 : -1;
        b.bumpT -= dt;
        if (b.bumpT <= 0) {
          b.bumpT = 1.4; s.say('бе-е!', 0.8); Sfx.play('bleat');
          if (s.ground) { s.vy = -380; s.ground = false; }
          if (Math.abs(P.x - s.x) < 70) { P.vx += s.face * 160; P.still = 0; }
        }
        if (b.distractT <= 0) { b.distractCd = rr(12, 20); go(s, 'approach'); }
        break;
      }
      default: go(s, 'approach');
    }
  };

  function alertNear(s, G) {
    G.sheep.forEach(function (o) {
      if (o === s || o.dead || Math.abs(o.x - s.x) > 300) return;
      o.ai.alertT = 0.7; o.say('!', 0.7);
    });
  }

  /* ---------- прыжок через забор ---------- */
  function stateJump(s, dt, G) {
    var b = s.ai, j = b.jump;
    if (!j) {
      var apex = s.jumpApex(), top = Fence.topHeight();
      if (apex <= top + 6) { b.pen.jump = 20; decide(s, G); return; }
      var v0 = s.jumpV(apex), vxj = Math.min(s.runSpeed, 165);
      var tup = (v0 - Math.sqrt(v0 * v0 - 2 * GRAV * top)) / GRAV, te = tup + 0.07;
      j = b.jump = { launchX: C.FENCE_L_X - s.hw - vxj * te, vx: vxj, v0: v0, phase: 0 };
    }
    if (j.phase === 0) {
      if (!walkTo(s, j.launchX - 130, s.walkSpeed * 1.2, dt, 6)) { if (stuckCheck(s, dt) > 3) { b.pen.jump = 15; b.jump = null; decide(s, G); } return; }
      j.phase = 1; s.face = 1; b.t = 0;
    }
    if (j.phase === 1) {
      s.face = 1; s.vx += (j.vx - s.vx) * Math.min(1, dt * 10);
      if (s.x >= j.launchX && s.vx > j.vx * 0.85 && s.ground) {
        s.vy = -j.v0; s.ground = false; j.phase = 2; s.vx = j.vx; Sfx.play('jump');
        s.say('!', 0.5);
      } else if (b.t > 6) { b.pen.jump = 15; b.jump = null; decide(s, G); }
      return;
    }
    // воздух
    s.vx = s.hitX ? s.vx : j.vx; s.face = 1;
    if (s.ground && b.t > 0.2) {
      var onTopOrBeyond = s.x > C.FENCE_L_X - 6 && (s.y < C.GROUND - 40 || s.x > C.FENCE_R_X);
      b.jump = null;
      if (onTopOrBeyond) { Group.success.jump++; Group.xp++; G.stats.jumps++; s.say('хе-хе', 1); alertNear(s, G); go(s, 'pass'); }
      else { Group.fail.jump++; b.pen.jump = 14; go(s, 'approach'); }
    }
  }

  /* ---------- ломание досок ---------- */
  function stateBreak(s, dt, G) {
    var b = s.ai, item = s.item ? s.item.kind : null;
    if (Fence.clearHeight() >= 36) { go(s, 'pass'); return; }
    var bd = b.board;
    if (!bd || bd.dead) {
      var alive = Fence.boards.filter(function (x) { return !x.dead; });
      if (!alive.length) { go(s, 'pass'); return; }
      alive.sort(function (a, c) { return (a.hp + a.reinf * 25 + a.i * 14) - (c.hp + c.reinf * 25 + c.i * 14); });
      // предпочитаем нижние доски
      var cand = alive.filter(function (x) { return x.i <= 2; });
      bd = b.board = (cand.length ? cand : alive)[0];
      b.atk = 0;
    }
    var stand = Math.min(bd.a.x, bd.b.x) - Fence.HALF - s.hw - 2;
    if (stand > C.FENCE_L_X - Fence.HALF - s.hw - 2) stand = C.FENCE_L_X - Fence.HALF - s.hw - 2;
    if (!walkTo(s, stand, s.walkSpeed * 1.3, dt, 12, true)) {
      if (stuckCheck(s, dt) > 3) { b.pen['break'] = 10; b.board = null; decide(s, G); }
      return;
    }
    s.face = 1; s.vx *= 0.5;
    var cd = item === 'sledge' ? 0.95 : item === 'hammer' ? 0.7 : item === 'stone' ? 0.8 : 1.15;
    b.atk += dt; s.animState = 'bash'; s.pose = Math.min(1, b.atk / cd);
    if (b.atk >= cd) {
      b.atk = 0;
      var base = item === 'sledge' ? 36 : item === 'hammer' ? 22 : item === 'stone' ? 12 : 6;
      var dmg = base * (0.75 + 0.5 * s.strength);
      var mx = (bd.a.x + bd.b.x) / 2, my = (bd.a.y + bd.b.y) / 2;
      var killed = Fence.damage(bd, dmg, -1);
      Sfx.play(item ? 'hit' : 'thud'); Game.burst('wood', Math.min(bd.a.x, bd.b.x), my, 4); Game.shake(1.5);
      if (s.item) Items.wear(s.item, 1);
      if (killed) {
        G.stats.boards++; Group.success['break']++; Group.xp += 0.5; s.say('хе-хе', 0.9);
        b.board = null;
        alertNear(s, G);
      }
    }
    if (b.t > 40) { b.pen['break'] = 10; b.board = null; decide(s, G); }
  }

  /* ---------- рытьё туннеля ---------- */
  function stateDig(s, dt, G) {
    var b = s.ai, d = b.dig;
    if (!d) {
      var plan = buildPlan(Math.round(b.goalX || chooseDigX(s)));
      d = b.dig = { plan: plan, i: 1, snd: 0, block: 0 };
      s.x = plan.wp[0].x; s.y = plan.wp[0].y; s.kin = true;
    }
    s.kin = true; s.animState = 'dig';
    var wp = d.plan.wp, tg = wp[d.i], dx = tg.x - s.x, dy = tg.y - s.y, dist = Math.hypot(dx, dy) || 0.001;
    var spd = ((s.item && s.item.kind === 'shovel') ? 72 : 24) * (0.75 + 0.5 * s.stamina);
    var step = Math.min(dist, spd * dt), nx = s.x + dx / dist * step, ny = s.y + dy / dist * step;
    s.face = dx >= 0 ? 1 : -1;
    var st = Items.blockingStone(nx + s.face * 6, ny, s.hw, s.hh);
    if (st) {
      d.block += dt; s.animState = 'push';
      if (s.strength >= 0.45 && d.block > 1.4 / (0.4 + s.strength)) {
        st.vx = -s.face * 220; st.vy = -300; d.block = 0; Sfx.play('thud'); s.say('!', 0.5);
      } else if (s.strength < 0.45 && d.block > 2.4) {
        s.kin = false; b.dig = null; Group.fail.dig++; b.pen.dig = 16; s.say('...', 0.9); go(s, 'approach'); return;
      }
      return;
    }
    d.block = 0;
    s.x = nx; s.y = ny;
    var inZone = nx > C.FENCE_L_X - 35 && nx < C.FENCE_R_X + 35;
    var cut = World.carveRect(nx - s.hw - 3, ny - s.hh - 3, nx + s.hw + 3, ny + s.hh + 3, inZone ? C.GROUND + 12 : undefined);
    d.snd -= dt;
    if (cut > 0 && d.snd <= 0) {
      d.snd = 0.22; Sfx.play('dig'); Game.burst('dirt', nx + s.face * 16, ny + 4, 4);
    }
    if (s.item && s.item.kind === 'shovel' && cut > 0) Items.wear(s.item, dt * 0.5);
    if (dist - step < 1.5) {
      d.i++;
      if (d.i >= wp.length) {
        s.kin = false; b.dig = null; s.vy = 0;
        var known = Group.plans.some(function (p) { return Math.abs(p.x0 - d.plan.x0) < 5; });
        if (!known) Group.plans.push(d.plan);
        Group.success.dig++; Group.xp += 1; G.stats.tunnels++;
        s.say('хе-хе', 1.2); alertNear(s, G);
        celebrate(s, 0.5, 'pass');
      }
    }
  }

  window.AI = AI;
})();
