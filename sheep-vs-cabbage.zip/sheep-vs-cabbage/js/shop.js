/* Магазин: улучшения инструментов, новый инструмент, косметика (скины овец/забора, эффекты). */
(function () {
  'use strict';
  var SHEEP = [
    { id: 'classic', name: 'Классическая', price: 0 }, { id: 'pink', name: 'Розовая', price: 60 },
    { id: 'black', name: 'Чёрная', price: 80 }, { id: 'golden', name: 'Золотая', price: 150 }];
  var FENCE = [
    { id: 'oak', name: 'Дуб', price: 0 }, { id: 'birch', name: 'Берёза', price: 70 },
    { id: 'red', name: 'Красный', price: 90 }, { id: 'blue', name: 'Синий', price: 110 }];
  var FX = [
    { id: 'dust', name: 'Пыль', price: 0 }, { id: 'sparkle', name: 'Искры', price: 90 }, { id: 'leaves', name: 'Листья', price: 70 }];
  var UP = [
    { tool: 'hammer', name: 'Молоток: прочность и урон', desc: '+25% прочности, +20% урона', max: 3, base: 40 },
    { tool: 'shovel', name: 'Лопата: прочность и захват', desc: '+25% прочности, шире копает', max: 3, base: 35 },
    { tool: 'stone', name: 'Камни: ещё один камень', desc: '+1 камень, +25% прочности', max: 3, base: 30 }];

  var Shop = {
    sheepSkins: SHEEP, fenceSkins: FENCE, fxList: FX,
    upPrice: function (u, lvl) { return u.base * (lvl + 1); },
    buyUpgrade: function (tool) {
      var u = UP.filter(function (x) { return x.tool === tool; })[0], lvl = Save.data.upgrades[tool] | 0;
      if (!u || lvl >= u.max) return false;
      if (!Save.spend(this.upPrice(u, lvl))) return false;
      Save.data.upgrades[tool] = lvl + 1; Save.save(); Items.refresh(); Sfx.play('buy'); return true;
    },
    buyTool: function () {
      if (Save.data.tools.sledge) return false;
      if (!Save.spend(150)) return false;
      Save.data.tools.sledge = true; Save.save(); Items.refresh(); Sfx.play('buy'); return true;
    },
    skin: function (kind, id, price) {
      var D = Save.data;
      if (!D.owned[id]) { if (!Save.spend(price)) return false; D.owned[id] = true; Sfx.play('buy'); }
      D.skins[kind] = id; Save.save(); return true;
    },
    render: function (root, onChange) {
      var D = Save.data, self = this;
      root.innerHTML = '';
      function head(t) { var h = document.createElement('div'); h.className = 'shopHead'; h.textContent = t; root.appendChild(h); }
      function row(icon, name, desc, btnText, disabled, cls, fn) {
        var r = document.createElement('div'); r.className = 'shopItem';
        var ic = document.createElement('div'); ic.className = 'ic';
        if (icon && icon.indexOf('data:') === 0) { var im = document.createElement('img'); im.src = icon; im.width = 30; im.height = 30; ic.appendChild(im); } else ic.textContent = icon || '';
        var tx = document.createElement('div'); tx.className = 'tx'; tx.innerHTML = '<b></b><br><span></span>';
        tx.firstChild.textContent = name; tx.lastChild.textContent = desc;
        var bt = document.createElement('button'); bt.textContent = btnText; bt.disabled = !!disabled; if (cls) bt.className = cls;
        bt.onclick = function () { fn(); onChange && onChange(); };
        r.appendChild(ic); r.appendChild(tx); r.appendChild(bt); root.appendChild(r);
      }
      head('Инструменты');
      UP.forEach(function (u) {
        var lvl = D.upgrades[u.tool] | 0, price = self.upPrice(u, lvl);
        row(Assets.itemIcon(u.tool), u.name + ' (ур. ' + lvl + '/' + u.max + ')', u.desc,
          lvl >= u.max ? 'МАКС' : price + ' монет', lvl >= u.max || D.coins < price, '', function () { self.buyUpgrade(u.tool); });
      });
      row(Assets.itemIcon('sledge'), 'Кувалда', 'Мощный удар, ломает доски, медленная',
        D.tools.sledge ? 'Куплено' : '150 монет', D.tools.sledge || D.coins < 150, '', function () { self.buyTool(); });
      function skinGroup(title, list, kind, iconFn) {
        head(title);
        list.forEach(function (s) {
          var own = !!D.owned[s.id], eq = D.skins[kind] === s.id;
          row(iconFn(s.id), s.name, own ? (eq ? 'Выбрано' : 'Куплено') : 'Косметика, не влияет на баланс',
            eq ? 'ВЫБРАНО' : own ? 'Выбрать' : s.price + ' монет', eq || (!own && D.coins < s.price), own ? 'eq' : '',
            function () { self.skin(kind, s.id, s.price); });
        });
      }
      function sheepIcon(id) {
        var P = Assets.sheep(id), c = document.createElement('canvas'); c.width = 60; c.height = 60;
        try { var g = c.getContext('2d'); g.drawImage(P.body.c, 0, 8, 60, 48); g.drawImage(P.head.c, 36, 6, 24, 24); return c.toDataURL(); } catch (e) { return ''; }
      }
      function boardIcon(id) {
        var c = document.createElement('canvas'); c.width = 60; c.height = 60;
        try { var g = c.getContext('2d'); g.drawImage(Assets.board(id, 0).c, 0, 14, 60, 14); g.drawImage(Assets.board(id, 1).c, 0, 32, 60, 14); return c.toDataURL(); } catch (e) { return ''; }
      }
      skinGroup('Скины овец', SHEEP, 'sheep', sheepIcon);
      skinGroup('Скины забора', FENCE, 'fence', boardIcon);
      skinGroup('Эффекты', FX, 'fx', function (id) { return id === 'dust' ? '💨' : id === 'sparkle' ? '✨' : '🍃'; });
    }
  };
  window.Shop = Shop;
})();
