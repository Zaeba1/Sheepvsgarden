/* Мир: константы, сетка грунта (деформируемая), отрисовка земли, столкновения с грунтом. */
(function () {
  'use strict';
  var C = { W: 960, H: 540, GROUND: 324, CS: 6, HILL: 48, STEP: 10 };
  C.Y0 = C.GROUND - C.HILL;                       // верх сетки (место для холмов)
  C.COLS = C.W / C.CS;
  C.ROWS = Math.ceil((C.H - C.Y0) / C.CS);
  C.GROUND_ROW = C.HILL / C.CS;
  C.FENCE_X = 590; C.FENCE_L = 84; C.BOARD_N = 6; C.PITCH = 20;
  C.FENCE_L_X = C.FENCE_X - C.FENCE_L / 2;
  C.FENCE_R_X = C.FENCE_X + C.FENCE_L / 2;
  C.GARDEN_X = C.FENCE_R_X + 18;
  window.C = C;

  var grid = new Uint8Array(C.COLS * C.ROWS);
  var top = new Int16Array(C.COLS);
  var tc = null, tg = null, pattern = null;
  var dirty = null;
  var edits = 0;

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function solidCell(c, r) {
    if (c < 0 || c >= C.COLS) return 1;
    if (r < 0) return 0;
    if (r >= C.ROWS) return 1;
    return grid[r * C.COLS + c];
  }
  function recalcTop(c) {
    var r = 0;
    while (r < C.ROWS && !grid[r * C.COLS + c]) r++;
    top[c] = r;
  }
  function markDirty(c0, r0, c1, r1) {
    if (!dirty) dirty = { c0: c0, r0: r0, c1: c1, r1: r1 };
    else { dirty.c0 = Math.min(dirty.c0, c0); dirty.r0 = Math.min(dirty.r0, r0); dirty.c1 = Math.max(dirty.c1, c1); dirty.r1 = Math.max(dirty.r1, r1); }
  }
  function hash(a, b) { var h = (a * 374761393 + b * 668265263) | 0; h = (h ^ (h >>> 13)) * 1274126177 | 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }

  function drawRegion(c0, r0, c1, r1) {
    c0 = clamp(c0 - 1, 0, C.COLS - 1); c1 = clamp(c1 + 1, 0, C.COLS - 1);
    r0 = clamp(r0 - 1, 0, C.ROWS - 1); r1 = clamp(r1 + 1, 0, C.ROWS - 1);
    var CS = C.CS, x, y, c, r;
    tg.clearRect(c0 * CS, r0 * CS - 6, (c1 - c0 + 1) * CS, (r1 - r0 + 1) * CS + 6);
    for (r = r0; r <= r1; r++) {
      for (c = c0; c <= c1; c++) {
        x = c * CS; y = r * CS;
        if (grid[r * C.COLS + c]) {
          tg.fillStyle = pattern || '#8c5a2c';
          tg.fillRect(x, y, CS, CS);
          var depth = clamp((r - C.GROUND_ROW) / (C.ROWS - C.GROUND_ROW), 0, 1);
          tg.fillStyle = 'rgba(35,16,4,' + (0.04 + depth * 0.42).toFixed(3) + ')';
          tg.fillRect(x, y, CS, CS);
        } else if (r >= C.GROUND_ROW) {
          var v = hash(c, r);
          tg.fillStyle = 'rgb(' + (46 + v * 8 | 0) + ',' + (27 + v * 6 | 0) + ',' + (14 + v * 4 | 0) + ')';
          tg.fillRect(x, y, CS, CS);
        }
      }
    }
    // края, ветки травы
    for (r = r0; r <= r1; r++) {
      for (c = c0; c <= c1; c++) {
        if (!grid[r * C.COLS + c]) continue;
        x = c * CS; y = r * CS;
        var up = solidCell(c, r - 1), dn = solidCell(c, r + 1), lf = solidCell(c - 1, r), rt = solidCell(c + 1, r);
        if (!up) {
          if (r === top[c] && r <= C.GROUND_ROW + 1) {
            tg.fillStyle = '#4c9a30'; tg.fillRect(x, y - 3, CS, 6);
            tg.fillStyle = '#7ccf48'; tg.fillRect(x, y - 3, CS, 3);
            tg.fillStyle = '#a6ec6a'; tg.fillRect(x, y - 3, CS, 1.2);
            var hh = hash(c, 9);
            if (hh > 0.45) {
              tg.fillStyle = hh > 0.75 ? '#8fdc55' : '#5fb23a';
              tg.beginPath(); tg.moveTo(x + 1, y - 3); tg.lineTo(x + 2.4, y - 7 - hh * 3); tg.lineTo(x + 4, y - 3); tg.fill();
            }
            tg.fillStyle = 'rgba(30,60,10,.35)'; tg.fillRect(x, y + 3, CS, 1.5);
          } else {
            tg.fillStyle = 'rgba(255,215,150,.28)'; tg.fillRect(x, y, CS, 1.6);
          }
        }
        if (!dn) { tg.fillStyle = 'rgba(15,6,0,.5)'; tg.fillRect(x, y + CS - 2, CS, 2); }
        if (!lf) { tg.fillStyle = 'rgba(15,6,0,.4)'; tg.fillRect(x, y, 1.6, CS); }
        if (!rt) { tg.fillStyle = 'rgba(15,6,0,.4)'; tg.fillRect(x + CS - 1.6, y, 1.6, CS); }
      }
    }
  }

  var World = {
    canvas: null,
    init: function () {
      var r, c;
      grid.fill(0);
      for (r = C.GROUND_ROW; r < C.ROWS; r++) for (c = 0; c < C.COLS; c++) grid[r * C.COLS + c] = 1;
      for (c = 0; c < C.COLS; c++) recalcTop(c);
      if (!tc) {
        tc = document.createElement('canvas');
        tc.width = C.W * 2; tc.height = (C.H - C.Y0) * 2;
        tg = tc.getContext('2d');
        tg.scale(2, 2);
        var tile = window.Assets.soil();
        try {
          pattern = tg.createPattern(tile.c, 'repeat');
          if (pattern && pattern.setTransform && typeof DOMMatrix !== 'undefined') pattern.setTransform(new DOMMatrix([0.5, 0, 0, 0.5, 0, 0]));
        } catch (e) { pattern = null; }
        World.canvas = tc;
      }
      // небольшая неровность поверхности не нужна: ровное поле удобнее для механик
      drawRegion(0, 0, C.COLS - 1, C.ROWS - 1);
      dirty = null; edits = 0;
    },
    flush: function () {
      if (dirty) { drawRegion(dirty.c0, dirty.r0, dirty.c1, dirty.r1); dirty = null; }
    },
    edits: function () { return edits; },
    isSolid: function (x, y) { return !!solidCell(Math.floor(x / C.CS), Math.floor((y - C.Y0) / C.CS)); },
    surfaceY: function (x) {
      var c = clamp(Math.floor(x / C.CS), 0, C.COLS - 1);
      return C.Y0 + top[c] * C.CS;
    },
    /* Вырезать прямоугольник (клип сверху — чтобы под забором оставалась «крыша»). Возвращает число ячеек. */
    carveRect: function (x0, y0, x1, y1, minY) {
      var CS = C.CS, n = 0;
      if (minY !== undefined && minY !== null) y0 = Math.max(y0, minY);
      var c0 = clamp(Math.floor(x0 / CS), 0, C.COLS - 1), c1 = clamp(Math.floor((x1 - 0.01) / CS), 0, C.COLS - 1);
      var r0 = clamp(Math.floor((y0 - C.Y0) / CS), 0, C.ROWS - 1), r1 = clamp(Math.floor((y1 - 0.01 - C.Y0) / CS), 0, C.ROWS - 1);
      r1 = Math.min(r1, C.ROWS - 3);                  // неразрушимое дно
      if (r1 < r0) return 0;
      for (var r = r0; r <= r1; r++) for (var c = c0; c <= c1; c++) {
        if (grid[r * C.COLS + c]) { grid[r * C.COLS + c] = 0; n++; }
      }
      if (n) { for (c = c0; c <= c1; c++) recalcTop(c); markDirty(c0, r0, c1, r1); edits++; }
      return n;
    },
    carveCircle: function (x, y, rad) {
      var CS = C.CS, n = 0;
      var c0 = clamp(Math.floor((x - rad) / CS), 0, C.COLS - 1), c1 = clamp(Math.floor((x + rad) / CS), 0, C.COLS - 1);
      var r0 = clamp(Math.floor((y - rad - C.Y0) / CS), 0, C.ROWS - 1), r1 = clamp(Math.floor((y + rad - C.Y0) / CS), 0, C.ROWS - 3);
      for (var r = r0; r <= r1; r++) for (var c = c0; c <= c1; c++) {
        var cx = (c + 0.5) * CS, cy = C.Y0 + (r + 0.5) * CS;
        if ((cx - x) * (cx - x) + (cy - y) * (cy - y) <= rad * rad && grid[r * C.COLS + c]) { grid[r * C.COLS + c] = 0; n++; }
      }
      if (n) { for (c = c0; c <= c1; c++) recalcTop(c); markDirty(c0, r0, c1, r1); edits++; }
      return n;
    },
    fillCircle: function (x, y, rad, maxCells) {
      var CS = C.CS, n = 0;
      var c0 = clamp(Math.floor((x - rad) / CS), 1, C.COLS - 2), c1 = clamp(Math.floor((x + rad) / CS), 1, C.COLS - 2);
      var r0 = clamp(Math.floor((y - rad - C.Y0) / CS), 0, C.ROWS - 1), r1 = clamp(Math.floor((y + rad - C.Y0) / CS), 0, C.ROWS - 1);
      // снизу вверх: земля «осыпается» на дно ямы
      for (var r = r1; r >= r0; r--) for (var c = c0; c <= c1; c++) {
        var cx = (c + 0.5) * CS, cy = C.Y0 + (r + 0.5) * CS;
        if (maxCells !== undefined && n >= maxCells) break;
        if ((cx - x) * (cx - x) + (cy - y) * (cy - y) <= rad * rad && !grid[r * C.COLS + c]) { grid[r * C.COLS + c] = 1; n++; }
      }
      if (n) { for (c = c0; c <= c1; c++) recalcTop(c); markDirty(c0, r0, c1, r1); edits++; }
      return n;
    },
    overlaps: function (x, y, hw, hh) {
      var CS = C.CS;
      var c0 = Math.floor((x - hw) / CS), c1 = Math.floor((x + hw - 0.001) / CS);
      var r0 = Math.floor((y - hh - C.Y0) / CS), r1 = Math.floor((y + hh - 0.001 - C.Y0) / CS);
      for (var r = r0; r <= r1; r++) for (var c = c0; c <= c1; c++) if (solidCell(c, r)) return true;
      return false;
    },
    /* Двигает AABB-сущность (x,y — центр; hw,hh — полуразмеры) с учётом грунта. */
    move: function (e, dx, dy) {
      var n, i, s, st, ok;
      e.hitX = 0; e.ground = false;
      n = Math.max(1, Math.ceil(Math.abs(dx) / 3)); s = dx / n;
      for (i = 0; i < n; i++) {
        e.x += s;
        if (World.overlaps(e.x, e.y, e.hw, e.hh)) {
          ok = false;
          if (e.canStep !== false) {
            for (st = 2; st <= C.STEP; st += 2) {
              if (!World.overlaps(e.x, e.y - st, e.hw, e.hh)) { e.y -= st; ok = true; break; }
            }
          }
          if (!ok) { e.x -= s; e.vx = 0; e.hitX = dx > 0 ? 1 : -1; break; }
        }
      }
      n = Math.max(1, Math.ceil(Math.abs(dy) / 3)); s = dy / n;
      for (i = 0; i < n; i++) {
        e.y += s;
        if (World.overlaps(e.x, e.y, e.hw, e.hh)) {
          e.y -= s;
          if (dy > 0) e.ground = true;
          e.vy = 0;
          break;
        }
      }
      // защита от застревания внутри грунта (например, засыпали сверху)
      var guard = 0;
      while (World.overlaps(e.x, e.y, e.hw, e.hh) && guard < 40) { e.y -= 2; guard++; }
    },
    /* Круг (предметы) против ячеек. e.x,e.y,e.r,e.vx,e.vy */
    collideCircle: function (e, bounce, fric) {
      var CS = C.CS, r = e.r, hit = false;
      for (var it = 0; it < 2; it++) {
        var c0 = Math.floor((e.x - r) / CS), c1 = Math.floor((e.x + r) / CS);
        var r0 = Math.floor((e.y - r - C.Y0) / CS), r1 = Math.floor((e.y + r - C.Y0) / CS);
        for (var rr = r0; rr <= r1; rr++) for (var cc = c0; cc <= c1; cc++) {
          if (!solidCell(cc, rr)) continue;
          var x0 = cc * CS, y0 = C.Y0 + rr * CS;
          var px = clamp(e.x, x0, x0 + CS), py = clamp(e.y, y0, y0 + CS);
          var dx = e.x - px, dy = e.y - py, d2 = dx * dx + dy * dy;
          if (d2 < r * r) {
            var d = Math.sqrt(d2), nx, ny;
            if (d < 0.0001) { nx = 0; ny = -1; d = 0; } else { nx = dx / d; ny = dy / d; }
            var pen = r - d;
            e.x += nx * pen; e.y += ny * pen;
            var vn = e.vx * nx + e.vy * ny;
            if (vn < 0) { e.vx -= (1 + bounce) * vn * nx; e.vy -= (1 + bounce) * vn * ny; e.vx *= fric; }
            if (ny < -0.5) { e.ground = true; hit = true; }
          }
        }
      }
      if (e.x < r) { e.x = r; e.vx = Math.abs(e.vx) * 0.3; }
      if (e.x > C.W - r) { e.x = C.W - r; e.vx = -Math.abs(e.vx) * 0.3; }
      return hit;
    }
  };
  World.hash = hash;
  window.World = World;
})();
