/*
 * Графика. Все спрайты рисуются процедурно в оффскрин-канвасы при старте (супер-сэмплинг x2),
 * а игровая логика обращается к ним только через Assets.* — поэтому любой спрайт можно заменить
 * готовым PNG/WEBP, не трогая остальной код: Assets.override('board_oak_0', 'assets/board.png').
 * Если файл не загрузится, остаётся процедурная картинка (ошибка только пишется в консоль).
 */
(function () {
  'use strict';
  var S = 2;
  var cache = {};
  var overrides = {};

  function mk(w, h) {
    var c = document.createElement('canvas');
    c.width = Math.ceil(w * S); c.height = Math.ceil(h * S);
    var g = c.getContext('2d');
    g.scale(S, S);
    return { c: c, g: g, w: w, h: h };
  }
  function rng(seed) {
    var s = (seed >>> 0) || 1;
    return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  }
  function parse(hex) {
    var n = parseInt(hex.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function shade(hex, a) {
    var c = parse(hex), t = a < 0 ? 0 : 255, k = Math.abs(a);
    var r = Math.round(c[0] + (t - c[0]) * k), g = Math.round(c[1] + (t - c[1]) * k), b = Math.round(c[2] + (t - c[2]) * k);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function rr(g, x, y, w, h, r) {
    g.beginPath();
    g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r);
    g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r);
    g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y);
    g.closePath();
  }
  function ell(g, x, y, rx, ry, rot) {
    g.beginPath(); g.ellipse(x, y, rx, ry, rot || 0, 0, Math.PI * 2);
  }
  function vgrad(g, y0, y1, stops) {
    var gr = g.createLinearGradient(0, y0, 0, y1);
    for (var i = 0; i < stops.length; i++) gr.addColorStop(stops[i][0], stops[i][1]);
    return gr;
  }

  /* ---------------- ОВЦЫ ---------------- */
  var SHEEP_SKINS = {
    classic: { wool: '#fbf8f0', face: '#4b4756', muzzle: '#6f6a7c', inner: '#f2a8b8' },
    pink:    { wool: '#ffbfd9', face: '#8e4a68', muzzle: '#b46d8a', inner: '#ffdbe8' },
    black:   { wool: '#615e70', face: '#2b2933', muzzle: '#4c4858', inner: '#9a7088' },
    golden:  { wool: '#ffdf6e', face: '#7d4e1e', muzzle: '#a76f31', inner: '#ffd0a0' }
  };

  function woolCluster(g, cx, cy, rx, ry, col, seed, n) {
    var r = rng(seed), circles = [], i;
    for (i = 0; i < n; i++) {
      var a = i / n * Math.PI * 2;
      circles.push([cx + Math.cos(a) * rx * 0.8, cy + Math.sin(a) * ry * 0.76, ry * 0.46 + r() * 3]);
    }
    for (i = 0; i < Math.round(n * 0.7); i++) {
      circles.push([cx + (r() - 0.5) * rx * 1.2, cy + (r() - 0.5) * ry * 1.0, ry * 0.55]);
    }
    circles.sort(function (a, b) { return b[1] - a[1]; });
    g.fillStyle = shade(col, -0.6);
    circles.forEach(function (c) { g.beginPath(); g.arc(c[0], c[1], c[2] + 1.8, 0, 7); g.fill(); });
    circles.forEach(function (c) {
      var gr = g.createRadialGradient(c[0] - c[2] * 0.35, c[1] - c[2] * 0.45, c[2] * 0.1, c[0], c[1], c[2]);
      gr.addColorStop(0, shade(col, 0.4)); gr.addColorStop(0.55, col); gr.addColorStop(1, shade(col, -0.24));
      g.fillStyle = gr; g.beginPath(); g.arc(c[0], c[1], c[2], 0, 7); g.fill();
    });
  }

  function sheepParts(skin) {
    var key = 'sheep_' + skin;
    if (cache[key]) return cache[key];
    var P = SHEEP_SKINS[skin] || SHEEP_SKINS.classic, parts = {};
    var b = mk(70, 56);
    woolCluster(b.g, 35, 28, 27, 18, P.wool, 11, 14);
    parts.body = b;

    var h = mk(36, 34), g = h.g;
    // голова
    g.fillStyle = shade(P.face, -0.55); ell(g, 15, 19, 14, 14.5); g.fill();
    var gr = g.createRadialGradient(11, 12, 2, 15, 19, 14);
    gr.addColorStop(0, shade(P.face, 0.3)); gr.addColorStop(1, P.face);
    g.fillStyle = gr; ell(g, 15, 19, 12.4, 13); g.fill();
    // морда
    g.fillStyle = shade(P.muzzle, -0.5); ell(g, 25, 23, 9.6, 7.8); g.fill();
    gr = g.createRadialGradient(23, 20, 1, 25, 23, 9);
    gr.addColorStop(0, shade(P.muzzle, 0.3)); gr.addColorStop(1, P.muzzle);
    g.fillStyle = gr; ell(g, 25, 23, 8.4, 6.7); g.fill();
    g.fillStyle = shade(P.face, -0.6); ell(g, 30, 21, 1.6, 1.2); g.fill(); ell(g, 29, 25, 1.2, 1); g.fill();
    g.strokeStyle = shade(P.face, -0.6); g.lineWidth = 1; g.beginPath(); g.moveTo(21, 26.5); g.quadraticCurveTo(26, 28.5, 30, 26.5); g.stroke();
    // щёчка
    g.fillStyle = 'rgba(255,140,160,0.35)'; ell(g, 15, 25, 3.5, 2.2); g.fill();
    // чёлка из шерсти
    woolCluster(g, 14, 6, 9, 5, P.wool, 5, 6);
    parts.head = h;

    var e = mk(18, 12); g = e.g;
    g.fillStyle = shade(P.face, -0.55); ell(g, 9, 6, 8.6, 4.6); g.fill();
    g.fillStyle = P.face; ell(g, 9, 6, 7.4, 3.7); g.fill();
    g.fillStyle = P.inner; ell(g, 9.5, 6, 5, 2); g.fill();
    parts.ear = e;

    var l = mk(11, 20); g = l.g;
    g.fillStyle = shade(P.face, -0.55); rr(g, 0.5, 0, 10, 19, 3.5); g.fill();
    var lg = g.createLinearGradient(0, 0, 11, 0);
    lg.addColorStop(0, shade(P.face, 0.22)); lg.addColorStop(1, shade(P.face, -0.12));
    g.fillStyle = lg; rr(g, 1.6, 0, 7.8, 17.5, 3); g.fill();
    g.fillStyle = '#26232c'; rr(g, 1.1, 13.5, 8.8, 5.6, 2.2); g.fill();
    parts.leg = l;

    var t = mk(20, 20);
    woolCluster(t.g, 10, 10, 6, 6, P.wool, 21, 6);
    parts.tail = t;
    parts.pal = P;
    cache[key] = parts;
    return parts;
  }

  /* ---------------- ИГРОК ---------------- */
  function playerParts() {
    if (cache.player) return cache.player;
    var o = {}, g;
    var hd = mk(30, 32); g = hd.g;
    // лицо
    g.fillStyle = '#6b3e1e'; ell(g, 15, 21, 10.8, 10.8); g.fill();
    var gr = g.createRadialGradient(12, 17, 2, 15, 21, 10);
    gr.addColorStop(0, '#ffe0bd'); gr.addColorStop(1, '#f0b685');
    g.fillStyle = gr; ell(g, 15, 21, 9.6, 9.8); g.fill();
    g.fillStyle = '#e9967a'; ell(g, 23, 22, 2.2, 2); g.fill(); // нос
    g.fillStyle = 'rgba(255,120,120,.35)'; ell(g, 12, 25, 3, 2); g.fill();
    g.strokeStyle = '#7a3b22'; g.lineWidth = 1.2; g.beginPath(); g.arc(18, 25, 3, 0.2, 2.2); g.stroke();
    // соломенная шляпа
    g.fillStyle = '#6a4a14'; ell(g, 15, 13, 14.6, 4.6); g.fill();
    var hg = g.createLinearGradient(0, 8, 0, 18);
    hg.addColorStop(0, '#ffe58a'); hg.addColorStop(1, '#d8a93b');
    g.fillStyle = hg; ell(g, 15, 13, 13.6, 3.7); g.fill();
    g.fillStyle = '#6a4a14'; rr(g, 6.5, 2.8, 17, 10.8, 5); g.fill();
    g.fillStyle = hg; rr(g, 7.5, 3.5, 15, 9.6, 4.6); g.fill();
    g.fillStyle = '#c0392b'; g.fillRect(7.5, 9.2, 15, 2.6);
    g.strokeStyle = 'rgba(120,80,10,.5)'; g.lineWidth = 0.7;
    for (var i = 0; i < 6; i++) { g.beginPath(); g.moveTo(9 + i * 2.4, 4); g.lineTo(9 + i * 2.4, 9); g.stroke(); }
    o.head = hd;

    var ts = mk(26, 24); g = ts.g;
    g.fillStyle = '#2a3f66'; rr(g, 1, 1, 24, 22, 6); g.fill();
    var tg = g.createLinearGradient(0, 0, 26, 0);
    tg.addColorStop(0, '#fffaf0'); tg.addColorStop(1, '#e3d9c3');
    g.fillStyle = tg; rr(g, 2, 2, 22, 20, 5); g.fill();
    g.fillStyle = '#3f67b5'; rr(g, 3, 9, 20, 14, 4); g.fill();   // комбинезон
    g.fillStyle = '#2e4f93'; g.fillRect(6, 2, 3.5, 9); g.fillRect(16.5, 2, 3.5, 9);
    g.fillStyle = '#f2c94c'; ell(g, 7.8, 11, 1.8, 1.8); g.fill(); ell(g, 18.2, 11, 1.8, 1.8); g.fill();
    g.fillStyle = '#2e4f93'; rr(g, 9.5, 14, 7, 5, 1.5); g.fill();
    o.torso = ts;

    var ar = mk(10, 24); g = ar.g;
    g.fillStyle = '#4a3b30'; rr(g, 0.5, 0, 9, 17, 4); g.fill();
    g.fillStyle = '#fffaf0'; rr(g, 1.5, 0.6, 7, 15, 3.4); g.fill();
    g.fillStyle = '#7a3b22'; ell(g, 5, 20, 4.4, 4.2); g.fill();
    g.fillStyle = '#f0b685'; ell(g, 5, 19.8, 3.4, 3.3); g.fill();
    o.arm = ar;

    var lg2 = mk(12, 22); g = lg2.g;
    g.fillStyle = '#1d2e50'; rr(g, 0.5, 0, 11, 16, 3.5); g.fill();
    g.fillStyle = '#3f67b5'; rr(g, 1.5, 0.5, 9, 14.6, 3); g.fill();
    g.fillStyle = '#3b2412'; rr(g, 0, 14, 12, 7.6, 3); g.fill();
    g.fillStyle = '#7a4a22'; rr(g, 0.8, 14.6, 9.6, 5.8, 2.6); g.fill();
    o.leg = lg2;
    cache.player = o;
    return o;
  }

  /* ---------------- ПРЕДМЕТЫ ---------------- */
  function woodHandle(g, x, y, w, h) {
    g.fillStyle = '#3d2410'; rr(g, x - 1, y - 1, w + 2, h + 2, 2.4); g.fill();
    var gr = g.createLinearGradient(x, 0, x + w, 0);
    gr.addColorStop(0, '#d9a362'); gr.addColorStop(0.5, '#b57a3c'); gr.addColorStop(1, '#8a5424');
    g.fillStyle = gr; rr(g, x, y, w, h, 2); g.fill();
  }
  function itemSprite(kind) {
    var key = 'item_' + kind;
    if (cache[key]) return cache[key];
    var s, g, gr;
    if (kind === 'hammer') {
      s = mk(34, 46); g = s.g;
      woodHandle(g, 14, 12, 6, 32);
      g.fillStyle = '#23262e'; rr(g, 3, 2, 28, 14, 3.5); g.fill();
      gr = g.createLinearGradient(0, 3, 0, 15);
      gr.addColorStop(0, '#e9eef5'); gr.addColorStop(0.45, '#aab4c4'); gr.addColorStop(1, '#6a7385');
      g.fillStyle = gr; rr(g, 4.2, 3.2, 25.6, 11.6, 3); g.fill();
      g.fillStyle = 'rgba(255,255,255,.7)'; rr(g, 6, 4.4, 20, 2.4, 1.2); g.fill();
      g.fillStyle = '#c0392b'; rr(g, 12.5, 15, 9, 3, 1); g.fill();
      s.gx = 17; s.gy = 38;
    } else if (kind === 'sledge') {
      s = mk(40, 54); g = s.g;
      woodHandle(g, 17, 16, 7, 38);
      g.fillStyle = '#1d1f26'; rr(g, 2, 1, 36, 21, 4); g.fill();
      gr = g.createLinearGradient(0, 2, 0, 21);
      gr.addColorStop(0, '#d6dce6'); gr.addColorStop(0.5, '#8b95a8'); gr.addColorStop(1, '#4e5568');
      g.fillStyle = gr; rr(g, 3.4, 2.4, 33.2, 18.2, 3.5); g.fill();
      g.fillStyle = '#e8b84a'; g.fillRect(9, 2.4, 3, 18.2); g.fillRect(28, 2.4, 3, 18.2);
      g.fillStyle = 'rgba(255,255,255,.55)'; rr(g, 5, 4, 30, 3, 1.5); g.fill();
      s.gx = 20.5; s.gy = 46;
    } else if (kind === 'shovel') {
      s = mk(30, 56); g = s.g;
      woodHandle(g, 12, 14, 6, 40);
      g.fillStyle = '#6b4a1e'; rr(g, 8, 49, 14, 5, 2); g.fill();
      g.fillStyle = '#23262e';
      g.beginPath(); g.moveTo(15, 0); g.bezierCurveTo(30, 2, 29, 20, 25, 25); g.lineTo(5, 25); g.bezierCurveTo(1, 20, 0, 2, 15, 0); g.fill();
      gr = g.createLinearGradient(3, 0, 27, 0);
      gr.addColorStop(0, '#d7dde8'); gr.addColorStop(0.5, '#9aa5b8'); gr.addColorStop(1, '#657089');
      g.fillStyle = gr;
      g.beginPath(); g.moveTo(15, 1.6); g.bezierCurveTo(27, 3, 26, 19, 23.5, 23.4); g.lineTo(6.5, 23.4); g.bezierCurveTo(4, 19, 3, 3, 15, 1.6); g.fill();
      g.fillStyle = 'rgba(255,255,255,.55)'; rr(g, 8, 4, 3, 14, 1.5); g.fill();
      g.fillStyle = '#8a5424'; rr(g, 11, 22, 8, 4, 1.5); g.fill();
      s.gx = 15; s.gy = 46;
    } else { // stone
      s = mk(26, 22); g = s.g;
      g.fillStyle = '#2b2d33';
      g.beginPath(); g.moveTo(3, 15); g.quadraticCurveTo(1, 7, 8, 3.5); g.quadraticCurveTo(15, 0.5, 21, 4.5); g.quadraticCurveTo(26, 9, 23.5, 16); g.quadraticCurveTo(20, 21.6, 12, 21); g.quadraticCurveTo(5, 20.6, 3, 15); g.fill();
      gr = g.createRadialGradient(9, 7, 1, 13, 12, 13);
      gr.addColorStop(0, '#d9dce3'); gr.addColorStop(0.55, '#9ba0ac'); gr.addColorStop(1, '#5d626f');
      g.fillStyle = gr;
      g.beginPath(); g.moveTo(4.2, 14.8); g.quadraticCurveTo(2.6, 8, 8.6, 4.8); g.quadraticCurveTo(15, 2.2, 20.2, 5.8); g.quadraticCurveTo(24.2, 9.6, 22.2, 15.4); g.quadraticCurveTo(19.4, 19.8, 12, 19.4); g.quadraticCurveTo(6, 19.2, 4.2, 14.8); g.fill();
      g.strokeStyle = 'rgba(40,40,50,.45)'; g.lineWidth = 0.9;
      g.beginPath(); g.moveTo(10, 8); g.lineTo(13, 12); g.lineTo(11, 16); g.stroke();
      g.beginPath(); g.moveTo(17, 7.5); g.lineTo(15.5, 11); g.stroke();
      g.fillStyle = 'rgba(255,255,255,.5)'; ell(g, 10, 7.4, 3.6, 1.6, -0.4); g.fill();
      s.gx = 13; s.gy = 11;
    }
    cache[key] = s;
    return s;
  }

  /* ---------------- ЗАБОР ---------------- */
  var FENCE_SKINS = {
    oak:   { base: '#c98f4f', dark: '#6d3f1c', light: '#e8b878' },
    birch: { base: '#ecd9b0', dark: '#8f7650', light: '#fff4d6' },
    red:   { base: '#c8473b', dark: '#6a1d17', light: '#ee7a6a' },
    blue:  { base: '#4f89c9', dark: '#223f70', light: '#86b6ea' }
  };
  function boardSprite(skin, variant) {
    var key = 'board_' + skin + '_' + variant;
    if (cache[key]) return cache[key];
    var P = FENCE_SKINS[skin] || FENCE_SKINS.oak, s = mk(88, 20), g = s.g, r = rng(100 + variant * 17);
    g.fillStyle = P.dark; rr(g, 0, 0.5, 88, 19, 4); g.fill();
    g.fillStyle = vgrad(g, 1, 19, [[0, P.light], [0.18, P.base], [0.8, P.base], [1, P.dark]]);
    rr(g, 1.4, 1.8, 85.2, 16.6, 3.2); g.fill();
    g.strokeStyle = 'rgba(0,0,0,0.18)'; g.lineWidth = 0.8;
    for (var i = 0; i < 7; i++) {
      var y = 4 + r() * 12;
      g.beginPath(); g.moveTo(5 + r() * 10, y);
      g.bezierCurveTo(28, y + (r() - 0.5) * 3, 56, y + (r() - 0.5) * 3, 70 + r() * 14, y + (r() - 0.5) * 2); g.stroke();
    }
    // сучок
    var kx = 20 + r() * 48;
    g.fillStyle = 'rgba(60,30,10,.35)'; ell(g, kx, 10, 3.6, 2.6); g.fill();
    g.strokeStyle = 'rgba(60,30,10,.45)'; ell(g, kx, 10, 5.4, 3.8); g.stroke();
    g.fillStyle = 'rgba(255,255,255,.28)'; rr(g, 4, 2.6, 80, 2.2, 1.1); g.fill();
    // гвозди
    [7, 81].forEach(function (nx) {
      g.fillStyle = '#2b2b30'; ell(g, nx, 10, 3, 3); g.fill();
      g.fillStyle = '#c6ccd6'; ell(g, nx - 0.3, 9.6, 2, 2); g.fill();
      g.fillStyle = '#fff'; ell(g, nx - 0.9, 8.9, 0.7, 0.7); g.fill();
    });
    cache[key] = s;
    return s;
  }
  function postSprite(skin) {
    var key = 'post_' + skin;
    if (cache[key]) return cache[key];
    var P = FENCE_SKINS[skin] || FENCE_SKINS.oak, s = mk(22, 150), g = s.g;
    g.fillStyle = shade(P.dark, -0.3); rr(g, 1, 6, 20, 144, 3); g.fill();
    var gr = g.createLinearGradient(0, 0, 22, 0);
    gr.addColorStop(0, shade(P.base, -0.05)); gr.addColorStop(0.4, P.light); gr.addColorStop(1, shade(P.base, -0.35));
    g.fillStyle = gr; rr(g, 2.2, 7, 17.6, 142, 2.6); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.2)'; g.lineWidth = 0.8;
    for (var i = 0; i < 9; i++) { g.beginPath(); g.moveTo(6 + i * 1.3, 10); g.lineTo(6 + i * 1.3 + (i % 2 ? 1 : -1), 145); g.stroke(); }
    g.fillStyle = shade(P.dark, -0.2); g.beginPath(); g.moveTo(0, 8); g.lineTo(11, 0); g.lineTo(22, 8); g.closePath(); g.fill();
    g.fillStyle = P.base; g.beginPath(); g.moveTo(2.4, 8); g.lineTo(11, 1.8); g.lineTo(19.6, 8); g.closePath(); g.fill();
    cache[key] = s;
    return s;
  }

  /* ---------------- ОГОРОД ---------------- */
  function cabbageSprite(v) {
    var key = 'cabbage_' + v;
    if (cache[key]) return cache[key];
    var s = mk(54, 50), g = s.g, r = rng(300 + v * 9);
    g.fillStyle = 'rgba(0,0,0,.28)'; ell(g, 27, 44, 22, 5); g.fill();
    var leaves = [['#2f7d2c', 22, 0], ['#3d9535', 19, 0.5], ['#52b043', 16, 1.0], ['#74cf55', 12, 1.5], ['#9be36d', 8, 2.0]];
    leaves.forEach(function (L, i) {
      var n = 6 - Math.floor(i / 2);
      for (var k = 0; k < n; k++) {
        var a = k / n * Math.PI * 2 + i * 0.4 + r() * 0.2;
        var cx = 27 + Math.cos(a) * L[1] * 0.38, cy = 27 + Math.sin(a) * L[1] * 0.3 - i;
        g.save(); g.translate(cx, cy); g.rotate(a);
        g.fillStyle = shade(L[0], -0.5); ell(g, 0, 0, L[1] * 0.62 + 1.5, L[1] * 0.48 + 1.5); g.fill();
        var gr = g.createRadialGradient(-3, -3, 1, 0, 0, L[1] * 0.6);
        gr.addColorStop(0, shade(L[0], 0.35)); gr.addColorStop(1, L[0]);
        g.fillStyle = gr; ell(g, 0, 0, L[1] * 0.62, L[1] * 0.48); g.fill();
        g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 0.9;
        g.beginPath(); g.moveTo(-L[1] * 0.4, 0); g.lineTo(L[1] * 0.5, 0); g.stroke();
        g.restore();
      }
    });
    g.fillStyle = 'rgba(255,255,255,.35)'; ell(g, 23, 21, 5, 3, -0.5); g.fill();
    cache[key] = s;
    return s;
  }
  function gardenPatch() {
    if (cache.garden) return cache.garden;
    var s = mk(330, 26), g = s.g;
    g.fillStyle = '#4a2c14'; rr(g, 0, 8, 330, 18, 6); g.fill();
    g.fillStyle = vgrad(g, 8, 26, [[0, '#7d4d26'], [1, '#4f2f16']]); rr(g, 1.4, 9.4, 327, 15.6, 5); g.fill();
    for (var i = 0; i < 11; i++) {
      g.fillStyle = 'rgba(30,15,5,.35)'; rr(g, 8 + i * 29, 13, 16, 4, 2); g.fill();
      g.fillStyle = 'rgba(255,220,170,.22)'; rr(g, 8 + i * 29, 11, 16, 2, 1); g.fill();
    }
    // мини-заборчик-колышки
    for (i = 0; i < 12; i++) { g.fillStyle = '#8a5a2a'; rr(g, 4 + i * 28.6, 0, 3.4, 12, 1.4); g.fill(); }
    cache.garden = s;
    return s;
  }

  /* ---------------- ФОН ---------------- */
  function backdrop() {
    if (cache.backdrop) return cache.backdrop;
    var W = 960, H = 340, s = mk(W, H), g = s.g, r = rng(7), i;
    g.fillStyle = vgrad(g, 0, H, [[0, '#7cc8f5'], [0.6, '#cdeeff'], [1, '#eaf8ff']]);
    g.fillRect(0, 0, W, H);
    // солнце
    var sg = g.createRadialGradient(150, 70, 4, 150, 70, 130);
    sg.addColorStop(0, 'rgba(255,255,220,1)'); sg.addColorStop(0.18, 'rgba(255,245,170,.95)'); sg.addColorStop(0.2, 'rgba(255,240,150,.4)'); sg.addColorStop(1, 'rgba(255,240,150,0)');
    g.fillStyle = sg; g.fillRect(0, 0, 380, 260);
    // облака
    [[250, 62, 1], [520, 40, 0.8], [760, 78, 1.1], [60, 120, 0.7], [640, 130, 0.6]].forEach(function (c) {
      var x = c[0], y = c[1], k = c[2];
      for (var pass = 0; pass < 2; pass++) {
        g.fillStyle = pass ? '#ffffff' : 'rgba(150,185,215,.5)';
        [[0, 0, 22], [24, -8, 26], [52, 0, 22], [78, 4, 16], [-20, 6, 15]].forEach(function (b) {
          g.beginPath(); g.arc(x + b[0] * k, y + b[1] * k + (pass ? 0 : 4), b[2] * k, 0, 7); g.fill();
        });
      }
    });
    // дальние холмы
    function hill(color, base, amp, f, ph, dark) {
      g.fillStyle = color; g.beginPath(); g.moveTo(0, H);
      for (var x = 0; x <= W; x += 8) g.lineTo(x, base + Math.sin(x * f + ph) * amp + Math.sin(x * f * 2.3 + ph * 1.7) * amp * 0.35);
      g.lineTo(W, H); g.closePath(); g.fill();
    }
    hill('#9fd4b5', 236, 22, 0.006, 1.2);
    hill('#86c47c', 262, 20, 0.0085, 3.4);
    // деревья
    for (i = 0; i < 16; i++) {
      var tx = 30 + i * 60 + r() * 30, ty = 262 + Math.sin(tx * 0.0085 + 3.4) * 20 + 6, sc = 0.7 + r() * 0.6;
      g.fillStyle = '#5a3b1e'; g.fillRect(tx - 2.5 * sc, ty - 14 * sc, 5 * sc, 16 * sc);
      [['#2e7a3c', 0], ['#3f9a4a', -3], ['#58b95a', -6]].forEach(function (cc, k) {
        g.fillStyle = cc[0]; g.beginPath(); g.arc(tx + (k - 1) * 3 * sc, ty - 24 * sc + cc[1] * sc, (15 - k * 2) * sc, 0, 7); g.fill();
      });
    }
    hill('#79bb4f', 292, 8, 0.012, 0.4);
    // сарай на заднем плане
    var bx = 835, by = 270;
    g.fillStyle = 'rgba(0,0,0,.2)'; ell(g, bx + 40, by + 30, 54, 6); g.fill();
    g.fillStyle = '#8f2b22'; g.fillRect(bx, by - 8, 80, 38);
    g.fillStyle = vgrad(g, by - 8, by + 30, [[0, '#c6483a'], [1, '#8f2b22']]); g.fillRect(bx + 1.5, by - 6.5, 77, 35.5);
    g.fillStyle = '#5a1b16'; g.beginPath(); g.moveTo(bx - 8, by - 6); g.lineTo(bx + 40, by - 36); g.lineTo(bx + 88, by - 6); g.closePath(); g.fill();
    g.fillStyle = '#7a2a20'; g.beginPath(); g.moveTo(bx - 4, by - 8); g.lineTo(bx + 40, by - 33); g.lineTo(bx + 84, by - 8); g.closePath(); g.fill();
    g.fillStyle = '#f7ead2'; g.fillRect(bx + 26, by + 4, 28, 26);
    g.strokeStyle = '#8f2b22'; g.lineWidth = 2; g.strokeRect(bx + 26, by + 4, 28, 26);
    g.beginPath(); g.moveTo(bx + 26, by + 4); g.lineTo(bx + 54, by + 30); g.moveTo(bx + 54, by + 4); g.lineTo(bx + 26, by + 30); g.stroke();
    // луг до земли
    g.fillStyle = vgrad(g, 296, H, [[0, '#88cc55'], [1, '#6db243']]); g.fillRect(0, 296, W, H - 296);
    for (i = 0; i < 160; i++) {
      var gx = r() * W, gy = 300 + r() * 38;
      g.strokeStyle = r() > 0.5 ? '#9be063' : '#5da23a'; g.lineWidth = 1.2;
      g.beginPath(); g.moveTo(gx, gy); g.lineTo(gx + (r() - 0.5) * 4, gy - 4 - r() * 5); g.stroke();
    }
    // цветочки
    for (i = 0; i < 22; i++) {
      var fx = r() * W, fy = 306 + r() * 24;
      g.fillStyle = ['#fff', '#ffd54a', '#ff8ab3', '#b99bff'][i % 4];
      for (var k = 0; k < 5; k++) { g.beginPath(); g.arc(fx + Math.cos(k * 1.256) * 2, fy + Math.sin(k * 1.256) * 2, 1.4, 0, 7); g.fill(); }
      g.fillStyle = '#ffb300'; g.beginPath(); g.arc(fx, fy, 1.2, 0, 7); g.fill();
    }
    cache.backdrop = s;
    return s;
  }

  function soilTile() {
    if (cache.soil) return cache.soil;
    var s = mk(96, 96), g = s.g, r = rng(77);
    g.fillStyle = '#8c5a2c'; g.fillRect(0, 0, 96, 96);
    for (var i = 0; i < 420; i++) {
      var x = r() * 96, y = r() * 96, k = r();
      g.fillStyle = k < 0.4 ? 'rgba(60,30,10,.22)' : k < 0.8 ? 'rgba(255,200,140,.16)' : 'rgba(40,20,5,.3)';
      g.beginPath(); g.arc(x, y, 0.7 + r() * 1.9, 0, 7); g.fill();
      // оборачиваем для бесшовности
      if (x < 3) { g.beginPath(); g.arc(x + 96, y, 1.5, 0, 7); g.fill(); }
      if (y < 3) { g.beginPath(); g.arc(x, y + 96, 1.5, 0, 7); g.fill(); }
    }
    for (i = 0; i < 16; i++) {
      var px = r() * 90, py = r() * 90, rad = 2 + r() * 3.2;
      g.fillStyle = 'rgba(40,25,15,.5)'; ell(g, px + 0.7, py + 0.8, rad, rad * 0.8); g.fill();
      g.fillStyle = 'rgba(180,170,160,.7)'; ell(g, px, py, rad, rad * 0.8); g.fill();
      g.fillStyle = 'rgba(255,255,255,.35)'; ell(g, px - 0.8, py - 0.8, rad * 0.5, rad * 0.3); g.fill();
    }
    cache.soil = s;
    return s;
  }

  /* ---------------- ИКОНКИ ---------------- */
  function iconCoin() {
    if (cache.coin) return cache.coin;
    var s = mk(24, 24), g = s.g;
    g.fillStyle = '#8a5a00'; ell(g, 12, 12, 11, 11); g.fill();
    var gr = g.createRadialGradient(9, 8, 1, 12, 12, 11);
    gr.addColorStop(0, '#fff0a0'); gr.addColorStop(0.6, '#ffc61e'); gr.addColorStop(1, '#d99100');
    g.fillStyle = gr; ell(g, 12, 12, 9.6, 9.6); g.fill();
    g.strokeStyle = '#b97a00'; g.lineWidth = 1.4; ell(g, 12, 12, 6.4, 6.4); g.stroke();
    g.fillStyle = '#b97a00'; rr(g, 10.8, 7.6, 2.4, 8.8, 1); g.fill();
    cache.coin = s;
    return s;
  }
  function iconClock() {
    if (cache.clock) return cache.clock;
    var s = mk(24, 24), g = s.g;
    g.fillStyle = '#243a5e'; ell(g, 12, 12, 11, 11); g.fill();
    g.fillStyle = '#fff'; ell(g, 12, 12, 9, 9); g.fill();
    g.strokeStyle = '#243a5e'; g.lineWidth = 1.8; g.lineCap = 'round';
    g.beginPath(); g.moveTo(12, 12); g.lineTo(12, 6); g.moveTo(12, 12); g.lineTo(16.5, 14.5); g.stroke();
    cache.clock = s;
    return s;
  }
  function toURL(s) {
    try { return s.c.toDataURL('image/png'); } catch (e) { return ''; }
  }

  function ov(name) {
    var img = overrides[name];
    if (!img) return null;
    var base = cache[name] || null;
    return { c: img, w: base ? base.w : img.width, h: base ? base.h : img.height, gx: base ? base.gx : img.width / 2, gy: base ? base.gy : img.height / 2 };
  }

  /* ---------------- ПУБЛИЧНЫЙ API ---------------- */
  var Assets = {
    SHEEP_SKINS: SHEEP_SKINS,
    FENCE_SKINS: FENCE_SKINS,
    ready: false,
    errors: [],
    sheep: sheepParts,
    player: playerParts,
    item: function (k) { return ov('item_' + k) || itemSprite(k); },
    board: function (s, v) { return ov('board_' + s + '_' + v) || boardSprite(s, v); },
    post: function (s) { return ov('post_' + s) || postSprite(s); },
    cabbage: function (v) { return ov('cabbage_' + v) || cabbageSprite(v); },
    garden: gardenPatch,
    backdrop: function () { return ov('backdrop') || backdrop(); },
    soil: soilTile,
    coin: iconCoin,
    clock: iconClock,
    dataURL: toURL,
    itemIcon: function (kind) { return toURL(itemSprite(kind)); },
    /* Подмена любого спрайта внешним изображением (необязательно). */
    override: function (name, url) {
      var img = new Image();
      img.onload = function () { overrides[name] = img; };
      img.onerror = function () { Assets.errors.push(url); console.warn('Не загрузился ассет', url, '— используется процедурная графика'); };
      img.src = url;
    },
    drawSprite: function (g, spr, x, y, w, h) {
      g.drawImage(spr.c, x, y, w === undefined ? spr.w : w, h === undefined ? spr.h : h);
    },
    init: function () {
      try {
        backdrop(); soilTile(); gardenPatch(); playerParts();
        ['hammer', 'shovel', 'stone', 'sledge'].forEach(itemSprite);
        for (var k in SHEEP_SKINS) sheepParts(k);
        for (var f in FENCE_SKINS) { postSprite(f); for (var v = 0; v < 3; v++) boardSprite(f, v); }
        for (var c = 0; c < 4; c++) cabbageSprite(c);
        iconCoin(); iconClock();
        Assets.ready = true;
      } catch (e) {
        console.error('Ошибка генерации графики', e);
        Assets.errors.push(String(e));
      }
    }
  };
  window.Assets = Assets;
})();
