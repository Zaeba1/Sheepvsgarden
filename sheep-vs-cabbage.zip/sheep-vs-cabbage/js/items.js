/* Предметы: определения инструментов, прочность, физика лежащих предметов, подбор/бросок/кража. */
(function () {
  'use strict';
  var DEF = {
    hammer: { name: 'Молоток', dur: 60, dmg: 20, cd: 0.45, reach: 52, kb: 270, r: 9, respawn: 14 },
    shovel: { name: 'Лопата', dur: 90, dmg: 8, cd: 0.42, reach: 46, kb: 130, r: 9, respawn: 14 },
    stone:  { name: 'Камень', dur: 8, dmg: 12, cd: 0.5, reach: 40, kb: 190, r: 11, respawn: 10 },
    sledge: { name: 'Кувалда', dur: 45, dmg: 38, cd: 0.95, reach: 60, kb: 500, r: 11, respawn: 20 }
  };
  var Items = { list: [], DEF: DEF, nextId: 1, onBreak: null };

  Items.level = function (kind) { return (Save.data.upgrades[kind] | 0); };
  Items.maxDur = function (kind) { return Math.round(DEF[kind].dur * (1 + 0.25 * Items.level(kind))); };
  Items.dmg = function (kind) { return DEF[kind].dmg * (1 + 0.2 * Items.level(kind)); };
  Items.stoneCount = function () { return 3 + Items.level('stone'); };

  Items.create = function (kind, state, x, y) {
    var it = { id: Items.nextId++, kind: kind, state: state || 'bag', x: x || 0, y: y || 0, vx: 0, vy: 0, r: DEF[kind].r,
      ang: 0, dur: Items.maxDur(kind), maxDur: Items.maxDur(kind), timer: 0, noPick: 0, thrown: 0, hitSet: null, sheep: null, ground: false };
    Items.list.push(it);
    return it;
  };

  Items.setup = function () {
    Items.list = [];
    var h = Items.create('hammer', 'bag');
    Items.create('shovel', 'bag');
    for (var i = 0; i < Items.stoneCount(); i++) Items.create('stone', 'bag');
    if (Save.data.tools.sledge) Items.create('sledge', 'bag');
    return h;
  };

  /* после покупки улучшений */
  Items.refresh = function () {
    Items.list.forEach(function (it) {
      var m = Items.maxDur(it.kind), f = it.dur / it.maxDur;
      it.maxDur = m; it.dur = Math.min(m, Math.max(it.dur, f * m));
    });
    var stones = Items.list.filter(function (i) { return i.kind === 'stone'; }).length;
    while (stones < Items.stoneCount()) { Items.create('stone', 'bag'); stones++; }
    if (Save.data.tools.sledge && !Items.list.some(function (i) { return i.kind === 'sledge'; })) Items.create('sledge', 'bag');
  };

  Items.ofKind = function (kind, states) {
    return Items.list.filter(function (i) { return i.kind === kind && states.indexOf(i.state) >= 0; });
  };

  /* Предмет сломался */
  Items.wear = function (it, n) {
    it.dur -= n;
    if (it.dur <= 0) {
      it.dur = 0;
      var s = it.sheep, wasHeld = it.state === 'held';
      var x = it.x, y = it.y;
      if (s) { s.item = null; x = s.x; y = s.y; }
      it.state = 'gone'; it.timer = DEF[it.kind].respawn; it.sheep = null;
      if (wasHeld && window.Player) window.Player.held = null;
      if (Items.onBreak) Items.onBreak(it, x, y);
      return true;
    }
    return false;
  };

  Items.toGround = function (it, x, y, vx, vy, noPick) {
    if (it.sheep) { it.sheep.item = null; it.sheep = null; }
    it.state = 'ground'; it.x = x; it.y = y; it.vx = vx || 0; it.vy = vy || 0; it.noPick = noPick || 0.5;
    it.ground = false;
  };

  Items.throwItem = function (it, x, y, vx, vy) {
    Items.toGround(it, x, y, vx, vy, 0.6);
    it.thrown = 1.0; it.hitSet = {};
  };

  Items.blockingStone = function (x, y, hw, hh) {
    for (var i = 0; i < Items.list.length; i++) {
      var it = Items.list[i];
      if (it.state !== 'ground' || it.kind !== 'stone') continue;
      if (Math.abs(it.x - x) < hw + it.r && Math.abs(it.y - y) < hh + it.r) return it;
    }
    return null;
  };

  /* Камни — твёрдые препятствия для овец. */
  Items.collideBox = function (e, strength) {
    for (var i = 0; i < Items.list.length; i++) {
      var it = Items.list[i];
      if (it.state !== 'ground' || it.kind !== 'stone') continue;
      var px = Math.max(e.x - e.hw, Math.min(it.x, e.x + e.hw)), py = Math.max(e.y - e.hh, Math.min(it.y, e.y + e.hh));
      var dx = it.x - px, dy = it.y - py, d2 = dx * dx + dy * dy;
      if (d2 >= it.r * it.r) continue;
      var d = Math.sqrt(d2);
      if (d < 0.001) { dx = it.x > e.x ? 1 : -1; dy = 0; d = 1; }
      var nx = dx / d, ny = dy / d, pen = it.r - d;
      if (Math.abs(nx) > Math.abs(ny)) {
        e.x -= nx * pen * 0.85; it.x += nx * pen * 0.15;
        if (strength > 0.5) it.vx += nx * (20 + strength * 50); // сильные овцы сдвигают камень
        else if (e.vx * nx > 0) e.vx = 0;
        e.hitX = nx > 0 ? 1 : -1;
      } else if (ny < 0) {
        // овца под камнем (редко) — выталкиваем камень вверх
        it.y += ny * pen;
      } else {
        e.y -= ny * pen; e.ground = true; if (e.vy > 0) e.vy = 0;
      }
    }
  };

  Items.update = function (dt, game) {
    for (var i = 0; i < Items.list.length; i++) {
      var it = Items.list[i];
      if (it.state === 'gone') {
        it.timer -= dt;
        if (it.timer <= 0) { it.state = 'bag'; it.dur = it.maxDur; if (Items.onRespawn) Items.onRespawn(it); }
        continue;
      }
      if (it.state !== 'ground') continue;
      if (it.noPick > 0) it.noPick -= dt;
      if (it.thrown > 0) it.thrown -= dt;
      it.vy = Math.min(900, it.vy + 1500 * dt);
      it.x += it.vx * dt; it.y += it.vy * dt;
      it.ground = false;
      World.collideCircle(it, 0.28, 0.9);
      if (it.ground) it.vx *= Math.pow(0.012, dt) * (it.kind === 'stone' ? 1 : 0.9) + 0.0;
      if (Math.abs(it.vx) < 3) it.vx = 0;
      it.ang += it.vx * dt / it.r * (it.kind === 'stone' ? 1 : 0.15);
      if (it.y > C.H + 30) { it.x = 300; it.y = C.GROUND - 30; it.vx = it.vy = 0; }
      if (it.x < 6) { it.x = 6; }
      // брошенный предмет бьёт овец
      if (it.thrown > 0 && game && Math.hypot(it.vx, it.vy) > 170) {
        for (var k = 0; k < game.sheep.length; k++) {
          var s = game.sheep[k];
          if (s.dead || (it.hitSet && it.hitSet[s.id])) continue;
          if (Math.abs(s.x - it.x) < s.hw + it.r && Math.abs(s.y - it.y) < s.hh + it.r) {
            it.hitSet[s.id] = true;
            var dir = it.vx >= 0 ? 1 : -1;
            s.hurt(Items.dmg(it.kind) * (it.kind === 'stone' ? 1.2 : 0.6), dir, DEF[it.kind].kb, 'thrown');
            it.vx *= 0.3;
            Items.wear(it, 1);
            break;
          }
        }
      }
    }
  };

  /* Рисует спрайт предмета, хват которого (gx,gy) помещён в точку (x,y). */
  Items.drawSprite = function (g, kind, x, y, rot, sc) {
    var s = Assets.item(kind);
    g.save(); g.translate(x, y); g.rotate(rot || 0); sc = sc || 1;
    g.drawImage(s.c, -s.gx * sc, -s.gy * sc, s.w * sc, s.h * sc);
    g.restore();
  };

  Items.drawGround = function (g, t) {
    for (var i = 0; i < Items.list.length; i++) {
      var it = Items.list[i];
      if (it.state !== 'ground') continue;
      var sp = Assets.item(it.kind);
      g.save();
      g.fillStyle = 'rgba(0,0,0,.25)';
      g.beginPath(); g.ellipse(it.x, it.y + it.r - 1, it.r + 4, 3, 0, 0, 7); g.fill();
      g.translate(it.x, it.y);
      if (it.kind === 'stone') {
        g.rotate(it.ang);
        g.drawImage(sp.c, -sp.w / 2, -sp.h / 2 - 1, sp.w, sp.h);
      } else {
        g.rotate(1.5 + it.ang * 0.3);
        g.drawImage(sp.c, -sp.gx + 0, -sp.h / 2, sp.w, sp.h);
      }
      g.restore();
      if (it.kind !== 'stone' || it.noPick <= 0) {
        // мерцающая метка, чтобы потерянный предмет было легко найти
        var by = it.y - 22 + Math.sin(t * 5 + it.id) * 3;
        g.fillStyle = 'rgba(255,255,255,.85)';
        g.beginPath(); g.moveTo(it.x - 4, by - 5); g.lineTo(it.x + 4, by - 5); g.lineTo(it.x, by + 1); g.closePath(); g.fill();
      }
    }
  };

  window.Items = Items;
})();
