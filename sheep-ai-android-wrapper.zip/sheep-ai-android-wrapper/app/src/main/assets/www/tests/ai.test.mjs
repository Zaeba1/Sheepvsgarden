// Тесты ядра ИИ и физики — запуск: node tests/ai.test.mjs
import { makeRng, SpatialHash, v2, turnToward } from '../src/utils/math.js';
import { SheepBrain, makePersonality, State } from '../src/ai/brain.js';
import { herdForces, propagatePanic } from '../src/ai/herd.js';
import { PhysicsWorld } from '../src/physics/world2d.js';

let passed = 0, failed = 0;
const ok = (c, n) => c ? passed++ : (failed++, console.error('FAIL:', n));

{ // math
  const rng = makeRng(1), a = rng();
  ok(makeRng(1)() === a, 'rng детерминирован');
  ok(turnToward(0, Math.PI, 0.1) <= 0.1 + 1e-9, 'turnToward ограничивает шаг');
  const h = new SpatialHash(2); let found = 0;
  for (let i = 0; i < 50; i++) h.insert({ i }, (i % 7) * 1.3, (i % 5) * 1.1);
  h.query(0, 0, 3, () => found++);
  ok(found > 0, 'spatial hash находит соседей');
}
{ // личность влияет на испуг
  const bb = new SheepBrain(makeRng(21), { half: 20 });
  const bB = new SheepBrain(makeRng(22), { half: 20 });
  bb.pers = makePersonality(makeRng(11)); bb.pers.boldness = 0.05;
  bB.pers = makePersonality(makeRng(13)); bB.pers.boldness = 0.95;
  bb.scare(0, 0, 1); bB.scare(0, 0, 1);
  ok(bb.fear > bB.fear, 'пугливая боится сильнее смелой');
  const dir = v2.make();
  bb.desiredDir(dir, { x: 5, z: 0 });
  ok(dir.x > 0.9, 'бегство от источника');
  let tT = 0, tB = 0; const s = 1 / 60;
  while (bb.state === State.FLEE && tT < 60) { bb.think(s); tT += s; }
  while (bB.state === State.FLEE && tB < 60) { bB.think(s); tB += s; }
  ok(tB < tT, 'смелая успокаивается быстрее');
}
{ // FSM
  const b = new SheepBrain(makeRng(31), { half: 20 });
  const saw = new Set([b.state]);
  for (let i = 0; i < 3000; i++) { b.think(1 / 30); saw.add(b.state); }
  ok(saw.has(State.WANDER) || saw.has(State.GRAZE), 'выход из IDLE в активность');
  const b2 = new SheepBrain(makeRng(33), { half: 20 });
  b2.setLure({ x: 10, z: 10, active: true });
  let went = false;
  for (let i = 0; i < 600 && !went; i++) {
    b2.bodyX = b2.bodyX ?? 0; b2.bodyZ = b2.bodyZ ?? 0; b2.think(1 / 30);
    if (b2.state === State.GO_TO) went = true;
  }
  ok(went, 'приманка вызывает GO_TO');
}
{ // антизастревание
  const b = new SheepBrain(makeRng(37), { half: 20 });
  b.bodyX = 0; b.bodyZ = 0;
  b._pickWanderTarget(); b._enter(State.WANDER);
  b.target.x = 100; b.target.z = 100; // недостижимо
  for (let i = 0; i < 200; i++) b.think(1 / 30);
  ok(b.blockedTime < 3.1 && b.hasTarget, 'антизастревание');
}
{ // стадные силы
  const rng = makeRng(41);
  const mk = (x, z) => ({ pos: { x, z }, vel: { x: 0, z: 0 }, brain: new SheepBrain(rng, { half: 20 }) });
  const out = v2.make();
  herdForces(mk(0, 0), [mk(0, 0), mk(0.5, 0), mk(-0.5, 0.2)], out);
  ok(out.x !== 0 || out.z !== 0, 'separation от близких соседей');
  // Один сосед на 2 м (вне comfortDist — separation=0), движется в +x.
  // Сравниваем стадную составляющую: herding=1 + FLEE против herding=0 в стороне.
  const n = mk(2.0, 0); n.vel.x = 1;
  const hA = mk(0, 0); hA.brain.pers.herding = 1; hA.brain.state = State.FLEE;
  const hB = mk(0, 8); hB.brain.pers.herding = 0; // изолирован
  const calm = mk(1.5, 0); // вне comfortDist, но в радиусе распространения паники
  const all = [hA, hB, n, calm];
  const o1 = v2.make(), o2 = v2.make();
  herdForces(hA, all, o1); herdForces(hB, all, o2);
  ok(o1.x > 1.0 && v2.len(o2) < 0.01, 'стадность и паника дают alignment+cohesion');
  hA.brain.fear = 1;
  propagatePanic(hA, all);
  ok(calm.brain.state === State.FLEE, 'испуг распространяется');
}
{ // физика
  const w = new PhysicsWorld();
  const a = w.addBody({ x: 0, z: 0, radius: 0.5, mass: 1 });
  const b = w.addBody({ x: 0.8, z: 0, radius: 0.5, mass: 1 });
  for (let i = 0; i < 60; i++) w.step(1 / 60);
  ok(v2.dist(a, b) >= 0.99, 'тела не проникают друг в друга');
  w.addSegment(5, -1, 5, 1, 0.3);
  const m = w.addBody({ x: 4.5, z: 0, radius: 0.4, mass: 1 }); m.vx = 3;
  for (let i = 0; i < 90; i++) w.step(1 / 60);
  ok(m.x < 5.4, 'сегмент-стена останавливает');
  const far = w.addBody({ x: -10, z: -10, radius: 0.5, mass: 1 });
  const hit = w.raycast(8, 8, -10, -10, 40, (b) => b === far);
  ok(hit && hit.body === far, 'raycast находит цель через фильтр');
}
console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
