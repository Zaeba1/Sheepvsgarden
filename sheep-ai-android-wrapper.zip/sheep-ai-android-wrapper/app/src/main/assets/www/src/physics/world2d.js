// Физический мир: круглые тела (овцы, объекты) + статические коллайдеры.
// Собственный лёгкий движок на плоскости x/z — стабильно и дёшево для мобильных.
import { CFG } from '../config.js';
import { SpatialHash, v2, clamp } from '../utils/math.js';

export class PhysicsWorld {
  constructor() {
    this.bodies = [];       // {id,x,z,vx,vz,radius,mass,static,tag,ref}
    this.statics = [];      // сегменты {ax,az,bx,bz,r} — заборы, камни
    this.grid = new SpatialHash(CFG.physics.cell);
    this.half = CFG.world.half - 0.8;
  }
  addBody(b) {
    b.id = this.bodies.length; b.vx = 0; b.vz = 0;
    b.mass = b.mass || 1; b.static = !!b.static;
    this.bodies.push(b); return b;
  }
  removeBody(b) { b.dead = true; }
  addSegment(ax, az, bx, bz, r = 0.25) { this.statics.push({ ax, az, bx, bz, r }); }

  rebuild() {
    this.grid.clear();
    for (const b of this.bodies) if (!b.dead) this.grid.insert(b, b.x, b.z);
  }

  // Отталкивание динамических тел друг от друга (soft push).
  _solvePairs() {
    const push = CFG.physics.push;
    this.grid.map.forEach((arr) => {
      for (let i = 0; i < arr.length; i++) {
        const a = arr[i]; if (a.static || a.dead) continue;
        for (let j = i + 1; j < arr.length; j++) {
          const b = arr[j]; if (b.dead) continue;
          let dx = b.x - a.x, dz = b.z - a.z;
          const minD = a.radius + b.radius;
          const d2 = dx * dx + dz * dz;
          if (d2 >= minD * minD || d2 === 0) continue;
          const d = Math.sqrt(d2), nx = dx / d, nz = dz / d;
          const overlap = minD - d;
          const wa = b.static ? 1 : a.mass / (a.mass + b.mass);
          const wb = b.static ? 0 : b.mass / (a.mass + b.mass);
          a.x -= nx * overlap * wa; a.z -= nz * overlap * wa;
          if (!b.static) { b.x += nx * overlap * wb; b.z += nz * overlap * wb; }
          // импульс
          const rel = (b.vx - a.vx) * nx + (b.vz - a.vz) * nz;
          if (rel < 0) {
            const imp = -rel * 0.5 * push * 0.016;
            a.vx -= nx * imp * wa; a.vz -= nz * imp * wa;
            if (!b.static) { b.vx += nx * imp * wb; b.vz += nz * imp * wb; }
          }
        }
      }
    });
  }

  // Столкновения со статикой (сегменты) и границами поля.
  _solveStatics(b) {
    for (const s of this.statics) {
      const abx = s.bx - s.ax, abz = s.bz - s.az;
      const apx = b.x - s.ax, apz = b.z - s.az;
      const len2 = abx * abx + abz * abz || 1;
      let t = (apx * abx + apz * abz) / len2; t = clamp(t, 0, 1);
      const cx = s.ax + abx * t, cz = s.az + abz * t;
      let dx = b.x - cx, dz = b.z - cz;
      const minD = s.r + b.radius;
      const d2 = dx * dx + dz * dz;
      if (d2 < minD * minD && d2 > 0) {
        const d = Math.sqrt(d2), nx = dx / d, nz = dz / d;
        b.x = cx + nx * minD; b.z = cz + nz * minD;
        const vn = b.vx * nx + b.vz * nz;
        if (vn < 0) { b.vx -= vn * nx * 1.4; b.vz -= vn * nz * 1.4; }
      }
    }
    // жёсткие границы пастбища
    const m = this.half - b.radius;
    if (b.x < -m) { b.x = -m; b.vx = Math.abs(b.vx) * 0.4; }
    if (b.x > m) { b.x = m; b.vx = -Math.abs(b.vx) * 0.4; }
    if (b.z < -m) { b.z = -m; b.vz = Math.abs(b.vz) * 0.4; }
    if (b.z > m) { b.z = m; b.vz = -Math.abs(b.vz) * 0.4; }
  }

  step(dt) {
    this.rebuild();
    this._solvePairs();
    const damp = Math.pow(CFG.physics.damping, dt * 60);
    for (const b of this.bodies) {
      if (b.dead || b.static) continue;
      b.x += b.vx * dt; b.z += b.vz * dt;
      this._solveStatics(b);
      b.vx *= damp; b.vz *= damp;
    }
  }

  // Raycast по кругам тел: возвращает ближайшее тело на луче (ox,oz)->(dx,dz).
  raycast(ox, oz, dx, dz, maxDist, filter) {
    let best = null, bestT = maxDist;
    const rx = dx - ox, rz = dz - oz;
    const rl = Math.hypot(rx, rz) || 1;
    const nx = rx / rl, nz = rz / rl;
    for (const b of this.bodies) {
      if (b.dead || (filter && !filter(b))) continue;
      const px = b.x - ox, pz = b.z - oz;
      const t = px * nx + pz * nz;
      if (t < 0 || t > bestT) continue;
      const cx = ox + nx * t, cz = oz + nz * t;
      const d2 = (b.x - cx) ** 2 + (b.z - cz) ** 2;
      if (d2 <= b.radius * b.radius) { best = b; bestT = t; }
    }
    return best ? { body: best, dist: bestT } : null;
  }
}
