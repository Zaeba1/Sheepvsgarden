// Мозг овцы: чистый JS (без three.js) — конечный автомат + индивидуальность.
// Состояния: IDLE, WANDER, GRAZE, GO_TO (точка/еда), FLEE, REST, BOOPED.
import { v2, clamp, rand, turnToward } from '../utils/math.js';

export const State = Object.freeze({
  IDLE: 'idle', WANDER: 'wander', GRAZE: 'graze',
  GO_TO: 'go_to', FLEE: 'flee', REST: 'rest', BOOPED: 'booped',
});

// Индивидуальность реально влияет на решения: смелость — порог испуга и
// скорость бегства; стадность — вес стадных сил; любопытство — охота идти к приманке.
export function makePersonality(rng) {
  return {
    boldness: rand(rng, 0.15, 0.95),     // 0 — пугливая, 1 — смелая
    herding: rand(rng, 0.3, 1.0),        // тяга к стаду
    curiosity: rand(rng, 0.1, 0.9),      // реакция на приманку/новизну
    reactDelay: rand(rng, 0.05, 0.5),    // сек до реакции на испуг
    grazeLove: rand(rng, 0.3, 1.0),      // склонность к выпасу
    speedMul: rand(rng, 0.85, 1.15),
  };
}

export class SheepBrain {
  constructor(rng, bounds) {
    this.rng = rng;
    this.bounds = bounds;             // {half} границы поля
    this.state = State.IDLE;
    this.stateTime = 0;
    this.target = v2.make();          // текущая цель движения
    this.hasTarget = false;
    this.pers = makePersonality(rng);
    this.fear = 0;                    // 0..1 накопленный страх
    this.panicTimer = 0;              // остаток времени бегства
    this.reactTimer = 0;              // задержка реакции (индивидуальная)
    this.grazeSpot = null;            // {x,z} куст травы
    this.lure = null;                 // активная приманка {x,z,age}
    this.desiredSpeed = 0;
    this.blockedTime = 0;             // контроль застревания
    this.lastProgress = null;
  }

  setLure(l) { this.lure = l; }
  setGrazeSpot(s) { this.grazeSpot = s; }

  scare(fromX, fromZ, power = 1) {
    // Смелые овцы пугаются слабее и реже.
    const eff = power * (1.15 - this.pers.boldness);
    this.fear = clamp(this.fear + eff, 0, 1.6);
    this.reactTimer = this.pers.reactDelay;
    // направление бегства — от источника
    this.fleeFrom = { x: fromX, z: fromZ };
    if (this.state !== State.FLEE) this._enter(State.FLEE);
  }

  boop() {
    this.fear = Math.max(0, this.fear - 0.4); // погладили — страх спадает
    this._enter(State.BOOPED);
  }

  _enter(s) {
    this.state = s; this.stateTime = 0;
    if (s === State.IDLE) this.desiredSpeed = 0;
  }

  _pickWanderTarget() {
    const r = this.rng, half = this.bounds.half - 2.5;
    this.target.x = rand(r, -half, half);
    this.target.z = rand(r, -half, half);
    this.hasTarget = true;
  }

  _pickGrazeSpot() {
    if (this.grazeSpot) {
      this.target.x = this.grazeSpot.x + rand(this.rng, -0.8, 0.8);
      this.target.z = this.grazeSpot.z + rand(this.rng, -0.8, 0.8);
    } else this._pickWanderTarget();
    this.hasTarget = true;
  }

  // dt может быть кратным (мы думаем дискретно, двигаемся каждый кадр).
  think(dt) {
    this.stateTime += dt;
    this.fear = Math.max(0, this.fear - dt * 0.25);

    switch (this.state) {
      case State.IDLE: {
        const t = rand(this.rng, 1, 3.2) * (1.4 - this.pers.grazeLove * 0.6);
        if (this.stateTime > t) {
          // Приоритет: приманка -> трава -> бродёжка.
          if (this.lure && this.rng() < this.pers.curiosity * 0.9) {
            this.target.x = this.lure.x; this.target.z = this.lure.z;
            this.hasTarget = true; this._enter(State.GO_TO);
          } else if (this.grazeSpot && this.rng() < this.pers.grazeLove) {
            this._pickGrazeSpot(); this._enter(State.GO_TO);
          } else if (this.rng() < 0.55) {
            this._pickWanderTarget(); this._enter(State.WANDER);
          } else this._enter(State.GRAZE);
        }
        break;
      }
      case State.WANDER:
      case State.GO_TO: {
        if (this.state === State.GO_TO && this.lure &&
            v2.dist2(this.target, this.lure) < 0.01 && !this.lure.active) {
          // приманку отпустили/истекла — теряет интерес
          this.lure = null; this._enter(State.IDLE); break;
        }
        const d = v2.dist({ x: this.bodyX, z: this.bodyZ }, this.target);
        const arrive = this.state === State.GO_TO ? 0.7 : 0.5;
        if (d < arrive) {
          this.hasTarget = false;
          if (this.state === State.GO_TO && this.grazeSpot &&
              v2.dist2(this.target, this.grazeSpot) < 4) this._enter(State.GRAZE);
          else this._enter(this.rng() < 0.4 ? State.REST : State.IDLE);
        } else {
          // защита от застревания: нет прогресса 3 сек — новая цель
          if (!this.lastProgress || v2.dist2(this.lastProgress, this.target) > 0.25) {
            this.lastProgress = { x: this.bodyX, z: this.bodyZ };
            this.blockedTime = 0;
          } else {
            this.blockedTime += dt;
            if (this.blockedTime > 3) {
              this.blockedTime = 0; this.lastProgress = null;
              this._pickWanderTarget();
            }
          }
        }
        break;
      }
      case State.GRAZE: {
        const t = rand(this.rng, 2.5, 6) * (0.6 + this.pers.grazeLove);
        if (this.stateTime > t) this._enter(State.IDLE);
        break;
      }
      case State.REST:
        if (this.stateTime > rand(this.rng, 2, 5)) this._enter(State.IDLE);
        break;
      case State.BOOPED:
        if (this.stateTime > 0.9) this._enter(State.IDLE);
        break;
      case State.FLEE: {
        if (this.reactTimer > 0) { this.reactTimer -= dt; break; }
        this.panicTimer -= dt;
        if (this.panicTimer <= 0 && this.fear < 0.35) {
          this.panicTimer = 0; this._enter(State.IDLE);
        }
        break;
      }
    }
    // целевая скорость по состоянию
    if (this.state === State.FLEE) this.desiredSpeed = 3.6 * this.pers.speedMul;
    else if (this.state === State.WANDER || this.state === State.GO_TO)
      this.desiredSpeed = 1.35 * this.pers.speedMul;
    else this.desiredSpeed = 0;
  }

  // Направление желаемого движения (без стадных сил — их добавляет herd.js).
  desiredDir(out, pos) {
    out.x = 0; out.z = 0;
    if (this.state === State.FLEE && this.fleeFrom) {
      out.x = pos.x - this.fleeFrom.x; out.z = pos.z - this.fleeFrom.z;
      // бегство вглубь поля, а не в угол
      const half = this.bounds.half - 3;
      if (Math.abs(pos.x + out.x) > half) out.x *= 0.3;
      if (Math.abs(pos.z + out.z) > half) out.z *= 0.3;
      return v2.norm(out, out);
    }
    if ((this.state === State.WANDER || this.state === State.GO_TO) && this.hasTarget) {
      out.x = this.target.x - pos.x; out.z = this.target.z - pos.z;
      const d = v2.len(out);
      if (d > 0.05) return v2.norm(out, out);
    }
    return out;
  }
}
