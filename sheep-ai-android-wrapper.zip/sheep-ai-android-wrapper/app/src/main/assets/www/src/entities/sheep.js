// Сущность овцы: физическое тело + мозг + модель + анимация.
import * as THREE from 'three';
import { CFG } from '../config.js';
import { v2, clamp, turnToward } from '../utils/math.js';
import { SheepBrain } from '../ai/brain.js';
import { SheepAnimator } from './animation.js';

const dir = v2.make(), herd = v2.make(), acc = v2.make();

export class Sheep {
  constructor(rng, scene, phys, mats, grassSpots) {
    const half = CFG.world.half - 4;
    this.body = phys.addBody({
      x: (rng() * 2 - 1) * half, z: (rng() * 2 - 1) * half,
      radius: CFG.sheep.radius, mass: 1, tag: 'sheep', ref: this,
    });
    this.brain = new SheepBrain(rng, { half: CFG.world.half });
    this.brain.bodyX = this.body.x; this.brain.bodyZ = this.body.z;
    if (grassSpots.length) this.brain.setGrazeSpot(grassSpots[(rng() * grassSpots.length) | 0]);
    this.thinkAcc = rng() / CFG.sheep.thinkHz; // рассинхрон мыслей

    // визуал
    const built = globalThis.__buildSheepMesh(rng, mats);
    this.mesh = built.group; this.parts = built.parts;
    this.anim = new SheepAnimator(this.parts);
    this.yaw = rng() * Math.PI * 2;
    this.mesh.rotation.y = this.yaw;
    this.mesh.position.set(this.body.x, 0, this.body.z);
    scene.add(this.mesh);

    this.pos = this.body; // алиас для herd.js
    this.vel = this.body;
    this.speed = 0;
  }

  // Одно касание: погладить. Ближе к морде — сильнее радость.
  boop(x, z) {
    this.brain.boop();
    this.anim.triggerBoop();
  }

  update(dt, allSheep, herdFn) {
    // ИИ думает дискретно (thinkHz), движение — каждый кадр.
    this.thinkAcc += dt;
    const step = 1 / CFG.sheep.thinkHz;
    while (this.thinkAcc >= step) {
      this.thinkAcc -= step;
      this.brain.bodyX = this.body.x; this.brain.bodyZ = this.body.z;
      this.brain.think(step);
    }

    // направление: собственное + стадные силы
    this.brain.desiredDir(dir, this.body);
    herdFn(this, allSheep, herd);
    acc.x = dir.x * 2.6 + herd.x;
    acc.z = dir.z * 2.6 + herd.z;

    // ускорение к желаемой скорости
    const want = this.brain.desiredSpeed;
    this.body.vx += acc.x * dt; this.body.vz += acc.z * dt;
    const sp = Math.hypot(this.body.vx, this.body.vz);
    const max = Math.max(want, 0.001);
    if (sp > max) { this.body.vx *= max / sp; this.body.vz *= max / sp; }
    this.speed = Math.min(sp, max);

    // срабатывание визуальных реакций при переходе в FLEE
    if (this.brain.state === 'flee' && this._wasFlee !== true) {
      this.anim.triggerStartle();
      this._wasFlee = true;
    } else if (this.brain.state !== 'flee') this._wasFlee = false;

    // поворот к скорости
    if (sp > 0.1) {
      const targetYaw = Math.atan2(this.body.vx, this.body.vz);
      this.yaw = turnToward(this.yaw, targetYaw, dt * (this.brain.state === 'flee' ? 10 : 5.5));
    }
    this.mesh.rotation.y = this.yaw;
    this.mesh.position.set(this.body.x, 0, this.body.z);

    this.anim.update(dt, this.brain, this.speed);
  }
}
