// Стадное поведение (separation/alignment/cohesion), восприятие и
// распространение испуга. Чистый JS — тестируется без рендерера.
import { v2, clamp } from '../utils/math.js';
import { CFG } from '../config.js';
import { State } from './brain.js';

const tmp = v2.make(), sep = v2.make(), ali = v2.make(), coh = v2.make();

// Собирает силы стада для одной овцы. Веса зависят от индивидуальности.
export function herdForces(sheep, all, out) {
  const P = CFG.sheep;
  sep.x = 0; sep.z = 0; ali.x = 0; ali.z = 0; coh.x = 0; coh.z = 0;
  let n = 0, close = 0;
  const pos = sheep.pos;
  for (const o of all) {
    if (o === sheep) continue;
    const d2 = v2.dist2(pos, o.pos);
    if (d2 > P.neighborRadius * P.neighborRadius) continue;
    const d = Math.sqrt(d2) || 0.001;
    n++;
    // separation: сильнее при сближении комфортной дистанции
    if (d < P.comfortDist) {
      const w = (P.comfortDist - d) / P.comfortDist;
      sep.x += (pos.x - o.pos.x) / d * w;
      sep.z += (pos.z - o.pos.z) / d * w;
      close++;
    }
    ali.x += o.vel.x; ali.z += o.vel.z;
    coh.x += o.pos.x; coh.z += o.pos.z;
  }
  out.x = 0; out.z = 0;
  if (n === 0) return out;
  const h = sheep.brain.pers.herding;
  // separation — всегда важна
  if (close > 0) { out.x += sep.x * 2.2; out.z += sep.z * 2.2; }
  // alignment & cohesion — по стадности личности; испуганные овцы держатся стаи сильнее
  const panicBoost = sheep.brain.state === State.FLEE ? 1.5 : 1;
  v2.scale(ali, ali, 1 / n);
  out.x += ali.x * 0.8 * h * panicBoost;
  out.z += ali.z * 0.8 * h * panicBoost;
  coh.x = coh.x / n - pos.x; coh.z = coh.z / n - pos.z;
  const cd = v2.len(coh);
  if (cd > 0.01) {
    const w = clamp(cd / P.neighborRadius, 0, 1) * 0.9 * h * panicBoost;
    out.x += coh.x / cd * w; out.z += coh.z / cd * w;
  }
  return out;
}

// Распространение испуга: одна испуганная овца пугает соседей.
export function propagatePanic(sheep, all) {
  if (sheep.brain.state !== State.FLEE) return;
  const R = CFG.sheep.panicPropagation;
  for (const o of all) {
    if (o === sheep || o.brain.state === State.FLEE) continue;
    const d2 = v2.dist2(sheep.pos, o.pos);
    if (d2 < R * R) {
      // чем ближе, тем сильнее; смелые сопротивляются
      const p = (1 - Math.sqrt(d2) / R) * sheep.brain.fear;
      if (p > 0.25) o.brain.scare(sheep.pos.x, sheep.pos.z, p * 0.8);
    }
  }
}

// Реакция на резкое событие рядом (тап по земле/вспышка).
export function startleNear(all, x, z, radius, power = 1) {
  for (const o of all) {
    const d2 = v2.dist2({ x, z }, o.pos);
    if (d2 < radius * radius) {
      const p = power * (1 - Math.sqrt(d2) / radius);
      if (p > 0.15) o.brain.scare(x, z, p);
    }
  }
}
