// Игровой цикл: фиксированный шаг симуляции + рендер каждый кадр.
// Пауза при потере фокуса/сворачивании — симуляция не «уезжает».
export class GameLoop {
  constructor(update, render) {
    this.update = update; this.render = render;
    this.paused = false;
    this.acc = 0; this.last = 0;
    this.fixed = 1 / 60;
    this.fps = 60; this._fpsAcc = 0; this._fpsN = 0;
    this._tick = this._tick.bind(this);
  }
  start() {
    this.last = performance.now();
    requestAnimationFrame(this._tick);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.last = 0; // сброс дельты после возврата
    });
  }
  _tick(now) {
    requestAnimationFrame(this._tick);
    if (!this.last) { this.last = now; return; }
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.25) dt = 0.25; // защита от скачков после сворачивания
    // fps meter
    this._fpsAcc += dt; this._fpsN++;
    if (this._fpsAcc >= 0.5) { this.fps = Math.round(this._fpsN / this._fpsAcc); this._fpsAcc = 0; this._fpsN = 0; }

    if (!this.paused) {
      this.acc += dt;
      let steps = 0;
      while (this.acc >= this.fixed && steps < 5) {
        this.update(this.fixed);
        this.acc -= this.fixed; steps++;
      }
      if (steps === 5) this.acc = 0; // не накапливать
    }
    this.render(dt);
  }
}
