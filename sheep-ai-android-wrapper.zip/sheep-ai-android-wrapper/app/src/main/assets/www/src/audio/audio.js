// Процедурный звук WebAudio: блеяние, щелчки, скрип ворот, эмбиент.
// Никаких внешних файлов. Запускается после первого жеста (политика iOS).
export class AudioSystem {
  constructor() {
    this.ctx = null; this.master = null; this.muted = false;
    this.ambient = null;
  }
  _ensure() {
    if (this.ctx) return true;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      this._startAmbient();
      return true;
    } catch { return false; }
  }
  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.5;
  }
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }

  // Короткий «бле»: модулированная пила с огибающей.
  bleat(pitch = 1, happy = false) {
    if (!this._ensure() || this.muted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    const base = (happy ? 500 : 380) * pitch;
    osc.frequency.setValueAtTime(base, t);
    osc.frequency.linearRampToValueAtTime(base * (happy ? 1.5 : 0.7), t + 0.18);
    osc.frequency.linearRampToValueAtTime(base * 0.9, t + 0.4);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.22, t + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
    // вибрато
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    lfo.frequency.value = 7; lfoGain.gain.value = 25;
    lfo.connect(lfoGain); lfoGain.connect(osc.frequency);
    osc.connect(gain); gain.connect(this.master);
    osc.start(t); lfo.start(t);
    osc.stop(t + 0.5); lfo.stop(t + 0.5);
  }

  _noise(dur, freq, vol, type = 'lowpass') {
    if (!this._ensure() || this.muted) return;
    const t = this.ctx.currentTime;
    const len = (dur * this.ctx.sampleRate) | 0;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = type; f.frequency.value = freq;
    const g = this.ctx.createGain(); g.gain.value = vol;
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t);
  }

  tick() { this._noise(0.05, 3000, 0.12, 'highpass'); }
  thump() { this._noise(0.15, 300, 0.3); }
  creak() { this._noise(0.5, 800, 0.15, 'bandpass'); }
  chime() {
    if (!this._ensure() || this.muted) return;
    const t = this.ctx.currentTime;
    [880, 1320].forEach((f, i) => {
      const o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + i * 0.08);
      g.gain.exponentialRampToValueAtTime(0.12, t + i * 0.08 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.08 + 0.4);
      o.connect(g); g.connect(this.master);
      o.start(t + i * 0.08); o.stop(t + i * 0.08 + 0.45);
    });
  }

  _startAmbient() {
    // тихий «ветер»: зацикленный шум через низкие частоты
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    let v = 0;
    for (let i = 0; i < len; i++) { v = v * 0.98 + (Math.random() * 2 - 1) * 0.02; d[i] = v * 8; }
    const src = this.ctx.createBufferSource();
    src.buffer = buf; src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = 420;
    const g = this.ctx.createGain(); g.gain.value = 0.06;
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start();
    this.ambient = src;
  }
}
