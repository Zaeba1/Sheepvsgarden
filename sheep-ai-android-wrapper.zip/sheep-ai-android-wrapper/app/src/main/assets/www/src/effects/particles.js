// Пул частиц (hearts, puff, ring) — без аллокаций в горячем цикле.
import * as THREE from 'three';

const MAX = 160;

export class Particles {
  constructor(scene) {
    this.scene = scene;
    const geo = new THREE.SphereGeometry(0.09, 6, 5);
    this.mat = new THREE.MeshBasicMaterial({ vertexColors: false, transparent: true });
    this.mesh = new THREE.InstancedMesh(geo, this.mat, MAX);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.count = 0;
    scene.add(this.mesh);
    this.pool = [];
    for (let i = 0; i < MAX; i++) this.pool.push({ alive: false });
    this.dummy = new THREE.Object3D();
    this.color = new THREE.Color();
    this.used = 0;
  }

  _spawn(x, y, z, vx, vy, vz, life, color, scale = 1) {
    for (const p of this.pool) {
      if (!p.alive) {
        p.alive = true; p.x = x; p.y = y; p.z = z;
        p.vx = vx; p.vy = vy; p.vz = vz;
        p.life = life; p.maxLife = life; p.color = color; p.scale = scale;
        return;
      }
    }
  }

  hearts(x, z) {
    for (let i = 0; i < 5; i++) {
      const a = Math.random() * Math.PI * 2;
      this._spawn(x, 1.1, z, Math.cos(a) * 0.5, 1.4 + Math.random(),
        Math.sin(a) * 0.5, 1.1, 0xff7fa5, 1.2);
    }
  }
  puff(x, z, color = 0xffffff) {
    for (let i = 0; i < 6; i++) {
      const a = Math.random() * Math.PI * 2;
      this._spawn(x, 0.4, z, Math.cos(a) * 1.2, 0.8 + Math.random() * 0.6,
        Math.sin(a) * 1.2, 0.6, color, 1.4);
    }
  }
  ring(x, z, color = 0xfff2b0, scale = 1) {
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2;
      this._spawn(x + Math.cos(a) * 0.3, 0.15, z + Math.sin(a) * 0.3,
        Math.cos(a) * 2.4 * scale, 0.4, Math.sin(a) * 2.4 * scale, 0.5, color, 0.9);
    }
  }

  update(dt) {
    let n = 0;
    for (const p of this.pool) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) { p.alive = false; continue; }
      p.vy -= dt * 1.6;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      if (p.y < 0.06) { p.y = 0.06; p.vy *= -0.3; }
      const t = p.life / p.maxLife;
      this.dummy.position.set(p.x, p.y, p.z);
      this.dummy.scale.setScalar(p.scale * (0.4 + t * 0.6));
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(n, this.dummy.matrix);
      this.color.setHex(p.color).multiplyScalar(0.5 + t * 0.5);
      this.mesh.setColorAt(n, this.color);
      n++;
    }
    this.mesh.count = n;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
}
