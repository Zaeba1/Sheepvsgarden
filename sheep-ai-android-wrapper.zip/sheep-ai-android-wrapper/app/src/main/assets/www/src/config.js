// Единый источник игровых констант.
export const CFG = {
  world: {
    size: 46,            // сторона квадратного пастбища (м)
    half: 23,
    segments: 64,
  },
  camera: {
    fov: 42,
    pitch: -0.98,        // радиан (изометрия ~56°)
    yaw: 0.7854,         // 45°
    minDist: 10, maxDist: 30, startDist: 19,
    panMargin: 6,
    followLerp: 3.2,
  },
  sheep: {
    count: 10,
    radius: 0.42,
    walkSpeed: 1.35,
    runSpeed: 3.6,
    grazeTime: [2.5, 6.0],
    idleTime: [1.0, 3.5],
    thinkHz: 6,          // частота принятия решений ИИ
    fleeRadius: 3.2,     // испуг от резкого касания рядом
    fleeTime: 2.2,
    comfortDist: 1.35,   // комфортная дистанция в стаде
    neighborRadius: 4.5,
    panicPropagation: 7.0,
  },
  input: {
    tapMaxMs: 260,
    tapMaxDistPx: 12,
    holdMs: 320,         // удержание -> приманка
    lureRadius: 2.4,     // радиус точки сбора
    lureLife: 12,        // сек жизни приманки
  },
  physics: {
    cell: 2.5,           // spatial hash
    push: 14,            // сила расталкивания
    damping: 0.86,
  },
  grass: { count: 2600, patchCount: 26 },
  colors: {
    sky: 0x87b5d6, fog: 0xa8cbe4,
    grassA: 0x6fae4e, grassB: 0x87c35c, groundLow: 0x5d9c46, groundHigh: 0x8bbf63,
    wool: 0xf4efe4, woolShade: 0xe4ddcb, face: 0x4a4038, leg: 0x3c332c,
    fence: 0x8a6b46, fenceDark: 0x6f5538, tree: 0x4e8a3f, trunk: 0x7a5a3c,
    hay: 0xd9b64a, rock: 0x9a9a92, water: 0x5fa8c9,
  },
};
