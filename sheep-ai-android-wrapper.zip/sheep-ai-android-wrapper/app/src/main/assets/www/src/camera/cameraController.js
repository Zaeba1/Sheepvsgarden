// Изометрическая камера: плавное следование за точкой интереса,
// pinch-zoom и двухпальцевый/краевой пан (с ограничением границ поля).
import * as THREE from 'three';
import { CFG } from '../config.js';
import { clamp, lerp } from '../utils/math.js';

export class CameraController {
  constructor(camera, dom) {
    this.camera = camera;
    this.dom = dom;
    this.target = new THREE.Vector3(0, 0, 0);   // куда смотрим
    this.focus = new THREE.Vector3(0, 0, 0);    // точка интереса (приманка и т.п.)
    this.followWeight = 0;
    this.dist = CFG.camera.startDist;
    this.pointers = new Map();
    this.pinchDist = 0;
    this._bind();
  }

  setFocus(v, weight = 1) { this.focus.copy(v); this.followWeight = weight; }

  _bind() {
    this.dom.addEventListener('pointerdown', (e) => {
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        this.pinchDist = Math.hypot(a.x - b.x, a.y - b.y);
      }
    });
    this.dom.addEventListener('pointermove', (e) => {
      const p = this.pointers.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      if (this.pointers.size === 1 && dx * dx + dy * dy > 0) {
        // пан одним пальцем от края экрана (20% с каждой стороны)
        const w = this.dom.clientWidth, h = this.dom.clientHeight;
        const edge = 0.2;
        const nx = e.clientX / w, ny = e.clientY / h;
        if (nx < edge || nx > 1 - edge || ny < edge || ny > 1 - edge) {
          this._panBy(dx, dy);
          this.followWeight = 0;
        }
      } else if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (this.pinchDist > 0) {
          this.dist = clamp(this.dist * (this.pinchDist / d),
            CFG.camera.minDist, CFG.camera.maxDist);
        }
        this.pinchDist = d;
      }
    });
    const clear = (e) => { this.pointers.delete(e.pointerId); this.pinchDist = 0; };
    this.dom.addEventListener('pointerup', clear);
    this.dom.addEventListener('pointercancel', clear);
  }

  _panBy(dx, dy) {
    const s = this.dist * 0.0016;
    // пан в плоскости земли с учётом yaw камеры
    const yaw = CFG.camera.yaw;
    const cos = Math.cos(yaw), sin = Math.sin(yaw);
    this.target.x -= (dx * cos - dy * sin) * s;
    this.target.z -= (dx * sin + dy * cos) * s;
    const lim = CFG.world.half + CFG.camera.panMargin;
    this.target.x = clamp(this.target.x, -lim, lim);
    this.target.z = clamp(this.target.z, -lim, lim);
  }

  update(dt) {
    if (this.followWeight > 0.001) {
      const t = 1 - Math.exp(-CFG.camera.followLerp * dt);
      this.target.lerp(this.focus, t * this.followWeight);
    }
    const { pitch, yaw } = CFG.camera;
    const cx = this.target.x + Math.sin(yaw) * Math.cos(pitch) * -this.dist;
    const cz = this.target.z + Math.cos(yaw) * Math.cos(pitch) * -this.dist;
    const cy = this.target.y - Math.sin(pitch) * this.dist;
    this.camera.position.set(cx, cy, cz);
    this.camera.lookAt(this.target);
  }
}
