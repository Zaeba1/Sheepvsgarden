// Процедурная анимация: ходьба/бег (ноги, покачивание), выпас (наклон головы),
// покой (дыхание), испуг (подпрыг), поглаживание (прыжок радости).
// Никаких случайных анимаций — всё привязано к состоянию мозга.
import { clamp, lerp } from '../utils/math.js';
import { State } from '../ai/brain.js';

export class SheepAnimator {
  constructor(parts) {
    this.p = parts;
    this.phase = Math.random() * 10;
    this.boopY = 0;         // вертикальный прыжок при boop
    this.startleY = 0;      // вздрагивание при испуге
  }

  triggerBoop() { this.boopY = 1; }
  triggerStartle() { this.startleY = 1; }

  update(dt, brain, speed) {
    const p = this.p;
    this.phase += dt * (2.2 + speed * 3.4);
    const moving = speed > 0.15;
    const run = speed > 2.2;

    // ноги — диагональные пары
    const amp = moving ? (run ? 0.75 : 0.45) : 0;
    const s = Math.sin(this.phase * 2.2);
    p.legs[0].rotation.x = s * amp;
    p.legs[3].rotation.x = s * amp;
    p.legs[1].rotation.x = -s * amp;
    p.legs[2].rotation.x = -s * amp;

    // корпус: покачивание при ходьбе, дыхание в покое
    if (moving) {
      p.body.position.y = Math.abs(Math.sin(this.phase * 2.2)) * (run ? 0.06 : 0.03);
      p.body.rotation.z = Math.sin(this.phase * 2.2) * (run ? 0.05 : 0.02);
    } else {
      const breathe = Math.sin(this.phase * 0.7) * 0.015;
      p.body.scale.setScalar(1 + breathe);
      p.body.position.y = 0; p.body.rotation.z = 0;
    }

    // голова по состоянию
    const h = p.head;
    h.rotation.x = lerp(h.rotation.x, this._headTarget(brain, moving, run), dt * 6);
    h.rotation.z = Math.sin(this.phase * 0.5) * 0.05; // лёгкий огляд

    // прыжки
    if (this.boopY > 0) this.boopY = Math.max(0, this.boopY - dt * 2.4);
    if (this.startleY > 0) this.startleY = Math.max(0, this.startleY - dt * 3.2);
    const jump =
      Math.sin(this.boopY * Math.PI) * 0.45 +
      Math.sin(this.startleY * Math.PI) * 0.18;
    p.body.position.y += jump;
    h.position.y = 0.72 + jump * 0.7;
    // хвостик виляет при беге и boop
    p.tail.rotation.x = Math.sin(this.phase * (run ? 9 : 4)) * (moving || this.boopY > 0 ? 0.5 : 0.12);
  }

  _headTarget(brain, moving, run) {
    switch (brain.state) {
      case State.GRAZE: return 1.15;                    // голова вниз к траве
      case State.IDLE: return Math.sin(this.phase * 0.23) > 0.4 ? 0.35 : 0.05;
      case State.REST: return 0.25;
      case State.BOOPED: return -0.25;                  // морда вверх — «улыбка»
      case State.FLEE: return run ? -0.1 : 0;
      default: return moving ? 0.12 : 0.05;
    }
  }
}
