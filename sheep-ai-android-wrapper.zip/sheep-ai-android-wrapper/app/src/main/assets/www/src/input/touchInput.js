// Сенсорный ввод одним пальцем: raycast в плоскость земли + различение
// tap / hold / drag. Объекты определяются через PhysicsWorld.raycast.
import * as THREE from 'three';
import { CFG } from '../config.js';

export class TouchInput {
  constructor(dom, camera, phys, terrain) {
    this.dom = dom; this.camera = camera; this.phys = phys;
    this.raycaster = new THREE.Raycaster();
    this.ndc = new THREE.Vector2();
    this.groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    this.active = null; // {id,startX,startY,curX,curY,t0,moved,type,groundStart}
    this.handlers = { tap: [], hold: [], dragStart: [], dragMove: [], dragEnd: [] };
    this._bind();
  }
  on(ev, fn) { this.handlers[ev].push(fn); return this; }
  _emit(ev, data) { for (const fn of this.handlers[ev]) fn(data); }

  _groundPoint(clientX, clientY, out) {
    const r = this.dom.getBoundingClientRect();
    this.ndc.set(((clientX - r.left) / r.width) * 2 - 1,
                 -((clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(this.ndc, this.camera);
    const hit = this.raycaster.ray.intersectPlane(this.groundPlane, out);
    return !!hit;
  }
  _rayBody(clientX, clientY) {
    const r = this.dom.getBoundingClientRect();
    this.ndc.set(((clientX - r.left) / r.width) * 2 - 1,
                 -((clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(this.ndc, this.camera);
    const o = this.raycaster.ray.origin, d = this.raycaster.ray.direction;
    // проецируем на землю и ищем тела вдоль луча (2D raycast)
    return this.phys.raycast(o.x, o.z, o.x + d.x * 80, o.z + d.z * 80, 80,
      (b) => b.tag !== 'water');
  }

  _bind() {
    const opt = { passive: false };
    this.dom.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (this.active) return; // один палец
      const gp = new THREE.Vector3();
      this._groundPoint(e.clientX, e.clientY, gp);
      this.active = {
        id: e.pointerId, startX: e.clientX, startY: e.clientY,
        curX: e.clientX, curY: e.clientY, t0: performance.now(),
        moved: false, type: null, groundStart: gp,
        body: this._rayBody(e.clientX, e.clientY),
      };
      // сразу проверяем draggable под пальцем
      if (this.active.body && this.active.body.draggable) {
        this.active.type = 'drag';
        this._emit('dragStart', { body: this.active.body, ground: gp });
      }
    }, opt);

    this.dom.addEventListener('pointermove', (e) => {
      if (!this.active || e.pointerId !== this.active.id) return;
      e.preventDefault();
      const a = this.active;
      a.curX = e.clientX; a.curY = e.clientY;
      const dx = a.curX - a.startX, dy = a.curY - a.startY;
      if (!a.moved && Math.hypot(dx, dy) > CFG.input.tapMaxDistPx) {
        a.moved = true;
        if (!a.type) {
          a.type = 'drag';
          this._emit('dragStart', { body: a.body ? a.body.ref : null, ground: a.groundStart, fromGround: true });
        }
      }
      if (a.type === 'drag') {
        const gp = new THREE.Vector3();
        this._groundPoint(e.clientX, e.clientY, gp);
        this._emit('dragMove', { ground: gp });
      }
    }, opt);

    const up = (e) => {
      if (!this.active || e.pointerId !== this.active.id) return;
      const a = this.active; this.active = null;
      const dt = performance.now() - a.t0;
      if (a.type === 'drag') {
        this._emit('dragEnd', { ground: a.groundStart });
        return;
      }
      const gp = new THREE.Vector3();
      this._groundPoint(e.clientX, e.clientY, gp);
      const isHold = dt >= CFG.input.holdMs;
      if (isHold) this._emit('hold', { ground: gp, body: a.body ? a.body.ref : null });
      else this._emit('tap', { ground: gp, body: a.body ? a.body.ref : null, ms: dt });
    };
    this.dom.addEventListener('pointerup', up, opt);
    this.dom.addEventListener('pointercancel', up, opt);
  }
}
