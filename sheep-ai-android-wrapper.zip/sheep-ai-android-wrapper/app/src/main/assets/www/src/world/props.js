// Окружение: забор по периметру, деревья, камни, пруд, сенные копны,
// ворота загона. Физические сегменты регистрируются в PhysicsWorld.
// Возвращает интерактивные объекты (draggables, gate).
import * as THREE from 'three';
import { CFG } from '../config.js';
import { makeRng, rand } from '../utils/math.js';

function buildFenceRun(mats, x0, z0, x1, z1, phys) {
  const group = new THREE.Group();
  const dx = x1 - x0, dz = z1 - z0;
  const len = Math.hypot(dx, dz);
  const n = Math.max(1, Math.round(len / 2.1));
  const postGeo = new THREE.CylinderGeometry(0.09, 0.11, 1.1, 6);
  const railGeo = new THREE.BoxGeometry(1, 0.09, 0.05);
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const post = new THREE.Mesh(postGeo, mats.fenceDark);
    post.position.set(x0 + dx * t, 0.55, z0 + dz * t);
    post.castShadow = true;
    group.add(post);
  }
  for (const h of [0.45, 0.85]) {
    const rail = new THREE.Mesh(railGeo, mats.fence);
    rail.scale.x = len;
    rail.position.set((x0 + x1) / 2, h, (z0 + z1) / 2);
    rail.rotation.y = Math.atan2(dz, dx) === 0 ? 0 : -Math.atan2(dz, dx);
    rail.rotation.y = -Math.atan2(dz, dx);
    rail.castShadow = true;
    group.add(rail);
  }
  phys.addSegment(x0, z0, x1, z1, 0.28);
  return group;
}

export function buildProps(scene, phys, heightAt) {
  const rng = makeRng(99);
  const C = CFG.colors;
  const mats = {
    fence: new THREE.MeshStandardMaterial({ color: C.fence, roughness: 0.9, flatShading: true }),
    fenceDark: new THREE.MeshStandardMaterial({ color: C.fenceDark, roughness: 0.9, flatShading: true }),
    trunk: new THREE.MeshStandardMaterial({ color: C.trunk, roughness: 1, flatShading: true }),
    leaf: new THREE.MeshStandardMaterial({ color: C.tree, roughness: 1, flatShading: true }),
    rock: new THREE.MeshStandardMaterial({ color: C.rock, roughness: 1, flatShading: true }),
    hay: new THREE.MeshStandardMaterial({ color: C.hay, roughness: 0.95, flatShading: true }),
    water: new THREE.MeshStandardMaterial({ color: C.water, roughness: 0.25, metalness: 0.1 }),
  };

  // --- забор по периметру с разрывом-воротами на юге ---
  const H = CFG.world.half;
  const gateW = 3.2;
  const g = new THREE.Group();
  g.add(buildFenceRun(mats, -H, -H, H, -H, phys));            // север
  g.add(buildFenceRun(mats, -H, -H, -H, H, phys));            // запад
  g.add(buildFenceRun(mats, H, -H, H, H, phys));              // восток
  g.add(buildFenceRun(mats, -H, H, -gateW / 2, H, phys));     // юг, левая часть
  g.add(buildFenceRun(mats, gateW / 2, H, H, H, phys));       // юг, правая часть
  scene.add(g);

  // --- ворота: перетаскиваемая створка (drag влево/вправо) ---
  const gate = new THREE.Mesh(new THREE.BoxGeometry(gateW - 0.2, 0.9, 0.08),
    mats.fence);
  gate.castShadow = true;
  gate.position.set(0, 0.5, H);
  scene.add(gate);
  // ворота физически закрыты до открытия; при открытии >60% сегмент убирается
  const gateSeg = { ax: -gateW / 2 + 0.1, az: H, bx: gateW / 2 - 0.1, bz: H, r: 0.3, gate: true };
  phys.statics.push(gateSeg);
  const gateObj = {
    kind: 'gate', mesh: gate, open: 0, seg: gateSeg, baseX: 0, z: H,
    setOpen(t) { // t 0..1
      this.open = t;
      gate.position.x = this.baseX + t * (gateW - 0.4);
      gate.rotation.y = -t * 1.9;
      this.seg.r = t > 0.6 ? -1 : 0.3; // r<0 = отключён
    },
  };
  gateObj.setOpen(0);

  // --- деревья (кольцо за забором + пара внутри, у края) ---
  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.34, 1.8, 7);
  const crownGeo = new THREE.IcosahedronGeometry(1.5, 1);
  const crownGeo2 = new THREE.IcosahedronGeometry(1.0, 1);
  const treeAt = (x, z, s = 1) => {
    const t = new THREE.Group();
    const trunk = new THREE.Mesh(trunkGeo, mats.trunk);
    trunk.position.y = 0.9; trunk.castShadow = true;
    const c1 = new THREE.Mesh(crownGeo, mats.leaf);
    c1.position.y = 2.4; c1.castShadow = true;
    const c2 = new THREE.Mesh(crownGeo2, mats.leaf);
    c2.position.set(0.5, 3.1, 0.3); c2.castShadow = true;
    t.add(trunk, c1, c2);
    t.scale.setScalar(s);
    t.position.set(x, heightAt(x, z), z);
    t.rotation.y = rng() * Math.PI;
    scene.add(t);
    if (Math.abs(x) < H - 1 && Math.abs(z) < H - 1) phys.addBody({ x, z, radius: 0.55 * s, static: true, tag: 'tree' });
  };
  const treeRing = 11;
  for (let i = 0; i < treeRing; i++) {
    const a = (i / treeRing) * Math.PI * 2 + rand(rng, -0.15, 0.15);
    const r = H + rand(rng, 3.5, 7);
    treeAt(Math.cos(a) * r, Math.sin(a) * r, rand(rng, 0.9, 1.5));
  }
  treeAt(-H + 3.4, -H + 4.2, 1.2);
  treeAt(H - 4.0, -H + 5.0, 1.0);

  // --- камни ---
  const rockGeo = new THREE.IcosahedronGeometry(0.5, 0);
  for (let i = 0; i < 7; i++) {
    const x = rand(rng, -H + 3, H - 3), z = rand(rng, -H + 3, H - 3);
    if (Math.hypot(x, z) < 6) continue; // центр свободен
    const rock = new THREE.Mesh(rockGeo, mats.rock);
    const s = rand(rng, 0.5, 1.3);
    rock.scale.set(s, s * 0.7, s);
    rock.position.set(x, heightAt(x, z) + 0.15 * s, z);
    rock.rotation.set(rng() * 3, rng() * 3, rng() * 3);
    rock.castShadow = true;
    scene.add(rock);
    phys.addBody({ x, z, radius: 0.5 * s, static: true, tag: 'rock' });
  }

  // --- пруд (зона избегания; овцы не любят воду) ---
  const pond = new THREE.Mesh(new THREE.CircleGeometry(3.2, 24), mats.water);
  pond.rotation.x = -Math.PI / 2;
  const pondPos = { x: -H + 7, z: H - 7.5 };
  pond.position.set(pondPos.x, heightAt(pondPos.x, pondPos.z) + 0.04, pondPos.z);
  scene.add(pond);
  phys.addBody({ x: pondPos.x, z: pondPos.z, radius: 3.3, static: true, tag: 'water' });

  // --- сенные копны: перетаскиваемые физические объекты ---
  const hayGeo = new THREE.CylinderGeometry(0.65, 0.65, 0.9, 10);
  const draggables = [];
  for (let i = 0; i < 3; i++) {
    const mesh = new THREE.Mesh(hayGeo, mats.hay);
    mesh.castShadow = true; mesh.receiveShadow = true;
    mesh.rotation.z = Math.PI / 2;
    const x = rand(rng, -8, 8), z = rand(rng, -6, 4);
    mesh.position.set(x, heightAt(x, z) + 0.65, z);
    scene.add(mesh);
    const body = phys.addBody({ x, z, radius: 0.72, mass: 3, tag: 'hay', draggable: true });
    draggables.push({ kind: 'hay', mesh, body });
  }

  return { draggables, gate: gateObj, pondPos, mats };
}
