// Трава и цветы — InstancedMesh (1 вызов отрисовки на тип).
// Трава растёт пятнами; пятна — это же точки выпаса для ИИ.
import * as THREE from 'three';
import { CFG } from '../config.js';
import { makeRng, rand } from '../utils/math.js';

// Возвращает {group, grassSpots:[{x,z}]} — spots использует ИИ овец.
export function buildVegetation(heightAt) {
  const group = new THREE.Group();
  const rng = makeRng(7);
  const half = CFG.world.half - 2;
  const spots = [];

  // пятна травы (кусты для выпаса)
  for (let i = 0; i < CFG.grass.patchCount; i++) {
    spots.push({
      x: rand(rng, -half, half) * 0.9,
      z: rand(rng, -half, half) * 0.9,
    });
  }

  // --- трава: крест-четырёхгранники ---
  const bladeGeo = new THREE.PlaneGeometry(0.34, 0.55, 1, 2);
  bladeGeo.translate(0, 0.26, 0);
  // лёгкий изгиб
  const bp = bladeGeo.attributes.position;
  for (let i = 0; i < bp.count; i++) {
    const y = bp.getY(i);
    bp.setZ(i, bp.getZ(i) + y * y * 0.35);
  }
  const grassMat = new THREE.MeshStandardMaterial({
    color: CFG.colors.grassA, roughness: 1, side: THREE.DoubleSide,
    alphaTest: 0, flatShading: true,
  });
  const grass = new THREE.InstancedMesh(bladeGeo, grassMat, CFG.grass.count * 2);
  const dummy = new THREE.Object3D();
  const col = new THREE.Color();
  let gi = 0;
  for (let i = 0; i < CFG.grass.count; i++) {
    // 70% травы внутри пятен — там гуще
    let x, z;
    if (rng() < 0.7) {
      const s = spots[(rng() * spots.length) | 0];
      x = s.x + rand(rng, -2.2, 2.2); z = s.z + rand(rng, -2.2, 2.2);
    } else {
      x = rand(rng, -half, half); z = rand(rng, -half, half);
    }
    if (Math.abs(x) > half || Math.abs(z) > half) continue;
    const y = heightAt(x, z);
    const rot = rng() * Math.PI;
    for (let k = 0; k < 2; k++) { // крест из двух плоскостей
      dummy.position.set(x, y, z);
      dummy.rotation.set(0, rot + k * Math.PI / 2, 0);
      const s = rand(rng, 0.7, 1.4);
      dummy.scale.set(s, s * rand(rng, 0.8, 1.3), s);
      dummy.updateMatrix();
      grass.setMatrixAt(gi, dummy.matrix);
      col.setHex(rng() < 0.5 ? CFG.colors.grassA : CFG.colors.grassB)
        .multiplyScalar(rand(rng, 0.85, 1.1));
      grass.setColorAt(gi, col);
      gi++;
    }
  }
  grass.count = gi;
  grass.instanceMatrix.needsUpdate = true;
  if (grass.instanceColor) grass.instanceColor.needsUpdate = true;
  grass.receiveShadow = true;
  group.add(grass);

  // --- цветы ---
  const flowerGeo = new THREE.SphereGeometry(0.07, 6, 5);
  const stemGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.3, 4);
  const FN = 120;
  const petals = new THREE.InstancedMesh(flowerGeo,
    new THREE.MeshStandardMaterial({ roughness: 0.7, flatShading: true }), FN);
  const stems = new THREE.InstancedMesh(stemGeo,
    new THREE.MeshStandardMaterial({ color: 0x4e8a3f, roughness: 1 }), FN);
  const petalCols = [0xf2f0e4, 0xe9c46a, 0xef8f7a, 0xc9a7e8];
  for (let i = 0; i < FN; i++) {
    const x = rand(rng, -half, half), z = rand(rng, -half, half);
    const y = heightAt(x, z);
    dummy.position.set(x, y + 0.3, z);
    dummy.rotation.set(0, 0, 0); dummy.scale.setScalar(rand(rng, 0.8, 1.3));
    dummy.updateMatrix();
    petals.setMatrixAt(i, dummy.matrix);
    col.setHex(petalCols[(rng() * petalCols.length) | 0]);
    petals.setColorAt(i, col);
    dummy.position.set(x, y + 0.15, z); dummy.scale.setScalar(1);
    dummy.updateMatrix();
    stems.setMatrixAt(i, dummy.matrix);
  }
  petals.instanceMatrix.needsUpdate = true;
  stems.instanceMatrix.needsUpdate = true;
  group.add(petals, stems);

  return { group, grassSpots: spots };
}
