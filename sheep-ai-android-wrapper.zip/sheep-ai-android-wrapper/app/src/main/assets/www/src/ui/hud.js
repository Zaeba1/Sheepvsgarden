// Минимальный HUD: счётчики + пауза/звук. Никаких игровых кнопок-действий.
export class Hud {
  constructor(loop, audio) {
    this.loop = loop; this.audio = audio;
    this.stats = document.getElementById('stats');
    this.hint = document.getElementById('hint');
    this.btnPause = document.getElementById('btn-pause');
    this.btnSound = document.getElementById('btn-sound');
    this.btnPause.addEventListener('click', () => this.togglePause());
    this.btnSound.addEventListener('click', () => this.toggleSound());
    this._acc = 0;
    setTimeout(() => { this.hint.style.opacity = '0'; }, 9000);
  }
  togglePause() {
    this.loop.paused = !this.loop.paused;
    this.btnPause.textContent = this.loop.paused ? '▶' : '⏸';
  }
  toggleSound() {
    const m = !this.audio.muted;
    this.audio.setMuted(m);
    this.btnSound.textContent = m ? '🔇' : '🔊';
  }
  update(dt, state) {
    this._acc += dt;
    if (this._acc < 0.5) return;
    this._acc = 0;
    this.stats.textContent =
      `🐑 ${state.sheep}   😊 ${state.happy}   ⚡ ${state.fleeing}   ${this.loop.fps} fps`;
  }
}
