// Процедурная стилизованная овца: «облако» шерсти из сфер, морда, уши,
// ноги, хвост. Геометрии кэшируются — одна на всех, масштаб/цвет различаются.
import * as THREE from 'three';
import { CFG } from '../config.js';
import { rand } from '../utils/math.js';

let cache = null;
function geometries() {
  if (cache) return cache;
  cache = {
    woolBig: new THREE.IcosahedronGeometry(0.42, 1),
    woolMid: new THREE.IcosahedronGeometry(0.3, 1),
    head: new THREE.SphereGeometry(0.2, 10, 8),
    ear: new THREE.SphereGeometry(0.08, 6, 5),
    leg: new THREE.CylinderGeometry(0.05, 0.045, 0.42, 6),
    tail: new THREE.SphereGeometry(0.1, 6, 5),
  };
  return cache;
}

export function makeSheepMaterials() {
  return {
    wool: new THREE.MeshStandardMaterial({ color: CFG.colors.wool, roughness: 0.95, flatShading: true }),
    face: new THREE.MeshStandardMaterial({ color: CFG.colors.face, roughness: 0.8, flatShading: true }),
    leg: new THREE.MeshStandardMaterial({ color: CFG.colors.leg, roughness: 0.85, flatShading: true }),
  };
}

// Возвращает {group, parts:{head, legs[], tail, body}} — parts анимируются.
export function buildSheepMesh(rng, mats) {
  const G = geometries();
  const group = new THREE.Group();
  const tint = 0.96 + rand(rng, -0.05, 0.02);
  const woolMat = mats.wool.clone();
  woolMat.color.multiplyScalar(tint);

  // тело — кластер сфер шерсти
  const body = new THREE.Group();
  const blobs = [
    [0, 0.55, 0, 1.0], [0.3, 0.6, 0.12, 0.85], [-0.3, 0.58, -0.1, 0.9],
    [0.12, 0.75, -0.15, 0.7], [-0.15, 0.72, 0.18, 0.75],
    [0.34, 0.45, -0.2, 0.6], [-0.35, 0.48, 0.2, 0.65], [0, 0.42, 0.3, 0.7],
  ];
  for (const [x, y, z, s] of blobs) {
    const m = new THREE.Mesh(G.woolBig, woolMat);
    m.position.set(x, y, z); m.scale.setScalar(s);
    m.castShadow = true; body.add(m);
  }
  group.add(body);

  // голова
  const head = new THREE.Group();
  const skull = new THREE.Mesh(G.head, mats.face);
  skull.scale.set(0.9, 1.05, 1.15); skull.castShadow = true;
  head.add(skull);
  // пучок шерсти на темени
  const tuft = new THREE.Mesh(G.woolMid, woolMat);
  tuft.position.set(0, 0.16, -0.05); tuft.scale.setScalar(0.85);
  head.add(tuft);
  // уши
  const earL = new THREE.Mesh(G.ear, mats.face);
  earL.position.set(0.2, 0.05, 0); earL.scale.set(1.4, 0.7, 0.9);
  const earR = earL.clone(); earR.position.x = -0.2;
  head.add(earL, earR);
  head.position.set(0, 0.72, 0.52);
  group.add(head);

  // ноги
  const legs = [];
  const legPos = [[0.22, 0.3], [-0.22, 0.3], [0.22, -0.32], [-0.22, -0.32]];
  for (const [x, z] of legPos) {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.42, z);
    const leg = new THREE.Mesh(G.leg, mats.leg);
    leg.position.y = -0.21; leg.castShadow = true;
    pivot.add(leg); group.add(pivot); legs.push(pivot);
  }

  // хвост
  const tail = new THREE.Mesh(G.tail, woolMat);
  tail.position.set(0, 0.62, -0.52); tail.scale.setScalar(0.9);
  tail.castShadow = true;
  group.add(tail);

  return { group, parts: { body, head, legs, tail } };
}
