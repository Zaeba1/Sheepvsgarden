// Детерминированный RNG и 2D-математика (x/z плоскость мира).
export function makeRng(seed = 1337) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const rand = (rng, a, b) => a + rng() * (b - a);
export const pick = (rng, arr) => arr[(rng() * arr.length) | 0];

export const v2 = {
  make: (x = 0, z = 0) => ({ x, z }),
  len: (v) => Math.hypot(v.x, v.z),
  dist: (a, b) => Math.hypot(a.x - b.x, a.z - b.z),
  dist2: (a, b) => { const dx = a.x - b.x, dz = a.z - b.z; return dx * dx + dz * dz; },
  norm(out, v) {
    const l = Math.hypot(v.x, v.z) || 1;
    out.x = v.x / l; out.z = v.z / l; return out;
  },
  add(out, a, b) { out.x = a.x + b.x; out.z = a.z + b.z; return out; },
  sub(out, a, b) { out.x = a.x - b.x; out.z = a.z - b.z; return out; },
  scale(out, v, s) { out.x = v.x * s; out.z = v.z * s; return out; },
  limit(out, v, max) {
    const l = Math.hypot(v.x, v.z);
    if (l > max && l > 0) { out.x = v.x / l * max; out.z = v.z / l * max; }
    return out;
  },
  angle(a, b) { return Math.atan2(b.x - a.x, b.z - a.z); }, // yaw: 0 = +z
};

// Поворот угла к цели с ограничением скорости (плавные развороты).
export function turnToward(cur, target, maxStep) {
  let d = target - cur;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return cur + clamp(d, -maxStep, maxStep);
}

// Пространственная хэш-таблица для запросов «соседи».
export class SpatialHash {
  constructor(cell) { this.cell = cell; this.map = new Map(); }
  key(x, z) { return ((x / this.cell) | 0) * 73856093 ^ ((z / this.cell) | 0) * 19349663; }
  clear() { for (const a of this.map.values()) a.length = 0; }
  insert(obj, x, z) {
    const k = this.key(x, z);
    let a = this.map.get(k);
    if (!a) { a = []; this.map.set(k, a); }
    a.push(obj);
  }
  // Вызывает cb для всех объектов в клетках, перекрывающих круг (x,z,r).
  query(x, z, r, cb) {
    const c = this.cell;
    const x0 = ((x - r) / c) | 0, x1 = ((x + r) / c) | 0;
    const z0 = ((z - r) / c) | 0, z1 = ((z + r) / c) | 0;
    for (let ix = x0; ix <= x1; ix++) for (let iz = z0; iz <= z1; iz++) {
      const a = this.map.get(ix * 73856093 ^ iz * 19349663);
      if (a) for (let i = 0; i < a.length; i++) cb(a[i]);
    }
  }
}
