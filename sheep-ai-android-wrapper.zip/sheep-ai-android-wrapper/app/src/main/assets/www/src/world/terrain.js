// Рельеф пастбища: мягкие холмы (вершинный шум), вершинные цвета,
// вторая UV-слой травяных пятен — без текстур, читается на мобильном.
import * as THREE from 'three';
import { CFG } from '../config.js';
import { makeRng, clamp, lerp } from '../utils/math.js';

export function buildTerrain() {
  const { size, segments } = CFG.world;
  const geo = new THREE.PlaneGeometry(size, size, segments, segments);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const cA = new THREE.Color(CFG.colors.groundLow);
  const cB = new THREE.Color(CFG.colors.groundHigh);
  const rng = makeRng(42);

  // простой value-noise для холмов
  const hash = (x, z) => {
    const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
    return s - Math.floor(s);
  };
  const noise = (x, z) => {
    const xi = Math.floor(x), zi = Math.floor(z);
    const xf = x - xi, zf = z - zi;
    const u = xf * xf * (3 - 2 * xf), v = zf * zf * (3 - 2 * zf);
    return lerp(
      lerp(hash(xi, zi), hash(xi + 1, zi), u),
      lerp(hash(xi, zi + 1), hash(xi + 1, zi + 1), u), v);
  };

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    // края приподняты (естественная «чаша» пастбища), центр ровный
    const edge = Math.max(Math.abs(x), Math.abs(z)) / CFG.world.half;
    const hill = noise(x * 0.12 + 7, z * 0.12 + 3) * 0.9 * Math.min(edge * 1.6, 1);
    const micro = noise(x * 0.6, z * 0.6) * 0.12;
    pos.setY(i, hill + micro);
    const t = clamp(noise(x * 0.2, z * 0.2) * 0.7 + micro * 2, 0, 1);
    const c = cA.clone().lerp(cB, t);
    colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  mesh.name = 'terrain';
  return { mesh, heightAt: (x, z) => noise(x * 0.12 + 7, z * 0.12 + 3) * 0.9 *
    Math.min(Math.max(Math.abs(x), Math.abs(z)) / CFG.world.half * 1.6, 1) + noise(x * 0.6, z * 0.6) * 0.12 };
}
